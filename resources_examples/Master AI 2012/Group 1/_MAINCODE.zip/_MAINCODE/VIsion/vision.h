#ifndef _VISION_H_
#define _VISION_H_

#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alvisiontoolboxproxy.h>


using namespace AL;

IplImage* GetColorOrange(IplImage* img, ALVisionToolboxProxy visionToolboxProxy);
IplImage* GetColorBlue(IplImage* img);
float getCameraHeight(float angle);
float* GetCoordinatesBall(IplImage* img);
float* GetCoordinatesGoal(IplImage* img);

void turnHead(ALMotionProxy motion, float yaw, float pitch);
void doTurnHead(float xPos, float yPos, bool* turnAngles);
float getYawFromImage (float x);
float getPitchFromImage (float y);
float getDistance(float angle);
void getWalkCoordinates(float distance, float headyaw, float* walkCoordinates);
bool doChangeCam(float angle, int cameraId);
void changeCamera(ALMotionProxy motion, ALVideoDeviceProxy camProxy, int cameraId);
void updateDistancePitch(ALMotionProxy motion, float distance, int cameraId, float currentpitch);
void followBallHead(float* coordinates, ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy);
void findBall(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy);
void findBallRandom(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy);
void showImages(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy);

#endif