/**
 *
 * This example demonstrates how to get images from the robot remotely and how
 * to display them on your screen using opencv.
 *
 * Copyright Aldebaran Robotics
 */

// Aldebaran includes
#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alledsproxy.h>
#include <alproxies/alvisiontoolboxproxy.h>

// Opencv includes
#include <opencv/cv.h>
#include <opencv/highgui.h>

// C++ include
#include <iostream>
#include <string>
#include <math.h>

#include "movement.h"

#define WALK_FUNCTION 0.5f
#define WALK_PITCH 0.2f

float const PI=4*atan(1); 

float const RADIAN = 180/PI;

using namespace AL;

float currentX, currentY, lastX, lastY;
bool turnAngles[2];
int cameraId = 0;
float* coordinates;
float walkCoordinates[2];
float backupPitch;

//desciption: This function is used to threshold colors in an image. Returns the thresholded image
//input: original image (RGB)
//output: thresholded image (HSV)`
IplImage* GetColorOrange(IplImage* img, ALVisionToolboxProxy visionToolboxProxy)
{
	int luminosity = visionToolboxProxy.isItDark();
    IplImage* imgHSV = cvCreateImage(cvGetSize(img),8,3);
    cvCvtColor(img, imgHSV, CV_BGR2HSV);
    IplImage* threshed = cvCreateImage(cvGetSize(img),8,1);
	CvScalar scalar1;
	CvScalar scalar2;
	if (luminosity <= 50 ) //bright
	{
		scalar1 = cvScalar(0, 20, 150, 0);
		scalar2 = cvScalar(30, 180, 255, 0);
	}
	else if (luminosity > 50 && luminosity <= 100) //normal
	{
		scalar1 = cvScalar(0, 50, 40, 0);
		scalar2 = cvScalar(30, 255, 255, 0);
	}
    cvInRangeS(imgHSV,scalar1, scalar2,threshed);
	cvSmooth(threshed, threshed, CV_GAUSSIAN, 9, 9 );
    cvReleaseImage(&imgHSV);
    return threshed;
}

//desciption: This function is used to threshold colors in an image. Returns the thresholded image
//input: original image (RGB)
//output: thresholded image (HSV)
IplImage* GetColorBlue(IplImage* img)
{
   	IplImage* threshblue = cvCreateImage(cvGetSize(img),8,3);
	cvInRangeS(img,cvScalar(150, 20, 180, 0), cvScalar(200, 50, 200, 0),threshblue);	
	cvSmooth(threshblue, threshblue, CV_GAUSSIAN, 9, 9 );
	cvReleaseImage(&threshblue);
	return threshblue;
}

//description: This function returns the current height of the camera
//output: cameraheight in m
//intput: headPitch in radians
float getCameraHeight(float angle)
{
	return 0.48 + 0.05*angle; 
}

//description: Returns position of the ball in 2D space by applying generalized houghs transform
//output: Coordinates (x,y) of the centre of the ball and the radius of the ball
//input: The frame grabbed by the NAO
float* GetCoordinatesGoal(IplImage* img)
{
     IplImage* imggrey = cvCreateImage(cvGetSize(img),8,3);
	 //Memory for hough transform      
	CvMemStorage* storage = cvCreateMemStorage(0);
 	//Perform Canny edge detection
	cvCanny( img, img, 50, 200, 3 );
	cvCvtColor(img, imggrey, CV_RGB2GRAY);
	CvSeq* lines = cvHoughLines2( imggrey, storage, CV_HOUGH_PROBABILISTIC, 1, 5, 20);
	printf("No. lines:%i\n", lines->total);
	float* line = 0;
		for(int i = 0; i < lines->total; i++ )
        {
            line = (float*) cvGetSeqElem(lines,i);
        }
	return line;
}

//description: Returns position of the goal in 2D space by applying generalized houghs transform
//output: Coordinates (x,y) of the centre of the goal and the radius of the ball
//input: The frame grabbed by the NAO
float* GetCoordinatesBall(IplImage* img)
{
	CvMemStorage* storage = cvCreateMemStorage(0);
	CvSeq* circles = cvHoughCircles(img, storage, CV_HOUGH_GRADIENT, 2,img->height/4, 100, 50, 1, 400);
	float* p = 0;
	for (int i = 0; i < circles->total; i++)
	{
		p = (float*)cvGetSeqElem( circles, i );
		//printf("Ball! x=%f y=%f r=%f\n\r",p[0],p[1],p[2] );
		cvCircle(img, cvPoint(cvRound(p[0]),cvRound(p[1])),3, CV_RGB(255,255,0), -1, 8, 0 );
		cvCircle(img, cvPoint(cvRound(p[0]),cvRound(p[1])),cvRound(p[2]), CV_RGB(255,255,0), 3, 8, 0 );
	}
	return p;
}

//description: This function makes the NAO face the ball by rotating (pitch,yaw) its head
//output: void
//input: the motion proxy, the current values of head yaw and head pitch
void turnHead(ALMotionProxy motion, float yaw, float pitch)
{
	printf("Turning head...");
    const AL::ALValue headyaw = "HeadYaw";
	const AL::ALValue headpitch = "HeadPitch";

    try{
        AL::ALValue stiffness = 1.0f;
        AL::ALValue time = 0.1f;
        motion.stiffnessInterpolation(headyaw,stiffness,time);
        motion.stiffnessInterpolation(headpitch,stiffness,time);
        AL::ALValue angleyaw = AL::ALValue::array(yaw);
        AL::ALValue timeyaw = AL::ALValue::array(0.3f);
        AL::ALValue anglepitch = AL::ALValue::array(pitch);
        AL::ALValue timepitch = AL::ALValue::array(0.3f);

        bool isAbsolute = true;

		motion.angleInterpolation(headyaw,angleyaw,timeyaw,isAbsolute);
		motion.angleInterpolation(headpitch,anglepitch,timepitch,isAbsolute);
        stiffness = 0.0f;
        time = 0.1f;
        motion.stiffnessInterpolation(headyaw,stiffness,time);
        motion.stiffnessInterpolation(headpitch,stiffness,time);
		printf("done\n");
    }
    catch(const AL::ALError& e)
    {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    
}

//description: Performs a check to determine whether the position of the ball as changed, which would require the NAO to move it head to the new position
// output: headYaw in radians
// input: y-coordinate from image
void doTurnHead(float xPos, float yPos, bool* turnAngles)
{
	abs(xPos-lastX) > 20 ? turnAngles[0] = true : turnAngles[0] = false;
	abs(yPos-lastY) > 15 ? turnAngles[1] = true : turnAngles[1] = false;
}

//description: Determines the head yaw value required to face the ball
// output: headYaw in radians
// input: y-coordinate from image
float getYawFromImage (float x)
{
	float degreepix = 61.0/320.0;
	float diff = 160.0-x;
	float angle = diff*degreepix/57.2;
	return angle;
}

//description: Determines the head pitch value to face the ball
// output: headPitch in radians
// input: x-coordinate from image
float getPitchFromImage (float y)
{
	float degreepix = 61.0/320.0;
	float diff = 120.0-y;
	float angle = diff*degreepix/57.2;
	return -angle;
}

//description: COnverts the 2D space coordinates to NAOspace and retreives the distance to the ball from the NAO
// output: distance to ball in m
// input: headPitch in radians
float getDistance(float angle)
{
	float realangle = 0.0;
	float distance = 0.0;
	if (cameraId == 0)
	{
	 	realangle = (180.0/57.6-90.0/57.6-angle);
		distance = tan(realangle) * getCameraHeight(angle);
	}
	else
	{
		realangle = (180.0/57.6-(90.0+40.0)/57.6-angle);
		distance = tan(realangle) * getCameraHeight(angle);
	}
	
	return distance;
}

//description: Retreives the coordinatesof the ball in NAOspace
// output: x and y coordinates
// input: distance in m, headYaw in radians, x and y coordinates (can be unset)
void getWalkCoordinates(float distance, float headyaw, float* walkCoordinates)
{
    walkCoordinates[0] = cos(headyaw)*distance;
    walkCoordinates[1] = sin(headyaw)*distance;
}


//description: Performs a check and returns a boolean to determine whether the NAO should switch between cameras
//cameraId 0 -> head camera
//cameraId 1 -> chin camera
bool doChangeCam(float angle, int cameraId)
{
	printf("Check to change cam...");
	bool change = false;
	
	if (cameraId == 0)
	{
		if (angle >= 0.5){
			printf("true\n");
			change = true;
		}
		else printf("false\n");
	}
	else
	{
		if (angle <= 0.0){
			printf("true\n");
			change = true;
		}
		else printf("false\n");
	}
	
	return change;
}

//description: Switches between cameras based on the boolean value returned by doChangeCam
//output: void
//input: proxies to vision and motion, camera id 
void changeCamera(ALMotionProxy motion, ALVideoDeviceProxy camProxy, int cameraId)
{
	printf("Changing camera...");
	if (cameraId == 0)
	{
		camProxy.setParam(18,1);
		cameraId = 1;
		printf("changed to 1\n");
		turnHead(motion, 0.0f, 0.7f);
	}
	else{
		camProxy.setParam(18,0);
		cameraId = 0;
		printf("changed to 0\n");
		turnHead(motion, 0.0f, -0.7f);
	}
}

//description: Updates the head pith angle with respect to the position of the ball(relative to the crrent pitch)\
//input: mationproxy, distance to ball in m
//output: void
void updateDistancePitch(ALMotionProxy motion, float distance, int cameraId, float currentpitch)
{
	float angle;
	if (cameraId == 0)	angle = atan(distance/getCameraHeight(currentpitch));
	else angle = atan(distance/getCameraHeight(backupPitch));
	float headpitch = 180/57.6-headpitch-90.0/57.6;
	turnHead(motion, 0.0f, headpitch);
}

//descripton: Performs the turn head motion in order to track the ball
//input: coordinates of the ball, motion and vision proxies.
//output: void
void followBallHead(float* coordinates, ALMotionProxy motion, ALVideoDeviceProxy camProxy)
{
	doTurnHead(coordinates[0], coordinates[1], turnAngles);

	float angleyaw = 0;
	float anglepitch = 0;
	std::string headyaw = "HeadYaw";
	std::vector<float> HeadYaw = motion.getAngles(headyaw, true);
	std::string headpitch = "HeadPitch";
	std::vector<float> HeadPitch = motion.getAngles(headpitch, true);
	//printf("HeadYaw:%f, HeadPitch:%f\n",HeadYaw[0],HeadPitch[0]);

	if (turnAngles[0]) angleyaw = getYawFromImage(coordinates[0]);
	if (turnAngles[1]) anglepitch = getPitchFromImage(coordinates[1]);
	if (anglepitch != 0 && angleyaw != 0) turnHead(motion, HeadYaw[0] + angleyaw, HeadPitch[0] + anglepitch);
}

//description: The Nao searches for the ball by performing a intuitive search 
//input: proxies to motion, camera and the vision toolbox
//output: a boolean value used to determine whether the all is found
bool findBall(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy)
{
	const std::string clientName = camProxy.subscribe("test", kQVGA, kBGRColorSpace, 30);
	camProxy.setParam(18,1);
    IplImage* imgHeader = cvCreateImageHeader(cvSize(320, 240), 8, 3);
	
	IplImage* color;
	float* coordinates;
	for (int i = 0; i<=3; i++)
	{
		turnHead(motion, 0.9f-i*0.425f, 0.5);
		for (int j = 0; j<2; j++)
		{
			ALValue img = camProxy.getImageRemote(clientName);
			imgHeader->imageData = (char*)img[6].GetBinary();
			camProxy.releaseImage(clientName);
			color = GetColorOrange(imgHeader, visionToolboxProxy);
			coordinates = GetCoordinatesBall(color);
			if (coordinates != 0) return true;
		}
		
		turnHead(motion, 0.9f-i*0.425f, 0.15);
		for (int j = 0; j<2; j++)
		{
			ALValue img = camProxy.getImageRemote(clientName);
			imgHeader->imageData = (char*)img[6].GetBinary();
			camProxy.releaseImage(clientName);
			color = GetColorOrange(imgHeader, visionToolboxProxy);
			coordinates = GetCoordinatesBall(color);
			if (coordinates != 0) return true;
		}
		
		turnHead(motion, 0.9f-i*0.425f, -0.3);
		for (int j = 0; j<2; j++)
		{
			ALValue img = camProxy.getImageRemote(clientName);
			imgHeader->imageData = (char*)img[6].GetBinary();
			camProxy.releaseImage(clientName);
			color = GetColorOrange(imgHeader, visionToolboxProxy);
			coordinates = GetCoordinatesBall(color);
			if (coordinates != 0) return true;
		}
		
		turnHead(motion, 0.9f-i*0.425f, -0.6);
		for (int j = 0; j<2; j++)
		{
			ALValue img = camProxy.getImageRemote(clientName);
			imgHeader->imageData = (char*)img[6].GetBinary();
			camProxy.releaseImage(clientName);
			color = GetColorOrange(imgHeader, visionToolboxProxy);
			coordinates = GetCoordinatesBall(color);
			if (coordinates != 0) return true;
		}
	}
}

//description: Performs the function of searching for the ball in a random manner 
//input: proxies to motion, camera and the vision toolbox,
//output: a boolean value determining if the ball is found or not
bool findBallRandom(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy)
{
	const std::string clientName = camProxy.subscribe("test", kQVGA, kBGRColorSpace, 30);
	camProxy.setParam(18,1);
    IplImage* imgHeader = cvCreateImageHeader(cvSize(320, 240), 8, 3);

	srand((unsigned)time(0));
	bool found = false;
	int count = 0;
	IplImage* color;
	while(!found || count < 10)
	{
		float randyaw = (float)rand()/(float)RAND_MAX * 1.8 - 0.9;
		float randpitch = (float)rand()/(float)RAND_MAX * 1.1 - 0.6;
		turnHead(motion, randyaw, randpitch);
		for (int i = 0; i<2; i++)
		{
			ALValue img = camProxy.getImageRemote(clientName);
			imgHeader->imageData = (char*)img[6].GetBinary();
			camProxy.releaseImage(clientName);
			color = GetColorOrange(imgHeader, visionToolboxProxy);
			coordinates = GetCoordinatesBall(color);
			if (coordinates != 0) found = true;
		}		
		count++;
	}	
}

//description: This function instantiates the proxies. Creates a loop to capture frames from the camera and calls other methods to perform operations on the frame
//outut: void
//input: proxies to vision, camera and the vision toolbox 
void showImages(ALMotionProxy motion, ALVideoDeviceProxy camProxy, ALVisionToolboxProxy visionToolboxProxy)
{

    const std::string clientName = camProxy.subscribe("test", kQVGA, kBGRColorSpace, 30);
	camProxy.setParam(18,1);
	cameraId = 1;
	
	//motion.setStiffnesses("Body", 1.0);
  	
    IplImage* imgHeader = cvCreateImageHeader(cvSize(320, 240), 8, 3);
  	
    cvNamedWindow("color", CV_WINDOW_AUTOSIZE);
    cvNamedWindow("images", CV_WINDOW_AUTOSIZE);
	
	int wait = 0;
	int detected = 0;
    while ((char) cvWaitKey(10) != 'q')
    {
    	
		ALValue img = camProxy.getImageRemote(clientName);

	    imgHeader->imageData = (char*)img[6].GetBinary();		
	    camProxy.releaseImage(clientName);
		//IplImage* color = GetColorBlue(imgHeader);
		IplImage* color = GetColorOrange(imgHeader, visionToolboxProx);
		float* coordinates = GetCoordinatesBall(color);
		if (coordinates != 0)
		{
			detected++;
			
			if (wait >= 2)
			{
				followBallHead(coordinates, motion, camProxy);
            	std::string headpitch = "HeadPitch";
	            std::vector<float> HeadPitch = motion.getAngles(headpitch, true);
               	std::string headyaw = "HeadYaw";
	            std::vector<float> HeadYaw = motion.getAngles(headyaw, true);
	            float distance = getDistance(HeadPitch[0]);
                getWalkCoordinates(distance, HeadYaw[0], walkCoordinates);
                //printf("x:%f, y:%f, distance:%f", walkCoordinates[0], walkCoordinates[1], distance);
				backupPitch = HeadPitch[0];
				turnHead(motion, 0.0f, WALK_PITCH);
				Walk(motion, walkCoordinates[0]*WALK_FUNCTION, walkCoordinates[1]*WALK_FUNCTION, 0.0f);
				Walk(motion, 0.0f, 0.0f, HeadYaw[0]);
				turnHead(motion, 0.0f, -0.2f);
				wait = 0;
			}
			wait++;
			
		}
		cvShowImage("color", color);
	    cvShowImage("images", imgHeader);
		cvReleaseImage(&color);
		
  	}
	printf("prob:%f\n", (float)detected/50.0);
    camProxy.unsubscribe(clientName);
    cvReleaseImageHeader(&imgHeader);
}