#ifndef _MOVEMENT_H_
#define _MOVEMENT_H_
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>

#include <iostream>

using namespace AL;

void Walk(ALMotionProxy motion, float x, float y, float theta);

#endif