#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alvisiontoolboxproxy.h>


#include <iostream>

#include "vision.h";

int s,v;

int main(int argc, char* argv[])
{
	ALMotionProxy motionProxy(argv[1],9559);
	ALVideoDeviceProxy camProxy(argv[1], 9559);
	ALVisionToolboxProxy visionToolboxProxy("192.168.200.17" , 9559);
  	if (argc < 2)
	  {
	    std::cerr << "Usage 'getimages robotIp'" << std::endl;
	    return 1;
	  }

	  //const std::string robotIp(argv[1]);

	  try
	  {
		
	    showImages(motionProxy, camProxy, visionToolboxProxy);
	  }
	  catch (const AL::ALError& e)
	  {
	    std::cerr << "Caught exception " << e.what() << std::endl;
	  }

	  return 0;
}