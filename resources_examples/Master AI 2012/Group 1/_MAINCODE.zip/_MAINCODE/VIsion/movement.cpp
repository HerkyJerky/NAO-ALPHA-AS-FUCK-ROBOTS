#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>

#include <iostream>

using namespace AL;

//description: The NAO walks to the coordinates of the ball (x,y) using Whole Body motion
void Walk(ALMotionProxy motion, float x, float y, float theta)
{
	printf("Starting walk...");
	motion.setStiffnesses("Body", 1.0f);
	motion.walkInit();
	motion.walkTo(x, y, theta);
	printf("done\n");
}
