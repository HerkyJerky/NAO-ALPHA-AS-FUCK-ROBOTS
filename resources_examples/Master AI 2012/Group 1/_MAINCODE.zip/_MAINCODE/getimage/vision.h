#ifndef _VISION_H_
#define _VISION_H_

#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>

using namespace AL;

IplImage* GetColor(IplImage* img);

//output: cameraheight in m
//intput: headPitch in radians
float getCameraHeight(float angle);
float* GetCoordinates(IplImage* img);
void turnHead(ALMotionProxy motion, float yaw, float pitch);
// output: headYaw in radians
// input: y-coordinate from image
void doTurnHead(float xPos, float yPos, bool* turnAngles);
// output: headYaw in radians
// input: y-coordinate from image
float getYawFromImage (float x);
// output: headPitch in radians
// input: x-coordinate from image
float getPitchFromImage (float y);
// output: distance to ball in m
// input: headPitch in radians
float getDistance(float angle);
// output: x and y coordinates
// input: distance in m, headYaw in radians, x and y coordinates (can be (0,0))
void getWalkCoordinates(float distance, float headyaw, float* walkCoordinates);
bool doChangeCam(float angle, int cameraId);
void changeCamera(ALMotionProxy motion, ALVideoDeviceProxy camProxy, int cameraId);
//input: mationproxy, distance to ball in m
void updateDistancePitch(ALMotionProxy motion, float distance, int cameraId, float currentpitch);
void followBallHead(float* coordinates, ALMotionProxy motion, ALVideoDeviceProxy camProxy);
void findBall(ALMotionProxy motion, IplImage* img);
void showImages(ALMotionProxy motion, ALVideoDeviceProxy camProxy);

#endif