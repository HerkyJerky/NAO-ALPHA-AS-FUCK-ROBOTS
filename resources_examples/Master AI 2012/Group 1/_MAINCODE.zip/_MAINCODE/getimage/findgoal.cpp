//**
// *
// * This code demonstrates how to get images from the robot remotely and how
// * to detect the goal using opencv.
// *
// * Copyright Group1 MAI
// */

// Aldebaran includes.
#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alerror/alerror.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alledsproxy.h>

// Opencv includes.
#include <opencv/cv.h>
#include <opencv/highgui.h>

#include <iostream>
#include <string>
#include <math.h>

using namespace AL;


#define WALK_FUNCTION 0.5
#define WALK_PITCH 0.2f
Initialize variables
float currentX, currentY, lastX, lastY;
bool turnAngles[2];
int cameraId = 0;
float* coordinates;
float walkCoordinates[2];
float backupPitch;


//threshold the image for blue
IplImage* GetColorBlue(IplImage* img)
{
	IplImage* threshblue = cvCreateImage(cvGetSize(img),8,3);
    cvInRangeS(img,cvScalar(150, 20, 180, 0), cvScalar(200, 50, 200, 0),threshblue);
	cvSmooth(threshblue, threshblue, CV_GAUSSIAN, 9, 9 );
    cvReleaseImage(&threshblue);
    return threshblue;
}

//threshold the image for yellow
IplImage* GetColorYellow(IplImage* img)
{
	IplImage* threshyelllow = cvCreateImage(cvGetSize(img),8,3);
    cvInRangeS(img,cvScalar(40, 120, 210, 0), cvScalar(50, 250, 255, 0),threshyellow);
	cvSmooth(threshyellow, threshyellow, CV_GAUSSIAN, 9, 9 );
    cvReleaseImage(&threshyellow);
    return threshyellow;
}

//get current camera height
//output: cameraheight in m
//intput: headPitch in radians
float getCameraHeight(float angle)
{
	return 0.48 + 0.05*angle; 
}

float* GetCoordinates(IplImage* img)
{
		IplImage* imggrey = cvCreateImage(cvGetSize(img),8,3);
       //Memory for hough transform      
	   CvMemStorage* storage = cvCreateMemStorage(0);
	   //Perform Canny edge detection
	   cvCanny( img, img, 50, 200, 3 );
	   cvCvtColor(img, imggrey, CV_RGB2GRAY);
	   //Feature extraction , detect lines using Hough lines transform
	   CvSeq* lines = cvHoughLines2( imggrey, storage, CV_HOUGH_PROBABILISTIC, 1, 5, 20);
		 for(int i = 0; i < lines->total; i++ )
        {
           CvPoint* pts = (CvPoint*) cvGetSeqElem(lines,i);
			//for testing and validation
			//cvLine( imgbgr, pts[0], pts[1], cvScalar(0,0,255), 3, 8 );
			/*printf ("starting point= %f ;", pts[0]);
			printf ("ending point = %f \n", pts[1]); */
	     }
		 return lines;
}

//turn head to face the goal
void turnHead(ALMotionProxy motion, float yaw, float pitch)
{
	printf("Turning head...");
    const AL::ALValue headyaw = "HeadYaw";
	const AL::ALValue headpitch = "HeadPitch";

    try{
        AL::ALValue stiffness = 1.0f;
        AL::ALValue time = 0.1f;
        motion.stiffnessInterpolation(headyaw,stiffness,time);
        motion.stiffnessInterpolation(headpitch,stiffness,time);
        AL::ALValue angleyaw = AL::ALValue::array(yaw);
        AL::ALValue timeyaw = AL::ALValue::array(0.3f);
        AL::ALValue anglepitch = AL::ALValue::array(pitch);
        AL::ALValue timepitch = AL::ALValue::array(0.3f);

        bool isAbsolute = true;

		motion.angleInterpolation(headyaw,angleyaw,timeyaw,isAbsolute);
		motion.angleInterpolation(headpitch,anglepitch,timepitch,isAbsolute);
        stiffness = 0.0f;
        time = 0.1f;
        motion.stiffnessInterpolation(headyaw,stiffness,time);
        motion.stiffnessInterpolation(headpitch,stiffness,time);
		printf("done\n");
    }
    catch(const AL::ALError& e)
    {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    
}


void showImages(ALMotionProxy motion, ALVideoDeviceProxy camProxy)
{
	 /** Subscribe a client image requiring 320*240 and BGR colorspace.*/
    const std::string clientName = camProxy.subscribe("test", kQVGA, kBGRColorSpace, 30);
	camProxy.setParam(18,1);
	cameraId = 0;
	motion.setStiffnesses("Body", 1.0);
	//turnHead(motion, 0.0f, -0.3f);
  /** Create an iplimage header to wrap into an opencv image.*/
    IplImage* imgHeader = cvCreateImageHeader(cvSize(320, 240), 8, 3);
	IplImage* color = cvCreateImage(cvGetSize(imgHeader),8,3);
	//for testing and validation
  /** Create a OpenCV window to display the images. */
    cvNamedWindow("color", CV_WINDOW_AUTOSIZE);
    cvNamedWindow("images", CV_WINDOW_AUTOSIZE);

	int wait = 0;
  /** Main loop. Exit when pressing ESC.*/
    while ((char) cvWaitKey(30) != 'q')
    {
		ALValue img = camProxy.getImageRemote(clientName);

   	 	/** Access the image buffer (6th field) and assign it to the opencv image
	    * container. */
	    imgHeader->imageData = (char*)img[6].GetBinary();
	    /** Tells to ALVideoDevice that it can give back the image buffer to the
	    * driver. Optional after a getImageRemote but MANDATORY after a getImageLocal.*/
	    camProxy.releaseImage(clientName);
		IplImage* color = GetColorBlue(imgHeader);
		float* coordinates = GetCoordinates(color);
		/*if (coordinates != 0)
		{
			if (wait >= 10)
			{
				if(followBallHead(coordinates, motion, camProxy)) followBallHead(coordinates, motion, camProxy);
            	std::string headpitch = "HeadPitch";
	            std::vector<float> HeadPitch = motion.getAngles(headpitch, true);
               	std::string headyaw = "HeadYaw";
	            std::vector<float> HeadYaw = motion.getAngles(headyaw, true);
	            float distance = getDistance(HeadPitch[0]);
                getWalkCoordinates(distance, HeadYaw[0], walkCoordinates);
                backupPitch = HeadPitch[0];
				turnHead(motion, 0.0f, WALK_PITCH);
				wait = 0;
			}
		}*/
	    /** Display the iplImage on screen. For testing purposes*/
	    wait++;
		cvShowImage("color", color);
	    cvShowImage("images", imgHeader);
  	}

  	/** Cleanup.*/
    camProxy.unsubscribe(clientName);
    cvReleaseImageHeader(&imgHeader);
}

int main(int argc, char* argv[])
{
	ALMotionProxy motion(argv[1],9559);
	ALVideoDeviceProxy camProxy(argv[1], 9559);
  	if (argc < 2)
	  {
	    std::cerr << "Usage 'getimages robotIp'" << std::endl;
	    return 1;
	  }

	  const std::string robotIp(argv[1]);

	  try
	  {
	    showImages(motion, camProxy);
	  }
	  catch (const AL::ALError& e)
	  {
	    std::cerr << "Caught exception " << e.what() << std::endl;
	  }

	  return 0;
	}