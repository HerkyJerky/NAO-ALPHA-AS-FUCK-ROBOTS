#ifndef MULTILOCRAYCAST_H
#define MULTILOCRAYCAST_H

#include "MultiLoc.h"

class MultiLocRayCast : public MultiLoc
{
public:
	MultiLocRayCast(ALPtr<ALBroker> pBroker, const std::string& pName);
	virtual void process();
	//~MultiLocRayCast();

private:
	CvPoint rayTrace(IplImage* const s, int const threshold, CvPoint const start, float const angle, int const channel=0);
	void evaluateParticles();
	void blueDetector();
	void yellowDetector();
	void redDetector();
	void colorDetector(int const hue, int const sat, int const val, IplImage* h, vector<ImageParticle*>* dst, const int dh=10, const int ds=128);
	virtual void displayImages();

};

#endif