#include <almathinternal/tools/mersennetwister.h>

#include <opencv/cxtypes.h>
#include <opencv/highgui.h>
#include <opencv/cv.h>

#include <vector>

using namespace std;

class ImageParticle{
public:
	ImageParticle(){
		this->x = randi(MAX_X);
		this->y = randi(MAX_Y);
		this->weight = 1;
	}

	void drawParticle(IplImage* img, CvScalar col = CV_RGB(255,0,0)){
		cvDrawCircle(img, cvPoint(x,y),2,col,3);
	}

	int x;
	int y;
	float weight;
	static const int MAX_X = 320;
	static const int MAX_Y = 240;

	static float randf(float const max = 1, float const min = 0){
		float diff = max-min;

		return 	mersennetwister::genrand_real2()*diff + min;
	}

	static int randi(int const max, int const min=0){
		return (int)randf(max, min);
	}

	static void drawParticles(IplImage* img, std::vector<ImageParticle*>& l, CvScalar col = CV_RGB(255,0,0)){
		for(int i=0; i<l.size(); i++){
			l[i]->drawParticle(img, col);
		}
	}

	static void deleteParticles(std::vector<ImageParticle*>& list){	
		for(int i=0; i<list.size(); i++){
			delete list[i];
		}
		list.clear();
	}

	static void generateParticles(int const n, std::vector<ImageParticle*>& dst){
		for(int i=0; i<n; i++){
			dst.push_back(new ImageParticle());
		}
	}

	static void resampleParticles(int const nTotal, int const newParticles, std::vector<ImageParticle*> const &  src, std::vector<ImageParticle*>& dst){

		int nKeep = nTotal - newParticles;

		std::vector<ImageParticle*> list;

		int weight = 0;
		for(int i=0; i<src.size(); i++){
			int x = src[i]->x;
			int y = src[i]->y;
			int neighbours = 0;
			for(int j=0; j<src.size(); j++){
				int dx = x - src[j]->x;
				int dy = y- src[j]->y;
				if(sqrt((double)(dx*dx + dy*dy)) < 10){
					neighbours++;

					if(neighbours > 9){
						break;
					}
				}
			}
			weight = src[i]->weight ;/// (neighbours / 10 + 1) + 1;
			for(int j=0;j<weight;j++){
				list.push_back(src[i]);
			}
		}

		for(int i=0; i<nKeep; i++){
			dst.push_back(sampleRandomParticle(list));
		}
		for(int i=0; i<newParticles; i++){
			dst.push_back(new ImageParticle());
		}
	}

	static ImageParticle* sampleRandomParticle(std::vector<ImageParticle*>& src){
		int pos = randi(src.size());
		ImageParticle* p = new ImageParticle();
		p->x = src[pos]->x+randi(2,-2);
		p->y = src[pos]->y+randi(2,-2);
		return p;
	}

	static ImageParticle getLocationEstimate(std::vector<ImageParticle*>& src){
		int n=src.size();
		ImageParticle p;
		p.x=0;
		p.y=0;
		for(int i=0; i<n; i++){
			p.x += src[i]->x;
			p.y += src[i]->y;
		}
		p.x /= n;
		p.y /= n;

		return p;
	}

	static float getVariance(std::vector<ImageParticle*>& src){
		ImageParticle mu = getLocationEstimate(src);
		int n=src.size();
		int var=0;
		for(int i=0; i<n; i++){
			int k=(src[i]->x-mu.x + src[i]->y-mu.y);
			var+=(k*k);
		}

		return var/(n-1);
	}
};