#include "MultiLocRayCast.h"

MultiLocRayCast::MultiLocRayCast(ALPtr<ALBroker> pBroker, const std::string& pName) : MultiLoc(pBroker, pName)
{
}

void MultiLocRayCast::displayImages(){
#ifdef USE_OPENCV_UI
	int maxI = MEASUREMENTS+1;
	float f = -PI/maxI;	
	
	cvCopy(soccerfield_col, displayPf);

	vector<float> camPositionNao = motionProxy->getPosition("CameraBottom", SPACE_NAO, true); 
	NaoLocationParticle loc(lastOwnPosition[0],lastOwnPosition[1],lastOwnPosition[2]);
	
	CvPoint start = cvPoint(hsv->width/2, hsv->height-10);
	for(int i=1; i<maxI; i++){
		CvPoint target = rayTrace(s, 5, start, f*i);
		if(target.x> 0 && target.y > 0 && target.x < hsv->width && target.y < hsv->height){			
			//cvCircle(img,target, 4, CV_RGB(255,0,0), 4);
			//cvLine(img, target, start, CV_RGB(0,255,0),2);

			if(i%1==0){
				stringstream* ss = new stringstream();
				*ss << measurement[i-1];
				CvPoint x3q579 = cvPoint(target.x, target.y-10);			
				//cvPutText(img, ss->str().c_str(), x3q579, &fnt,  CV_RGB(0,0,255));
				delete ss;
			}
		}
	}
	CvPoint locStart = cvPoint(loc.getX(), loc.getY());

	f = PI/maxI*0.7;
	for(int j=0; j<MEASUREMENTS; j++){		
		CvPoint locEnd = cvPoint(locStart.x + cos(loc.getTheta()-PI/2+(j+1)*f) * measurement[MEASUREMENTS-j-1]*100, locStart.y + sin(loc.getTheta()-PI/2+(j+1)*f)*measurement[MEASUREMENTS-j-1]*100); 
		//CvPoint locEnd = rayTrace(soccerfield, 42, locStart, loc.getTheta()-((PI/2)+((j+1)*f)));
		cvLine(displayPf, locStart, locEnd, CV_RGB(0,255,0),1);
	}

	//--- DEBUG ---
	cvZero(canvas);
	ImageParticle::drawParticles(canvas, imPtclsBlue[ptidx], CV_RGB(0,0,255));
	ImageParticle::drawParticles(canvas, imPtclsYellow[ptidx], CV_RGB(255,255,0));
	ImageParticle::drawParticles(img, imPtclsRed[ptidx], CV_RGB(255,0,0));

	NaoLocationParticle::drawParticles(displayPf, ptcls[ptidx]);	
	NaoLocationParticle::drawParticle(displayPf, &loc, 0, 8, 4, CV_RGB(255,255,0),CV_RGB(0,0,255));

	cvShowImage("Canvas", canvas);
	cvShowImage("Input", img);
	cvShowImage("Canny(s)", s);
	cvShowImage("Particles", displayPf);
	cvWaitKey(1);
#endif
}


CvPoint MultiLocRayCast::rayTrace(IplImage* const s, int const threshold, CvPoint const start, float const angle, int const channel){
	float x = (float)start.x;
	float y = (float)start.y;
	float dx = cos(angle);
	float dy = sin(angle);
	while(x > 0 && y > 0 && x < s->width && y < s->height){
		int value = cvGet2D(s, (int)y, (int)x).val[channel];
		if(value > threshold){
			break;
		}
		x+=dx;
		y+=dy;
	}

	return cvPoint((int)x,(int)y);
}

void MultiLocRayCast::evaluateParticles(){
	const float MAX_V = 5.0f;
	const float EPS = 1e-1f;
	for(unsigned int i=0; i<ptcls[ptidx].size();i++){
		float f = PI/(MEASUREMENTS+1)*0.7;
		float val = 0;
		int skippedOnes = 0;
		
		float diff = 0;
		for(int j=0; j<MEASUREMENTS ; j++){
			int measurementIndex = MEASUREMENTS-j-1;
			if(measurement[measurementIndex] > MAX_V) { // maybe lower value to have more accuracy
				skippedOnes++;
				continue;
			}

			CvPoint start = cvPoint(ptcls[ptidx][i]->getX(), ptcls[ptidx][i]->getY());
			CvPoint end = rayTrace(soccerfield, 42, start, ptcls[ptidx][i]->getTheta()+((PI/2)+((j+1)*f)));

			float dist = sqrt(sq((float)(start.x-end.x)) + sq((float)(start.y-end.y))) / 100.0f;
			diff += abs(measurement[measurementIndex] - dist) / abs(measurement[measurementIndex]);
		}

		if(diff<0.01) val+= 20;
		else if(diff<0.032) val+= 7;
		else if(diff<0.172) val+= 4;
		else if(diff<0.572) val+= 2;
		else val+= 1;

		
		if(seeYellowGoal && cos(ptcls[ptidx][i]->getTheta()) > 0.5 && ptcls[ptidx][i]->getX() > 300){
			if((lastYellowGoalImg.x - imgWidth/2 < 0 && ptcls[ptidx][i]->getY() > 200) || 
				(lastYellowGoalImg.x - imgWidth/2 > 0 && ptcls[ptidx][i]->getY() < 200)){
					val*=2;
			}
		}
		else if(seeBlueGoal &&  cos(ptcls[ptidx][i]->getTheta()) < -0.5 && ptcls[ptidx][i]->getX() < 300){
			if((lastBlueGoalImg.x - imgWidth/2 < 0 && ptcls[ptidx][i]->getY() > 200) || 
				(lastBlueGoalImg.x - imgWidth/2 > 0 && ptcls[ptidx][i]->getY() < 200)){
					val*=2;
			}
		}
		
		ptcls[ptidx][i]->setWeight((int)val);
	}
}


void MultiLocRayCast::blueDetector(){
	colorDetector(120, 255, 255, hsv, imPtclsBlue);
}

void MultiLocRayCast::yellowDetector(){
	colorDetector(35, 255, 255, hsv, imPtclsYellow);
}

void MultiLocRayCast::redDetector(){
	colorDetector(0, 255, 255, hsv, imPtclsRed);
}

void MultiLocRayCast::colorDetector(int const hue, int const sat, int const val, IplImage* h, vector<ImageParticle*>* dst, const int dh, const int ds){
	for(int i=0; i<dst[ptidx].size(); i++){
		ImageParticle* p = dst[ptidx][i];
		int x = p->x;
		int y = p->y;
		if(x < 0 || y < 0 || x >= hsv->width || y >= hsv->height){
			p->weight=0;
		}else{
			int diffH = abs(cvGet2D(hsv, p->y, p->x).val[0] - hue);
			int diffS = abs(cvGet2D(hsv, p->y, p->x).val[1] - sat);
			int diffV = abs(cvGet2D(hsv, p->y, p->x).val[2] - val);
			if(diffH < 10 || diffH > 170){
				p->weight=10-diffH;
			}
			if(diffS > 180){
				p->weight=0;
			}
			if(diffS > 128){
				p->weight=0;
			}
		}
	}

	ImageParticle::resampleParticles(500, 10, dst[ptidx], dst[ptidx^1]);
	ImageParticle::drawParticles(h, dst[ptidx]);
	ImageParticle::deleteParticles(dst[ptidx]);
}


void MultiLocRayCast::process()
{
	//--- LINE / DISTANCE based LOCALIZATION ---
	cvCvtColor(img, hsv, CV_BGR2HSV);

	cvSmooth(hsv,hsv, CV_MEDIAN, 5,5);

	cvSplit(hsv, h, s, v, NULL);

	cvCanny(s, s, 50, 200);

	cvSmooth(s,s, CV_GAUSSIAN, 15,15);

	int maxI = MEASUREMENTS+1;
	float f = -PI/maxI;	

	vector<float> camPositionNao = motionProxy->getPosition("CameraBottom", SPACE_NAO, true); 

	for(int i=1; i<maxI; i++){
		CvPoint start = cvPoint(hsv->width/2, hsv->height-10);
		CvPoint target = rayTrace(s, 5, start, f*i, 0);
		if(target.x> 0 && target.y > 0 && target.x < hsv->width && target.y < hsv->height){			
			measurement[i-1] = realDistanceFromImage(target.x, target.y, camPositionNao);
		}
	}


	//--- PARTICLE BASED GOAL DETECTION ---
	blueDetector();
	yellowDetector();
	redDetector();

	//--- DETECTION ---
	if(ImageParticle::getVariance(imPtclsBlue[ptidx^1]) < 5000){
		lastBlueGoalImg = ImageParticle::getLocationEstimate(imPtclsBlue[ptidx^1]);
		seeBlueGoal = true;
	}else{
		seeBlueGoal = false;
	}

	if(ImageParticle::getVariance(imPtclsYellow[ptidx^1]) < 5000){
		lastYellowGoalImg = ImageParticle::getLocationEstimate(imPtclsYellow[ptidx^1]);
		seeYellowGoal = true;
	}else{
		seeYellowGoal = false;
	}

	if(ImageParticle::getVariance(imPtclsRed[ptidx^1]) < 1000){
		ImageParticle r = ImageParticle::getLocationEstimate(imPtclsRed[ptidx^1]);
		seeBall = true;
		vector<float> ballCoords = realFromImage(r.x, r.y, camPositionNao);
		lastBallPosition[0] = ballCoords[0];
		lastBallPosition[1] = ballCoords[1];
	}else{
		seeBall = false;
	}

	//--- LOCALIZATION ---
	evaluateParticles();

	translateParticles();

	NaoLocationParticle::resampleParticles(NPARTICLES, RAND_PARTICLES, ptcls[ptidx], ptcls[ptidx^1]);
	NaoLocationParticle::deleteParticles(ptcls[ptidx]);
	ptidx = ptidx ^ 1;

	NaoLocationParticle loc = NaoLocationParticle::getLocationEstimate(ptcls[ptidx]);
	lastOwnPosition[0] = loc.getX();
	lastOwnPosition[1] = loc.getY();
	lastOwnPosition[2] = loc.getTheta();
}