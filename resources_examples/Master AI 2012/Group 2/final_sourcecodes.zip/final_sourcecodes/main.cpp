#include <alcommon/albroker.h>
#include <alcommon/almodule.h>
#include <alcommon/alproxy.h>
#include <alcommon/albrokermanager.h>
#include <alcore/alptr.h>
#include <alcore/altypes.h>
#include <qi/os.hpp>

#include "StateMachine.h"
#include "imageprocessing/MultiLoc.h"
#include "imageprocessing/MultiLocRayCast.h"
#include "WalkToBallState.h"

#include <iostream>
#include <string>

using namespace std;
using namespace AL;

//#define STATEMACHINE_IS_REMOTE_OFF

#ifdef STATEMACHINE_IS_REMOTE_OFF

#ifdef _WIN32
#define ALCALL __declspec(dllexport)
#else
#define ALCALL
#endif

extern "C"
{


	ALCALL int _createModule( ALPtr<ALBroker> pBroker )
	{
		// init broker with the main broker inctance
		// from the parent executable
		ALBrokerManager::setInstance(pBroker->fBrokerManager.lock());
		ALBrokerManager::getInstance()->addBroker(pBroker);

		// create modules instance
		ALModule::createModule<StateMachine>(pBroker,"StateMachine");
		
		ALModule::createModule<MultiLocRayCast>(pBroker, "MultiLoc");

		pBroker->getProxy("MultiLoc")->callVoid("start");

		return 0;
	}

	ALCALL int _closeModule(  )
	{
		return 0;
	}

} // extern "C"

#else

void _terminationHandler( int signum )
{
  ALBrokerManager::getInstance()->killAllBroker();
  ALBrokerManager::kill();
  exit(0);
}

int usage( char* progName )
{
	std::cout << progName <<", a remote module of naoqi !" << std::endl

		<< "USAGE :" << std::endl
		<< "-b\t<ip> : binding ip of the server. Default is 127.0.0.1" << std::endl
		<< "-p\t<port> : binding port of the server. Default is 9559" << std::endl
		<< "-pip\t<ip> : ip of the parent broker. Default is 127.0.0.1" << std::endl
		<< "-pport\t<ip> : port of the parent broker. Default is 9559" << std::endl
		<< "-h\t: Display this help\n" << std::endl;
	return 0;
}

int main(int argc, char** argv){
	std::cout << "..::: starting StateMashine :::.." << std::endl;
	std::cout << "2012 GROUP 2 and GROUP 4" << std::endl << std::endl;

	int  i = 1;
	std::string brokerName = "stateMachine";
	std::string brokerIP = "127.0.0.1";
	int brokerPort = 0 ;
	// Default parent broker IP
	std::string parentBrokerIP = "127.0.0.1";
	// Default parent broker port
	int parentBrokerPort = 9559;

	// checking options
	while( i < argc ) {
		if ( argv[i][0] != '-' ) return usage( argv[0] );
		else if ( std::string( argv[i] ) == "-b" )        brokerIP          = std::string( argv[++i] );
		else if ( std::string( argv[i] ) == "-p" )        brokerPort        = atoi( argv[++i] );
		else if ( std::string( argv[i] ) == "-pip" )      parentBrokerIP    = std::string( argv[++i] );
		else if ( std::string( argv[i] ) == "-pport" )    parentBrokerPort  = atoi( argv[++i] );
		else if ( std::string( argv[i] ) == "-h" )        return usage( argv[0] );
		i++;
	}

	std::cout << "Try to connect to parent Broker at ip :" << parentBrokerIP
		<< " and port : " << parentBrokerPort << std::endl;
	std::cout << "Start the server bind on this ip :  " << brokerIP
		<< " and port : " << brokerPort << std::endl;

	ALPtr<ALBroker> pBroker = ALBroker::createBroker(brokerName, brokerIP, brokerPort, parentBrokerIP,  parentBrokerPort);
	pBroker->setBrokerManagerInstance(ALBrokerManager::getInstance());

	//--------------------------- INIT MODULES --------------------------------------------
	// e.g. ALModule::createModule<ALVisionTemplate>(pBroker, "ALVisionTemplate" );
	AL::ALPtr<StateMachine> sm = ALModule::createModule<StateMachine>(pBroker, "StateMachine");
	sm->getModuleStorage().setMultiLoc(ALModule::createModule<MultiLocRayCast>(pBroker, "MultiLoc"));
	sm->getModuleStorage().setNaoMotionModule(ALModule::createModule<NaoMotionModule>(pBroker, "NaoMotionModule"));
	
	//--------------------------- START MODULES (pCalls) ----------------------------------
	// e.g. pBroker->getProxy("ALVisionTemplate")->pCall("run");
	pBroker->getProxy("MultiLoc")->callVoid("start");
	
	//--------------------------- START STATE MACHINE --------------------------------------
	ALModule::createModule<StateMachine>(pBroker, "StateMachine");
	//pBroker->getProxy("StateMachine")->callVoid("start");

	pBroker.reset();

	std::cin.peek();	

	ALBrokerManager::getInstance()->killAllBroker();
	ALBrokerManager::kill();
	return 0;
}

#endif