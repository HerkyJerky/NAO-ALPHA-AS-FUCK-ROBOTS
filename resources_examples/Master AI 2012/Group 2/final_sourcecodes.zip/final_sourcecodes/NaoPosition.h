#ifndef NAOPOSITION_H
#define NAOPOSITION_H

class NaoPosition
{
private:
	float posX, posY, orientation;

public:
	NaoPosition() : posX(DEFAULT_X), posY(DEFAULT_Y), orientation(DEFAULT_T) {}

	static float const DEFAULT_X;
	static float const DEFAULT_Y;
	static float const DEFAULT_T;

	float getX() const;
	float getY() const;
	float getOrientation() const;

	void setX(float const x);
	void setY(float const y);
	void setOrientation(float const t);
};

#endif