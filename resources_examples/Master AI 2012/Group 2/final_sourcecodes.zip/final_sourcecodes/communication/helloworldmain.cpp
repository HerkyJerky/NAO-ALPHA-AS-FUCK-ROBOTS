/**
 * Copyright Aldebaran Robotics
 */

#ifndef _WIN32
#include <signal.h>
#endif

#include <alcore/alptr.h>
#include <alcommon/albroker.h>
#include <alcommon/almodule.h>
#include <alcommon/albrokermanager.h>
#include <alcommon/altoolsmain.h>

#include "alhelloworld.h"


#ifdef HELLOWORLD_IS_REMOTE_ON

#define ALCALL

#else

// when not remote, we're in a dll, so export the entry point
#ifdef _WIN32
#define ALCALL __declspec(dllexport)
#else
#define ALCALL
#endif

#endif

using namespace AL;

extern "C"
{

ALCALL int _createModule( AL::ALPtr<AL::ALBroker> pBroker )
{
  // init broker with the main broker instance
  // from the parent executable
  AL::ALBrokerManager::setInstance(pBroker->fBrokerManager.lock());
  AL::ALBrokerManager::getInstance()->addBroker(pBroker);

  // create module instances
  AL::ALPtr<ALHelloWorld> hw = AL::ALModule::createModule<ALHelloWorld>(pBroker,"ALHelloWorld" );

  ALPtr<ALBroker> pBroker2 = ALBroker::createBroker("helloWorld2", "192.168.1.3", 50410, "192.168.2.1",  9559);

  AL::ALBrokerManager::setInstance(pBroker2->fBrokerManager.lock());
  AL::ALBrokerManager::getInstance()->addBroker(pBroker2);
  AL::ALModule::createModule<ALHelloWorld>(pBroker2,"ALHelloWorld2" );

  hw->ping2();
  hw->helloWorld(pBroker2);

  return 0;
}

ALCALL int _closeModule(  )
{
  return 0;
}

} // extern "C"


#ifdef COMMUNICATION_IS_REMOTE_ON


int main(int argc, char *argv[] )
{
  // pointer on createModule
  TMainType sig;
  sig = &_createModule;

  // call main
  ALTools::mainFunction("helloworld",argc, argv,sig);

}

#endif
