/**
 * Copyright Aldebaran Robotics
 */

#ifndef ALHelloWorld_H
#define ALHelloWorld_H

#include <alcore/alptr.h>
#include <alcommon/almodule.h>
#include <vector>
using namespace std;

namespace AL
{
  class ALBroker;
}

/**
 * An simple example
 */


class ALHelloWorld : public AL::ALModule
{

  public:

    /**
     * Default Constructor.
     */
    ALHelloWorld(AL::ALPtr<AL::ALBroker> pBroker, const std::string& pName );

    /**
     * Destructor.
     */
    virtual ~ALHelloWorld();

    /**
     * helloWorld, print "hello world!" to the ALLogger module
     */
    void helloWorld( AL::ALPtr<AL::ALBroker> );

	void ping2();
	void pong(vector<float> const &);
};
#endif // ALHelloWorld_H

