/**
 * Copyright Aldebaran Robotics
 */
#include "alhelloworld.h"

#include <iostream>
#include <alcommon/alproxy.h>
#include <alcore/alptr.h>
#include <alcommon/albroker.h>
#include <alcommon/almodule.h>
#include <alproxies/alloggerproxy.h>
#include <alproxies/altexttospeechproxy.h>
#include <alproxies/almemoryproxy.h>
#include <alproxies/almotionproxy.h>

#include <vector>

using namespace std;
using namespace AL;

//______________________________________________
// constructor
//______________________________________________
ALHelloWorld::ALHelloWorld(ALPtr<ALBroker> pBroker, const std::string& pName ): ALModule(pBroker, pName )
{
 // Describe the module here
  setModuleDescription( "An hello world app." );

  functionName( "ping2", getName(),  "says something" );
  BIND_METHOD( ALHelloWorld::ping2 );

  functionName( "pong", getName(),  "weird stuff!" );
  addParam("angles", "LArm angles");
  BIND_METHOD( ALHelloWorld::pong);
}

//______________________________________________
// destructor
//______________________________________________
ALHelloWorld::~ALHelloWorld()
{

}

/**
 * helloworld Function
 */
void ALHelloWorld::helloWorld(AL::ALPtr<AL::ALBroker> pBroker)
{
  try
  {
	  AL::ALPtr<ALMemoryProxy> memProxy = AL::ALPtr<ALMemoryProxy>( new ALMemoryProxy( getParentBroker() ));
	  AL::ALPtr<ALMotionProxy> motion = getParentBroker()->getMotionProxy();

	  while(true)
	  {
		memProxy->getDataOnChange("FrontTactilTouched", 23);
		pBroker->getProxy("ALHelloWorld2")->callVoid("ping2");
		pBroker->getProxy("ALHelloWorld2")->callVoid("pong", motion->getAngles("LArm", true));
	  }

  }catch( ALError& e)
  {
	  std::cout << e.what() << std::endl;
  }
}

void ALHelloWorld::ping2(){
  try
  {
	  AL::ALPtr<ALTextToSpeechProxy> tts = AL::ALPtr<ALTextToSpeechProxy>( new ALTextToSpeechProxy( getParentBroker() ));
	  tts->say("Order received!");
  }catch( ALError& e)
  {
	  std::cout << e.what() << std::endl;
  }
}

void ALHelloWorld::pong(vector<float> const & angles){
  try
  {
	  AL::ALPtr<ALMotionProxy> motion = getParentBroker()->getMotionProxy();
	  motion->setStiffnesses("Body", 1.0);
	  motion->setAngles("LArm", angles, 0.2f);
	  
  }catch( ALError& e)
  {
	  std::cout << e.what() << std::endl;
  }
}




