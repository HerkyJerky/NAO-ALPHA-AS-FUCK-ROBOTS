#ifndef MODULE_STORAGE
#define MODULE_STORAGE

#include <alcore/alptr.h>
#include "imageprocessing/MultiLoc.h"
#include "motion/NaoMotionModule.h"

class ModuleStorage
{
private:
	AL::ALPtr<MultiLoc> loc;
	AL::ALPtr<NaoMotionModule> nmm;

public:
	void setMultiLoc(AL::ALPtr<MultiLoc>);
	AL::ALPtr<MultiLoc> getMultiLoc(void) const;
	void setNaoMotionModule(AL::ALPtr<NaoMotionModule>);
	AL::ALPtr<NaoMotionModule> getNaoMotionModule(void) const;

	ModuleStorage(void);
};

#endif