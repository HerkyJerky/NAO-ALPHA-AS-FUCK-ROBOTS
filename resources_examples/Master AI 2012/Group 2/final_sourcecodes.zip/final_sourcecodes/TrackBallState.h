#ifndef TRACK_BALL_STATE
#define TRACK_BALL_STATE

#include "State.h"
#include "imageprocessing/MultiLoc.h"

#include <alproxies/alledsproxy.h>
#include <alcore/alptr.h>

class TrackBallState : public State
{
public:
	TrackBallState(StateMachine* s);
	virtual cStates run(void);

private:
	virtual void init(void);
	virtual void exit(void);
	AL::ALPtr<AL::ALLedsProxy> proxy;
};
#endif