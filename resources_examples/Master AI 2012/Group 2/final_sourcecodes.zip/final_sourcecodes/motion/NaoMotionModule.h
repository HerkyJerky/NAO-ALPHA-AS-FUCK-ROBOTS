#include <alcommon/almodule.h>
#include <alcommon/albroker.h>
#include <alcore/alptr.h>

using namespace AL;

class NaoMotionModule : public ALModule
{
public:
	NaoMotionModule(ALPtr<ALBroker> pBroker, const std::string& pName);

	void kick(void);
	void stiffnessOnPoseInit(void);
	void poseInit(void);
	void stiffnessOn(void);
	void stiffnessOff(void);
	void walkTo(float, float, float);
	void raiseHead(void);
	void doKick(void);
	void rotateHead(float, bool);
};