#ifndef PENALIZED_STATE
#define PENALIZED_STATE
#include "State.h"
#include <alproxies/alledsproxy.h>
#include <alcore/alptr.h>

class PenalizedState : public State
{
public:
	PenalizedState(StateMachine*);
	virtual cStates run(void);

private:
	virtual void init(void);
	virtual void exit(void);
	AL::ALPtr<AL::ALLedsProxy> proxy;
};
#endif