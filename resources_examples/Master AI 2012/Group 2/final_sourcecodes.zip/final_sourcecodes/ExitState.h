#ifndef EXIT_STATE
#define EXIT_STATE
#include "State.h"
#include <alproxies/alledsproxy.h>
#include <alcore/alptr.h>

class ExitState : public State
{
public:
	ExitState(StateMachine*);
	virtual cStates run(void);

private:
	virtual void init(void);
	virtual void exit(void);
	AL::ALPtr<AL::ALLedsProxy> proxy;
};
#endif