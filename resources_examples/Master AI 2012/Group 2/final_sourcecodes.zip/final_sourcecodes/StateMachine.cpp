#include "StateMachine.h"
#include "PenalizedState.h"
#include "WalkToBallState.h"
#include "ExitState.h"
#include "State.h"

#include <alcommon/almodule.h>
#include <alcore/altypes.h>
#include <alcore/alptr.h>
#include <alproxies/almemoryproxy.h>
#include <alcommon/alproxy.h>
#include <qi/os.hpp>

#include <iostream>
using namespace std;



StateMachine::StateMachine(AL::ALPtr<AL::ALBroker> pBroker, const std::string& pName) : AL::ALModule(pBroker, pName), bPenalized(true)
{
	setModuleDescription("This is the state machine module to play soccer.");

	functionName( "start", getName() ,  "Start the state machine. Make the NAO play soccer..." );
	BIND_METHOD(StateMachine::start);

	functionName( "checkForChestButton", getName() ,  "Check for the Chest Button to be pressed... " );
	BIND_METHOD(StateMachine::checkForChestButton);
}

void StateMachine::init(){
	getProxy( getName() )->pCall("checkForChestButton");

	this->addState(PENALIZED);
	this->addState(TRACKBALL);
	this->addState(CLOSE);
}

StateMachine::~StateMachine(void)
{
	for(unsigned int i = 0; i < states.size(); i++)
	{
		delete states[i];
	}
}

void StateMachine::addState(cStates c)
{
	State* s;

	switch(c)
	{
	case LOCALIZE: break;
	case FINDBALL: break;
	case TRACKBALL: s = new WalkToBallState(this); break;
	case PENALIZED: s = new PenalizedState(this); break;
	case CLOSE: s = new ExitState(this); break;
	}

	states.push_back(s);
}

bool const StateMachine::isPenalized(void){
	return bPenalized;
}

void StateMachine::start(void)
{
	cStates nextState = PENALIZED;
	while(nextState != CLOSE){
		nextState = states[nextState]->run();
	}

	states[nextState]->run();
}

void StateMachine::checkForChestButton(void)
{
	cout << "Started checking for Front Tactil ... " << endl;
	AL::ALPtr<AL::ALMemoryProxy> memProxy = AL::ALPtr<AL::ALMemoryProxy>( new AL::ALMemoryProxy(this->getParentBroker()) );

	while(true)
	{
		memProxy->getDataOnChange("FrontTactilTouched", 23);
		this->switchPenalized();
		qi::os::msleep(1000);
	}

}

void StateMachine::switchPenalized(void)
{
	this->bPenalized = !this->bPenalized;
}

ModuleStorage& StateMachine::getModuleStorage(void)
{
	return this->m;
}