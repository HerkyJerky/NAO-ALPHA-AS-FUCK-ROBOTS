#include "ModuleStorage.h"

ModuleStorage::ModuleStorage(void)
{
}


void ModuleStorage::setMultiLoc(AL::ALPtr<MultiLoc> ptr)
{
	if(this->loc.get() == 0)
	{
		this->loc = ptr;
	}
}

void ModuleStorage::setNaoMotionModule(AL::ALPtr<NaoMotionModule> ptr)
{
	if(this->nmm.get() == 0)
	{
		this->nmm = ptr;
	}
}

AL::ALPtr<MultiLoc> ModuleStorage::getMultiLoc(void) const
{
	return this->loc;
}

AL::ALPtr<NaoMotionModule> ModuleStorage::getNaoMotionModule(void) const
{
	return this->nmm;
}