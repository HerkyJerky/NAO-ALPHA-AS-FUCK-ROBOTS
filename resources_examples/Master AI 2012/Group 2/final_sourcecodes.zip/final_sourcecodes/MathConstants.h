#ifndef MATH_CONSTANTS
#define MATH_CONSTANTS

static float const PI = 3.141592653f;
static float const TO_RAD = PI/180;
static float const TO_DEG = 1 / TO_RAD;

#endif