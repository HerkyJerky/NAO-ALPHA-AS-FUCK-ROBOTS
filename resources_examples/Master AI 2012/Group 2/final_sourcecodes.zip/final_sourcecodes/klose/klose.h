/**
* Copyright Aldebaran Robotics
*/

#ifndef Klose_H
#define Klose_H

#include <alcore/alptr.h>
#include <alcommon/almodule.h>
#include <althread/almutex.h>

namespace AL
{
	class ALBroker;
}

/**
* Klose - the Knowledge Loaded Object for Soccer Environments
*/
class Klose : public AL::ALModule
{

public:

	/**
	* Default Constructor.
	*/
	Klose(AL::ALPtr<AL::ALBroker> pBroker, const std::string& pName );

	/**
	* Destructor.
	*/
	virtual ~Klose();

	/**
	* Setter for some value managed by Klose
	*/
	void setTheValue( const int& n );

	/**
	* Getter for some value managed by Klose
	*/
	int getTheValue();

	enum playerModes{
		ATTACK, ATTACK_NO_BALL, DEFEND
	}

	enum robotStates{
		INITIAL, READY, SET, PLAYING, PENALIZED, FINISHED
	}

private:
	AL::ALPtr<AL::ALMutex> mutex;
	int theValue;

	// ME
	char* location1;
	// MATE
	char* location2;
	char* location3;
	char* location4;
	char* locationBall;

	float orientation1;
	float orientation2;
	float orientation3;
	float orientation4;

	float velocity1;
	float velocity2;
	float velocity3;
	float velocity4;
	float velocityBall;

	playerMode currentMode1;
	playerMode currentMode2;

	robotState currentSate;

	int* targetPosition1;
	int* targetPosition2;

	bool teamColorIsBlue;
	bool isKickoffTeam;
	bool isGoalie;
};
#endif // Klose_H

