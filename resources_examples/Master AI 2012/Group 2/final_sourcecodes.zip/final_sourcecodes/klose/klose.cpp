/**
 * Copyright Aldebaran Robotics
 */
#include "klose.h"

#include <iostream>
#include <alcommon/alproxy.h>
#include <alcore/alptr.h>
#include <alcommon/albroker.h>
#include <alcommon/almodule.h>
#include <alproxies/alloggerproxy.h>
#include <althread/almutex.h>

using namespace AL;

//______________________________________________
// constructor
//______________________________________________
Klose::Klose(ALPtr<ALBroker> pBroker, const std::string& pName ): ALModule(pBroker, pName )
{
	this->mutex = ALMutex::createALMutex();

  // Describe the module here
  setModuleDescription( "Knowledge Loaded Object for Soccer Environments. The central data structure to manage knowledge of the soccer game." );

  // Define callable methods with there description
  functionName("getTheValue", getName(), "Get the value managed by Klose");
  BIND_METHOD( Klose::getTheValue );

  functionName( "setTheValue", getName(),  "Set the value managed by Klose" );
  addParam("n", "the new value of theValue");
  BIND_METHOD( Klose::setTheValue );
}

//______________________________________________
// destructor
//______________________________________________
Klose::~Klose()
{

}


//______________________________________________
// functionality
//______________________________________________
void Klose::setTheValue(const int& n){
	this->theValue = n;
}

int Klose::getTheValue(){
	return this->theValue;
}

