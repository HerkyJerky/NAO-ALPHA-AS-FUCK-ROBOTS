#ifndef STATE_MACHINE
#define STATE_MACHINE
#include "State.h"
#include "ModuleStorage.h"

#include <vector>

#include <alcommon/almodule.h>
#include <alcore/altypes.h>
#include <alcore/alptr.h>

using namespace std;

enum cStates;

class StateMachine : public AL::ALModule
{
private:
	vector<State*> states;
	bool bPenalized;
	ModuleStorage m;


public:
	StateMachine(AL::ALPtr<AL::ALBroker> pBroker, const std::string& pName);
	~StateMachine(void);
	virtual void init();

	void start(void);
	void addState(cStates c);
	bool const isPenalized(void);
	void switchPenalized(void);

	void checkForChestButton(void);

	ModuleStorage& getModuleStorage(void);
};
#endif