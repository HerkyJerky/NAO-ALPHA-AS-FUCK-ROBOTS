#include "TrackBallState.h"
#include "StateMachine.h"
#include <iostream>
using namespace std;

TrackBallState::TrackBallState(StateMachine* s) : State(s)
{
}

cStates TrackBallState::run()
{
	
	this->init();

	while(!this->sm->isPenalized())
	{
		cout << this->sm->getModuleStorage().getMultiLoc()->getBallLocation() << endl;
		cout << this->sm->getModuleStorage().getMultiLoc()->getOwnLocation() << endl;
	}

	this->exit();

	cout << "Transitioning to PenalizedState ..." << endl;
	return PENALIZED;
}

void TrackBallState::init(void)
{
	cout << "Initializing TrackBallState ... " << endl;
	this->proxy = AL::ALPtr<AL::ALLedsProxy>( new AL::ALLedsProxy(this->sm->getParentBroker()) );
	proxy->fadeRGB("FaceLeds", 0x00FF00, 1);
}

void TrackBallState::exit(void)
{
	cout << "Exiting TrackBallState ... " << endl;
	proxy->setIntensity("FaceLeds", 0);
}