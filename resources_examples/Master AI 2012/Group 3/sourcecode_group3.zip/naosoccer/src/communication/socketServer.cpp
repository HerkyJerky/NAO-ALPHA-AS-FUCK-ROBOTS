/* 
 * File:   socketServer.cpp
 * Author: decebal
 * 
 * Created on January 15, 2012, 12:52 AM
 */

#include "socketServer.h"


socketServer::socketServer() {
}

void socketServer::initializeParameters(int port,bool *stopComServer){
     stopCommunicationServer=stopComServer;
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = port;
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
}

void socketServer::start(){
     while (!(*stopCommunicationServer)) {
         newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);
         if (newsockfd < 0) error("ERROR on accept");
         pid = fork();
         if (pid < 0) error("ERROR on fork");
         if (pid == 0)  {
             close(sockfd);
             doStuff(newsockfd);
             exit(0);
         }
                else close(newsockfd);
     } 
     
}

void socketServer::doStuff(int sock)
{
   int n;
   char buffer[256];
      
   bzero(buffer,256);
   n = read(sock,buffer,255);
   if (n < 0) error("ERROR reading from socket");
   
   char toSend[40];
   Locator *loc = Locator::getInstance();
   switch (buffer[0])
   {
       case '1' : sprintf(toSend,"%g",loc->getMyX());
       break;
       case '2' : sprintf(toSend,"%g",loc->getMyY());
       break;
       case '3' : sprintf(toSend,"%g",loc->getMyAngle());
       break;
       case '4' : sprintf(toSend,"%g",loc->getBallX());
       break;
       case '5' : sprintf(toSend,"%g",loc->getBallY());
       break;   
       default : sprintf(toSend,"notcommand");
   }

   n = write(sock,toSend,strlen(toSend));
   if (n < 0) error("ERROR writing to socket");
}

void socketServer::error(const char *msg)
{
    std::cout << msg<< std::endl;
    //exit(1);
}

socketServer::~socketServer() {
    close(sockfd);
}

