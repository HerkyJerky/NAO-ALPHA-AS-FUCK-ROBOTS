/* 
 * File:   socketClient.h
 * Author: decebal
 *
 * Created on January 15, 2012, 12:53 AM
 */

#ifndef SOCKETCLIENT_H
#define	SOCKETCLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <netdb.h> 
#include <iostream>



class socketClient {
    
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;    
    
public:
    static socketClient* create();
    static socketClient* getInstance();
    void initializeParameters(char*,int);
    double getPartnerBallX();
    double getPartnerBallY();
    double getPartnerX();
    double getPartnerY();
    double getPartnerAngle();
    void error(const char *);
    virtual ~socketClient();
private:
    char* askPartner(char*);
    socketClient();
    static socketClient* pinstance;
};

#endif	/* SOCKETCLIENT_H */

