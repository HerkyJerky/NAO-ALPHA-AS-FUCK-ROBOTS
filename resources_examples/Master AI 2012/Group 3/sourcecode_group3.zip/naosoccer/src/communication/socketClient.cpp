/* 
 * File:   socketClient.cpp
 * Author: decebal
 * 
 * Created on January 15, 2012, 12:53 AM
 */

#include "socketClient.h"

socketClient* socketClient::pinstance = NULL;

socketClient* socketClient::create() {
    if (pinstance == NULL) {
        pinstance = new socketClient();
    }
    return pinstance;
}

socketClient::socketClient() {
}

void socketClient::initializeParameters(char* host, int port){

    portno = port;
    server = gethostbyname(host);
}

socketClient* socketClient::getInstance() {
    return create();
}

char* socketClient::askPartner(char buffer[256]){
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) error("ERROR opening socket");
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);    
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) error("ERROR connecting");
    n = write(sockfd,buffer,strlen(buffer));
    if (n < 0) error("ERROR writing to socket");
    char bufferRead[256];
    bzero(bufferRead,256);
    n = read(sockfd,bufferRead,255);
    if (n < 0) error("ERROR reading from socket");
    close(sockfd);
    return bufferRead;
}

double socketClient::getPartnerBallX(){
    char buffer[256];
    sprintf(buffer,"4");
    return atof(askPartner(buffer));
}

double socketClient::getPartnerBallY(){
    char buffer[256];
    sprintf(buffer,"5");
    return atof(askPartner(buffer));
}

double socketClient::getPartnerX(){
    char buffer[256];
    sprintf(buffer,"1");
    return atof(askPartner(buffer));
}

double socketClient::getPartnerY(){
    char buffer[256];
    sprintf(buffer,"2");
    return atof(askPartner(buffer));
}

double socketClient::getPartnerAngle(){
    char buffer[256];
    sprintf(buffer,"3");
    return atof(askPartner(buffer));
}

void socketClient::error(const char *msg)
{
   perror(msg);
   //exit(1);
}

socketClient::~socketClient() {
}

