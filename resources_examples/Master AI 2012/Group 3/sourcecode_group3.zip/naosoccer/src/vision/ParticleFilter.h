#ifndef _PARTICLEFILTER_H
#define	_PARTICLEFILTER_H

#include <math.h>
#include <string>
#include <vector>

struct Particle {
    double x, y, a, value;
};

struct Spot {
    double x, y;
    int type;
};
const int SPOT_LINE = 0;
const int SPOT_GOAL_Y = 1;
const int SPOT_GOAL_B = 2;

const int FIELDTYPE_CROSSINGS = 0;
const int FIELDTYPE_LINES_HALF = 1;
const int FIELDTYPE_LINES_FULL = 2;

double getAngle(double x1, double y1, double x2, double y2);

double getDist(double x1, double y1, double x2, double y2);

class ParticleFilter {
public:
    ParticleFilter(int amount, int fieldtype);
    virtual ~ParticleFilter();
    void evaluate(double* avgX,double* avgY,double* avgA);
    void debugDraw(std::string path);
    Spot* debugSpots(double x, double y, double angle, int* size);
    void setSpots(std::vector<Spot*> input);
    void move(double x, double y, double angle);
    double* grid;
private:
    Spot* field;
    std::vector<Spot*> spots;
    Particle* particles;
    int particleSize, fieldSize, spotSize;
    void definitions();
    double posNoise();
    double angleNoise();
    int iteration;
    double avgValue;
    int fieldType;
    time_t startClock;
};

#endif	/* _PARTICLEFILTER_H */

