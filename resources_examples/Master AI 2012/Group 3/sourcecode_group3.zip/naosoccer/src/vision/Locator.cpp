/* 
 * File:   Locator.cpp
 * Author: Christian Andrich
 * 
 * Created on 2. November 2011, 12:27
 */

#include "Locator.h"
#include <pthread.h>
#include <opencv/cxcore.h>

Locator* Locator::instance = NULL;

// Brightness, Contrast, Saturation, Hue, Red, Blue, ExposureC, Exposure, Gain
//int Locator::cameraValues[9] = {100, 64, 255, 0, 64, 160, 0, 280, 56}; // Aachen
int Locator::cameraValues[9] = {-1, 0, 0, 0, 0, 0, 0, 0, 0}; // Webots
//int Locator::cameraValues[9] = {100, 64, 255, 0, 72, 163, 0, 510, 40}; // Maastricht

Locator* Locator::create(const char* ip, int port, int type, int camID, RobotStatus* robotStatus) {
    if (instance == NULL) {
        instance = new Locator(ip, port, type, camID, robotStatus);
    }
    return instance;
}

void* WorkerCode(void* arguments) {
    Locator* me = (Locator*) arguments;

    IplImage* naoImage = cvCreateImageHeader(cvSize(Locator::IMAGE_W, Locator::IMAGE_H), IPL_DEPTH_8U, 3);

    bool readyToReset = false;
    int iter = 0;
    while (me->running) {
		
        if (readyToReset) {
            if (!me->robotStatus->isFallen() && !me->robotStatus->isPenalized()) {
                readyToReset = false;
                me->resetPF();
            }
        } else if (me->robotStatus->isFallen() || me->robotStatus->isPenalized()) {
            readyToReset = true;
        }

        //clock_t startClock = clock();

        AL::ALValue img = me->camProxy.getImageRemote(me->clientName);
        naoImage->imageData = (char*) img[6].GetBinary();
        if (me->camID == 0) {
            me->camParam = me->motionProxy.getPosition("CameraTop", 1, true);
        } else {
            me->camParam = me->motionProxy.getPosition("CameraBottom", 1, true);
        }

        //cvSaveImage("/home/seddy/Desktop/particle/input.jpg", naoImage);

        cvCvtColor(naoImage, me->hsvImage, CV_BGR2HSV);

        while (!me->spots.empty()) {
            Spot* trash = me->spots.back();
            me->spots.pop_back();
            delete trash;
        }

        if (me->robotStatus != NULL) {
            me->searchBall = me->robotStatus->isSearchBall();
        }


        if (me->cameraValues[0] != -1) {
            me->extractField();
        }
        me->detectBall();
        me->detectGoal();

        if ((me->seeBall && me->searchBall) || (me->seeGoal && (!(me->searchBall)))) {
            me->searchLeft = false;
            me->searchRight = false;
            //printf("The Locator will now look at the Item.\n");
            if (!readyToReset)
                me->lookAtItem();
        } else {
            if (!readyToReset)
                me->searchForItem();
        }

        /*if ((iter++) % 10 == 0) {
            me->pointAlgorithm();
            me->pf->setSpots(me->spots);
            me->pf->evaluate(&(me->myX), &(me->myY), &(me->myAngle));
            me->relBallX = me->myX + sin(me->myAngle + me->robotStatus->getAngleToBall()) * me->robotStatus->getDistanceToBall();
            me->relBallY = me->myY - cos(me->myAngle + me->robotStatus->getAngleToBall()) * me->robotStatus->getDistanceToBall();
            //me->pf->debugDraw("/home/seddy/Desktop/particle/");
        }*/
        /*if ((++iter) % 5 == 0) {
            me->motionProxy.walkTo(0.15f, 0.0f, 0.0f);
            me->pf->move(0.15, 0.0, 0.0);
        } else {
            me->pf->move(0.0, 0.0, 0.0);
        }
        me->pf->evaluate();
        me->pf->debugDraw("/home/seddy/Desktop/particle/");*/

        //me->pf->setSpots(me->spots, me->spotsSize);
        //me->pf->move(0.0, 0.0, 0.0);
        //me->pf->evaluate();
        //me->pf->debugDraw("/home/seddy/Desktop/particle/");

        //cvSaveImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/result.jpg", naoImage);

        //printf("time needed: %fs\n", (double) (clock() - startClock) / (double) CLOCKS_PER_SEC);

        //me->detectBall(naoImage);
        //me->detectGoal(naoImage);
        //usleep(1000000);

        /*printf("ball: %5.2f|%5.2f, goalB: %5.2f|%5.2f, goalY: %5.2f|%5.2f\n",
            me->robotStatus->getDistanceToBall(),me->robotStatus->getAngleToBall(),
            me->robotStatus->getDistanceToGoal(true),me->robotStatus->getAngleToGoal(true),
            me->robotStatus->getDistanceToGoal(false),me->robotStatus->getAngleToGoal(false));
         */
    }

    cvReleaseImage(&naoImage);

    return NULL;
}

Locator::Locator() : camProxy("127.0.0.1", 9559), motionProxy("127.0.0.1", 9559), walkMotionProxy("127.0.0.1", 9559) {

    size = cvSize(IMAGE_W, IMAGE_H);
    hsvImage = cvCreateImage(size, IPL_DEPTH_8U, 3);
}

Locator::Locator(const char* ip, int port, int type, int camID, RobotStatus* robotStatus) : camProxy(ip, port), motionProxy(ip, port), walkMotionProxy(ip, port) {
    this->type = type;
    this->camID = camID;
    this->robotStatus = robotStatus;
    searchLeft = false;
    searchRight = false;
    seeBall = false;

    motionProxy.stiffnessInterpolation("HeadYaw", 1.0f, 1.0f);
    motionProxy.stiffnessInterpolation("HeadPitch", 1.0f, 1.0f);

    pf = NULL;
    resetPF();
    // pf->debugDraw("/home/seddy/Desktop/particle/");

    clientName = camProxy.subscribe("1", AL::kQVGA, AL::kBGRColorSpace, 30);
    if (camID == 0) camID = 1;
    else camID = 0;
    changeCam();
    size = cvSize(IMAGE_W, IMAGE_H);
    hsvImage = cvCreateImage(size, IPL_DEPTH_8U, 3);
    running = true;
    pthread_create(&worker, NULL, WorkerCode, (void*) this);
}

void Locator::resetPF() {
    if (pf != NULL)
        delete pf;
    pf = new ParticleFilter(2000, type);
}

void Locator::detectBall() {

    //IplImage* grayImage = cvCreateImage(size, IPL_DEPTH_8U, 1);
    //uchar* atGray;
    //cvGetRawData(grayImage, (uchar**) & atGray);

    uchar* atFrame;
    cvGetRawData(hsvImage, (uchar**) & atFrame);
    uchar* max = atFrame + size.width * (size.height - 1) * 3;

    int atX = 0, atY = 0, x = 0, y = 0, num = 0;

    while (atFrame < max) {
        if (*(atFrame) < 20 && *(atFrame + 1) > 230 && *(atFrame + 2) > 220) {
            x += atX;
            y += atY;
            num++;
            //*atGray = 255;
        }// else *atGray = 0;
        atX++;
        if (atX > size.width) {
            atX -= size.width;
            atY++;
        }
        atFrame += 3;
        //atGray++;
    }



    //cvCvtColor(hsvImage, hsvImage, CV_HSV2BGR);

    /*if (num > 3) {
        printf("Ball: %10.7fm\n", getDistance(y / num));
        cvCircle(hsvImage, cvPoint(x / num, y / num), 5, CV_RGB(0, 0, 0), 10);
        //cvCircle(hsvImage, cvPoint(x / num, y / num), 2, CV_RGB(0, 0, 255), 2);
    } else {
        printf("Ball: away\n");
    }*/

    //cvSaveImage("/home/seddy/Desktop/particle/ball.jpg", hsvImage);
    //cvSaveImage("/home/seddy/Desktop/particle/gray.jpg", grayImage);

    seeBall = num > 3;

    if (seeBall) {
        ballX = x / num;
        ballY = y / num;
        if (robotStatus != NULL) {
            robotStatus->setDistanceToBall(getDistance(ballY));
            robotStatus->setAngleToBall(getAngle(ballX, true));
        }
    } else {
        robotStatus->setAngleToBall(100.0);
    }

    if (robotStatus != NULL) {

        robotStatus->setSeesBall(seeBall);
    }

}

void Locator::detectGoal() {
    uchar* atFrame;
    cvGetRawData(hsvImage, (uchar**) & atFrame);
    uchar* max = atFrame + size.width * (size.height - 1) * 3;
    uchar* max2 = atFrame + size.width * (size.height - 1) * 3;

    if (robotStatus != NULL)
        blueGoal = robotStatus->getTargetGoal();

    int atX = 0, atY = 0;
    seeGoal = false;

    while (atFrame < max) {
        if (atFrame < max2 && *(atFrame) < 130 && *(atFrame) > 105 && *(atFrame + 1) > 192) {
            int i = 0, imax = (int) spots.size();
            bool replace = false;
            for (; i < imax; i++) {
                if (spots[i ]->type == -SPOT_GOAL_B) {
                    if (abs(spots[i]->x - atX) < 150) {
                        if (spots[i]->y < atY) {
                            replace = true;
                        }
                        break;
                    }
                }
            }
            if (i == imax) {
                Spot* spot = new Spot();
                spot->x = atX;
                spot->y = atY;
                spot->type = -SPOT_GOAL_B;
                spots.push_back(spot);
            } else if (replace) {
                spots[i]->x = atX;
                spots[i]->y = atY;
            }
        }
        if (atFrame < max2 && *(atFrame) < 40 && *(atFrame) > 30 && *(atFrame + 1) > 00 && *(atFrame + 2) > 180) {
            int i = 0, imax = (int) spots.size();
            bool replace = false;
            for (; i < imax; i++) {
                if (spots[i ]->type == -SPOT_GOAL_Y) {
                    if (abs(spots[i ]->x - atX) < 150) {
                        if (spots[i ]->y < atY) {
                            replace = true;
                        }
                        break;
                    }
                }
            }
            if (i == imax) {
                Spot* spot = new Spot();
                spot->x = atX;
                spot->y = atY;
                spot->type = -SPOT_GOAL_Y;
                spots.push_back(spot);
            } else if (replace) {
                spots[i ]->x = atX;
                spots[i ]->y = atY;
            }
        }
        atFrame += 3;
        atX++;
        if (atX > size.width) {
            atX -= size.width;
            atY++;
        }
    }

    spotsSize = ((int) spots.size());
    double gbx = 0.0, gby = 0.0, gyx = 0.0, gyy = 0.0;
    int gb = 0, gy = 0;
    for (int i = 0; i < spotsSize; i++) {
        if (spots[i]->type == -SPOT_GOAL_B) {
            spots[i]->type = SPOT_GOAL_B;
            gb++;
            gbx += spots[i]->x;
            gby += spots[i]->y;
        } else if (spots[i]->type == -SPOT_GOAL_Y) {
            spots[i]->type = SPOT_GOAL_Y;
            gy++;
            gyx += spots[i]->x;
            gyy += spots[i]->y;
        }
        spots[i]->x = getDistance(spots[i]->y);
        spots[i]->y = getAngle(spots[i]->x, true);
    }
    if (robotStatus != NULL) {
        robotStatus->setSeesGoalB(gb > 0);
        robotStatus->setSeesGoalY(gy > 0);
        if (gb > 0) {
            robotStatus->setDistanceToGoalB(getDistance(gby / (double) gb));
            robotStatus->setAngleToGoalB(getAngle(gbx / (double) gb, true));
            if (blueGoal) {
                seeGoal = true;
                goalX = gbx / (double) gb;
                goalY = gby / (double) gb;
            }
        } else {
            robotStatus->setAngleToGoalB(100.0);
        }
        if (gy > 0) {
            robotStatus->setDistanceToGoalY(getDistance(gyy / (double) gy));
            robotStatus->setAngleToGoalY(getAngle(gyx / (double) gy, true));
            if (!blueGoal) {
                seeGoal = true;
                goalX = gyx / (double) gy;
                goalY = gyy / (double) gy;
            }
        } else {
            robotStatus->setAngleToGoalY(100.0);
        }
    }
    //printf("goal: %d,%d,%d\n", seeGoal ? 1 : 0, goalX, goalY);

}

Locator::~Locator() {

    running = false;
    pthread_join(worker, NULL);
    camProxy.unsubscribe("1");
    cvReleaseImage(&hsvImage);
    delete pf;
}

void Locator::takeImages(const char* ip, int port, int amount, int add, int camID) {
    AL::ALVideoDeviceProxy camProxy(ip, port);
    std::string clientName = camProxy.subscribe("1", AL::kVGA, AL::kBGRColorSpace, 30);

    camProxy.setParam(AL::kCameraSelectID, camID);
    camProxy.setParam(AL::kCameraAutoWhiteBalanceID, 0);
    camProxy.setParam(AL::kCameraAutoGainID, 0);
    camProxy.setParam(AL::kCameraAutoExpositionID, 0);
    camProxy.setParam(AL::kCameraBrightnessID, cameraValues[0]);
    camProxy.setParam(AL::kCameraContrastID, cameraValues[1]);
    camProxy.setParam(AL::kCameraSaturationID, cameraValues[2]);
    camProxy.setParam(AL::kCameraHueID, cameraValues[3]);
    camProxy.setParam(AL::kCameraRedChromaID, cameraValues[4]);
    camProxy.setParam(AL::kCameraBlueChromaID, cameraValues[5]);
    camProxy.setParam(AL::kCameraExposureCorrectionID, cameraValues[6]);
    camProxy.setParam(AL::kCameraExposureID, cameraValues[7]);
    camProxy.setParam(AL::kCameraGainID, cameraValues[8]);

    IplImage* frame = cvCreateImageHeader(cvSize(IMAGE_W, IMAGE_H), IPL_DEPTH_8U, 3);

    char buffer [256];

    for (int i = 0; i < amount; i++) {

        AL::ALValue img = camProxy.getImageRemote(clientName);
        frame->imageData = (char*) img[6].GetBinary();

        // sprintf(buffer, "/home/seddy/Desktop/field/%03d.jpg", i + add);
        cvSaveImage(buffer, frame);
#ifdef __linux__
        sleep(1);
#elif _WIN32
        Sleep(1000);
#endif
    }

    camProxy.unsubscribe("1");
    cvReleaseImage(&frame);
}

/* HSV color space:
 * gimp: 360, 100, 100
 * opencv: 180, 240, 240 */

/*void Locator::extractField() {
    //return;
    uchar* atFrame;
    cvGetRawData(hsvImage, (uchar**) & atFrame);
    uchar* min = atFrame;
    uchar* max = atFrame + 3 * size.height * size.width;
    for (int i = 0; i < size.width; i++) {
        cvGetRawData(hsvImage, (uchar**) & atFrame);
        atFrame += 3 * i + (size.height - 5) * size.width * 3;
        uchar color = *(atFrame + 2);
        int stop = 0;
        while (atFrame > min) {
            if ((int) *(atFrame + 2) - (int) color > 30 || (int) *(atFrame + 2) - (int) color<-30) {
                atFrame -= 45 * size.width;
                if (atFrame > min) {
                    if ((int) *(atFrame + 2) - (int) color > 30 || (int) *(atFrame + 2) - (int) color<-30) {
                        break;
                    }

                } else {
                    break;
                }
                //if (*(atFrame + 2) < 225) {
                /*stop++;
                if (stop > 15) {
                    break;
                }*/
//} else {
//    stop = 0;
//}

/*} else {
    stop = 0;
    color = *(atFrame + 2);
}
atFrame -= 3 * size.width;
}
atFrame += 45 * size.width;
while (atFrame > max) {
atFrame -= 3 * size.width;
}
while (atFrame > min) {
 *(atFrame) = 0;
 *(atFrame + 1) = 0;
 *(atFrame + 2) = 0;
atFrame -= 3 * size.width;
}
}

//cvSaveImage("/home/seddy/Desktop/particle/extract.jpg", hsvImage);
}*/

void Locator::extractField() {
    uchar* atFrame;
    cvGetRawData(hsvImage, (uchar**) & atFrame);
    uchar* max = atFrame + size.width * size.height * 3;

    int atY = 5;

    int lastY = -1;
    for (int i = 0; i < size.width; i++) {
        cvGetRawData(hsvImage, (uchar**) & atFrame);
        atFrame += 3 * i + 12 * size.width;
        atY = 0;
        while (atFrame < max) {
            if (/*(atY > 8 + lastY && lastY != -1) ||*/ (*(atFrame) > 10 && *(atFrame) < 80 &&
                    *(atFrame + 2) < 140 /*&&
                    (abs(atY - lastY) < 8 || lastY == -1)*/)) {
                lastY = atY;

                break;
            }
            *(atFrame - 12 * size.width) = 0;
            *(atFrame - 12 * size.width + 1) = 0;
            *(atFrame - 12 * size.width + 2) = 0;
            atFrame += 3 * size.width;
            atY++;
        }
    }

    //cvSaveImage("/home/seddy/Desktop/particle/extract.jpg", hsvImage);
}

void Locator::pointAlgorithm() {

    IplImage* grayImage = cvCreateImage(size, IPL_DEPTH_8U, 1);
    //IplImage* frame = cvLoadImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/img028.jpg", CV_LOAD_IMAGE_UNCHANGED);
    //IplImage* frame = cvLoadImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/img027.jpg", CV_LOAD_IMAGE_UNCHANGED);
    //IplImage* frame = cvLoadImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/img023.jpg", CV_LOAD_IMAGE_UNCHANGED);

    uchar* atFrame;
    cvGetRawData(hsvImage, (uchar**) & atFrame);
    uchar* atGray;
    cvGetRawData(grayImage, (uchar**) & atGray);
    uchar* max = atFrame + size.width * size.height * 3;
    uchar* max2 = atFrame + size.width * (size.height - 1) * 3;
    int atX = 0, atY = 0;

    while (atFrame < max) {
        if (atFrame < max2 && *(atFrame + 1) < 64 && *(atFrame + 2) > 128) {
            //if ((*(atFrame - 14) > 20 && *(atFrame - 13) < 240) || (*(atFrame - line + 1) > 20 && *(atFrame - line + 2) < 240)) {
            //if ((*(atFrame - 15) > 30 && *(atFrame - 15) < 120 && *(atFrame - 14) > 0) ||
            //        (*(atFrame - line) > 30 && *(atFrame - line) < 120 && *(atFrame - line + 1) > 0)) {
            //if ((*(atFrame) > 40 && *(atFrame) < 100) ) {
            *atGray = 255;
            //}
        } else {
            *atGray = 0;
        }
        atFrame += 3;
        atGray++;
        atX++;
        if (atX > size.width) {
            atX -= size.width;
            atY++;
        }
    }

    int kbegin = (int) spots.size();

    //cvSaveImage("/home/seddy/Desktop/particle/gray1.jpg", grayImage);

    cvCanny(grayImage, grayImage, 10, 100, 5);
    //cvSmooth(grayImage, grayImage, CV_GAUSSIAN, 3);

    //cvSaveImage("/home/seddy/Desktop/particle/gray2.jpg", grayImage);

    if (type == FIELDTYPE_CROSSINGS) {




        CvMemStorage* storage = cvCreateMemStorage(0);
        CvSeq* lines = cvHoughLines2(grayImage,
                storage,
                CV_HOUGH_PROBABILISTIC,
                1,
                CV_PI / 180.0,
                30,
                20,
                8);

        for (int i = 0; i < lines->total; i++) {
            CvPoint* line1 = (CvPoint*) cvGetSeqElem(lines, i);
            for (int j = i + 1; j < lines->total; j++) {
                CvPoint* line2 = (CvPoint*) cvGetSeqElem(lines, j);
                float arc1 = atan((double) (line1[1].x - line1[0].x) / (double) (line1[1].y - line1[0].y));
                float arc2 = atan((double) (line2[1].x - line2[0].x) / (double) (line2[1].y - line2[0].y));
                if (arc1 < 0.0f) arc1 += 3.14159265f;
                if (arc2 < 0.0f) arc2 += 3.14159265f;
                float arc = arc1 - arc2;
                if (arc < 0.0f) arc *= -1.0f;
                if (arc > 0.174532925f) { // 15°
                    float n = (float) (-line1[0].y * line1[1].x + line1[0].x * line1[1].y + line1[0].y * line2[0].x
                            - line1[1].y * line2[0].x - line1[0].x * line2[0].y + line1[1].x * line2[0].y) /
                            (float) (-line1[0].y * line2[0].x + line1[1].y * line2[0].x + line1[0].x * line2[0].y
                            - line1[1].x * line2[0].y + line1[0].y * line2[1].x - line1[1].y * line2[1].x
                            - line1[0].x * line2[1].y + line1[1].x * line2[1].y);
                    if (n < -1.15f || n > 0.1f) continue;
                    float n2 = (float) (-line2[0].y * line2[1].x + line2[0].x * line2[1].y + line2[0].y * line1[0].x
                            - line2[1].y * line1[0].x - line2[0].x * line1[0].y + line2[1].x * line1[0].y) /
                            (float) (-line2[0].y * line1[0].x + line2[1].y * line1[0].x + line2[0].x * line1[0].y
                            - line2[1].x * line1[0].y + line2[0].y * line1[1].x - line2[1].y * line1[1].x
                            - line2[0].x * line1[1].y + line2[1].x * line1[1].y);
                    if (n2 < -1.15f || n2 > 0.1f) continue;
                    int x = line2[0].x + n * (line2[0].x - line2[1].x);
                    int y = line2[0].y + n * (line2[0].y - line2[1].y);
                    if (x < 0 || x > IMAGE_W || y < 0 || y > IMAGE_H) continue;
                    int k, kmax = (int) spots.size();
                    for (k = kbegin; k < kmax; k++) {
                        if ((spots[k]->x - x)*(spots[k]->x - x) < 100 && (spots[k]->y - y)*(spots[k]->y - y) < 100) {
                            spots[k]->x = (spots[k]->x * spots[k]->type + x) / (spots[k]->type + 1);
                            spots[k]->y = (spots[k]->y * spots[k]->type + y) / (spots[k]->type + 1);
                            spots[k]->type += 1;
                            break;
                        }
                    }
                    if (k == kmax) {
                        Spot* spot = new Spot();
                        spot->x = x;
                        spot->y = y;
                        spot->type = 1;
                        spots.push_back(spot);
                    }
                }
            }
        }

        int kmax = (int) spots.size();
        for (int k = kbegin; k < kmax; k++) {
            spots[k]->type = SPOT_LINE;
        }

        //cvCvtColor(hsvImage, hsvImage, CV_HSV2BGR);

        /*for (int i = 0; i < lines->total; i++) {
            CvPoint* line = (CvPoint*) cvGetSeqElem(lines, i);
            cvLine(hsvImage, line[0], line[1], CV_RGB(255, 0, 0), 1, 8);
        }*/

        cvReleaseMemStorage(&storage);

    } else if (type == FIELDTYPE_LINES_HALF || type == FIELDTYPE_LINES_FULL) {
        cvGetRawData(grayImage, (uchar**) & atGray);
        max = atGray + size.width * (size.height - 10) - 9;
        atX = 0;
        atY = 0;
        while (atGray < max) {
            int sum = 0;
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 9; j++)
                    sum += (int) *(atGray + size.width * j + i);
            if (sum > 1200) {
                Spot* spot = new Spot();
                spot->x = atX + 4;
                spot->y = atY + 4;
                spot->type = 1;
                spots.push_back(spot);
            }
            atGray += 9;
            atX += 9;
            if (atX >= size.width) {

                atX -= size.width;
                atGray += size.width * 8;
                atY += 9;
            }
        }

    }

    /*int imax = (int) points.size();
    for (int i = 0; i < imax; i += 3) {
        if (points[i + 2] == -SPOT_GOAL_B || points[i + 2] == -SPOT_GOAL_Y) {
            cvCircle(hsvImage, cvPoint(points[i], points[i + 1]), 2, CV_RGB(255, 0, 255), 2);
        } else {
            cvCircle(hsvImage, cvPoint(points[i], points[i + 1]), 2, CV_RGB(255, 255, 0), 2);
        }
    }

    cvSaveImage("/home/seddy/Desktop/particle/result.jpg", hsvImage);*/

    //cvSaveImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/gray.jpg", grayImage);
    //cvSaveImage("/media/truecrypt1/Dropbox/Master/P2/svn/project/trunk/naosoccer-3/ball/img/goal.jpg", goal);
    cvReleaseImage(&grayImage);
}

// file:///home/seddy/naoqi-sdk-1.10.52-linux/doc/site_en/reddoc/hardware/video_camera.html
// Field of view: 58° diagonal, 34.8° vertical, resulting in 46.4° horizontal
// Camera height: foot+tibia+thigh+hip+neck=45.19+102.9+100+85+126.5=459.59

double Locator::getAngle(int x, bool relative) {
    double angle = (double) (x - IMAGE_W / 2) / (double) (IMAGE_W)*0.80983277;
    if (relative)
        angle -= (double) motionProxy.getAngles("HeadYaw", false)[0];

    return angle; // 46.4°
}

double Locator::getAngleV(int y) {

    return (double) (y - IMAGE_H / 2) / (double) (IMAGE_H)*0.60737458; // 34.8°
}

double Locator::getDistance(int y) {
    return camParam[2] / tan(getAngleV(y) + camParam[4]);
}

void Locator::lookAtItem() {

    double aH = -getAngle(searchBall ? ballX : goalX, false);
    double aV = getAngleV(searchBall ? ballY : goalY);
    if (aH > 0.01 || aH<-0.01) {

        motionProxy.angleInterpolation("HeadYaw", aH, 0.2f, false);
    }
    if (aV > 0.01 || aV<-0.01) {
        /*double angle = (double) motionProxy.getAngles("HeadPitch", false)[0] + aV;
        if (camID == 0 && angle > 0.50614548) { // 29°
            changeCam();
            angle -= 0.6981317; // 40°
            motionProxy.angleInterpolation("HeadPitch", angle, 0.4f, true);
        } else if (camID == 1 && angle < -0.50614548) { // 29°
            changeCam();
            angle += 0.6981317; // 40°
            motionProxy.angleInterpolation("HeadPitch", angle, 0.4f, true);
        } else {*/

        motionProxy.angleInterpolation("HeadPitch", aV, 0.2f, false);
        //}
    }
    // printf("%d,%d,%f,%f\n", searchBall ? ballX : goalX, searchBall ? ballY : goalY, aH, aV);
}

void Locator::searchForItem() {
    changeCam();
    /*if (camID == 0) {
        double pitch = (double) motionProxy.getAngles("HeadPitch", false)[0] - 0.2;
        if (pitch > 0.01 || pitch<-0.01)
            motionProxy.angleInterpolation("HeadPitch", 0.2, 0.2f, true);
    } else {
        double pitch = (double) motionProxy.getAngles("HeadPitch", false)[0] + 0.4;
        if (pitch > 0.01 || pitch<-0.01)
            motionProxy.angleInterpolation("HeadPitch", -0.4, 0.2f, true);
    }*/
    double pitch = (double) motionProxy.getAngles("HeadPitch", false)[0] - 0.26179939; // 15°
    if (pitch > 0.01 || pitch<-0.01)
        motionProxy.angleInterpolation("HeadPitch", 0.26179939, 0.15f, true);

    // HeadYaw: -2.0857 to 2.0857
    if (searchRight) {
        double headangle = (double) motionProxy.getAngles("HeadYaw", false)[0];
        if (headangle<-1.0) {
            searchLeft = true;
            searchRight = false;
        } else {
            double angle = -0.3;
            if (headangle + angle<-1.0) {
                angle = -1.0 - headangle;
                searchLeft = true;
                searchRight = false;
            }
            motionProxy.angleInterpolation("HeadYaw", angle, 0.15f, false);
        }
    } else if (searchLeft) {
        double headangle = (double) motionProxy.getAngles("HeadYaw", false)[0];
        if (headangle > 1.0) {
            searchLeft = false;
            searchRight = true;
        } else {
            double angle = 0.3;
            if (headangle + angle > 1.0) {
                angle = 1.0 - headangle;
                searchLeft = false;
                searchRight = true;
            }
            motionProxy.angleInterpolation("HeadYaw", angle, 0.15f, false);
        }
    } else {
        if (searchBall ? ballX : goalX > IMAGE_W / 2) {
            searchRight = true;
        } else {

            searchLeft = true;
        }
    }
}

bool Locator::gotoItem() {
    float angle = (float) -getAngle(searchBall ? ballX : goalX, true);
    double dist = getDistance(searchBall ? ballY : goalY);
    if (dist > 0.25) {
        motionProxy.setAngles("HeadYaw", 0.0f, 0.2f);
        motionProxy.walkTo(cos(angle)*0.2f, sin(angle)*0.2f, angle / 2.0f);
        pf->move(cos(angle)*0.2f, sin(angle)*0.2f, angle);

        return false;
    }
    return true;
}

void Locator::changeCam() {
    if (camID == 0) camID = 1;
    else camID = 0;
    camProxy.setParam(AL::kCameraSelectID, camID);
    if (cameraValues[0] != -1) {

        camProxy.setParam(AL::kCameraAutoWhiteBalanceID, 0);
        camProxy.setParam(AL::kCameraAutoGainID, 0);
        camProxy.setParam(AL::kCameraAutoExpositionID, 0);
        camProxy.setParam(AL::kCameraBrightnessID, cameraValues[0]);
        camProxy.setParam(AL::kCameraContrastID, cameraValues[1]);
        camProxy.setParam(AL::kCameraSaturationID, cameraValues[2]);
        camProxy.setParam(AL::kCameraHueID, cameraValues[3]);
        camProxy.setParam(AL::kCameraRedChromaID, cameraValues[4]);
        camProxy.setParam(AL::kCameraBlueChromaID, cameraValues[5]);
        camProxy.setParam(AL::kCameraExposureCorrectionID, cameraValues[6]);
        camProxy.setParam(AL::kCameraExposureID, cameraValues[7]);
        camProxy.setParam(AL::kCameraGainID, cameraValues[8]);
    }
}

double Locator::getProbability(int x, int y) {
    if (x > -1 && y>-1 && x < GRID_SIZE_X && y < GRID_SIZE_Y)
        return pf->grid[x + y * GRID_SIZE_X];

    else
        return 0.0;
}

void Locator::walkTo(float x, float y, float angle) {

    walkMotionProxy.walkTo(x, y, angle);
    pf->move(x, y, angle);
}

void Locator::stepTo(std::string legName, float x, float y, float angle) {

    walkMotionProxy.stepTo(legName, x, y, angle);
    pf->move(x * 0.5f, y * 0.5f, angle);
}

Locator* Locator::getInstance() {

    return instance;
}

double Locator::getBallX() {

    return relBallX;
}

double Locator::getBallY() {

    return relBallY;
}

double Locator::getMyX() {

    return myX;
}

double Locator::getMyY() {

    return myY;
}

double Locator::getMyAngle() {
    return myAngle;
}

int Locator::getBallCamX() {
    return ballX;
}

int Locator::getBallCamY() {
    return ballY;
}

void Locator::killWalkMotions() {
    walkMotionProxy.killAll();
}

AL::ALMotionProxy*  Locator::getWalkMotionProxy(){
    return &walkMotionProxy;;
}