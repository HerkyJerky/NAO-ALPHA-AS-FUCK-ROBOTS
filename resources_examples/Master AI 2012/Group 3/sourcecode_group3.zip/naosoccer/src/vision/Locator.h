/* 
 * File:   Locator.h
 * Author: Christian Andrich
 *
 * Created on 2. November 2011, 12:27
 */
#include "opencv/cv.h"
#include "opencv/cvaux.h"
#include "opencv/highgui.h"
#include "opencv/cxcore.h"
#include <alproxies/alvideodeviceproxy.h>
#include <alproxies/almotionproxy.h>
#include <alvision/alvisiondefinitions.h>
#include "ParticleFilter.h"
#include "../base/robotStatus.h"
#include <pthread.h>

#ifndef LOCATOR_H
#define	LOCATOR_H

class Locator {
public:
    static Locator* create(const char* ip, int port, int type, int camID, RobotStatus* robotStatus);
    static void takeImages(const char* ip, int port, int amount, int add, int camID);
    virtual ~Locator();
    static const int GRID_SIZE_X = 6, GRID_SIZE_Y = 4;
    double getProbability(int x, int y);
    double getBallX();
    double getBallY();
    double getMyX();
    double getMyY();
    double getMyAngle();
	int getBallCamX();
    int getBallCamY();
    void walkTo(float x, float y, float angle);
    void stepTo(std::string legName, float x, float y, float angle);
    static Locator* getInstance();
    void killWalkMotions();
    AL::ALMotionProxy* getWalkMotionProxy();
private:
    static const int IMAGE_W = 320, IMAGE_H = 240;
    static Locator* instance;
    Locator(const char* ip, int port, int type, int camID, RobotStatus* robotStatus);
    Locator();
    void extractField();
    void pointAlgorithm();
    void detectBall();
    void detectGoal();
    pthread_t worker;
    bool running;
    AL::ALVideoDeviceProxy camProxy;
    AL::ALMotionProxy motionProxy, walkMotionProxy;
    std::string clientName;
    friend void* WorkerCode(void* arguments);
    friend int main(int argc, char* argv[]);
    IplImage* hsvImage;
    bool seeBall, seeGoal, searchBall, blueGoal;
    CvSize size;
    double getAngle(int x, bool relative);
    double getAngleV(int y);
    double getDistance(int y);
    int ballX, ballY, goalX, goalY;
    ParticleFilter* pf;
    std::vector<Spot*> spots;
    int spotsSize;
    static int cameraValues[9];
    int type;
    bool searchLeft, searchRight;
    int camID;
    void changeCam();
    RobotStatus* robotStatus;
    void lookAtItem();
    void searchForItem();
    bool gotoItem();
    double myX, myY, myAngle, relBallX, relBallY;
    void resetPF();
    std::vector<float> camParam;
};

#endif	/* LOCATOR_H */

