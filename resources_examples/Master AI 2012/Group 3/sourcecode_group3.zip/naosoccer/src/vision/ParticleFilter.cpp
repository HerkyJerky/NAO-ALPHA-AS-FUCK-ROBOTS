#include "ParticleFilter.h"
#include <cstdlib>
#include "opencv/cv.h"
#include "opencv/highgui.h"
#include <stdio.h>
#include <opencv/cxcore.h>
#include <time.h>
#include "Locator.h"

double getAngle(double x1, double y1, double x2, double y2) {
    if (y1 == y2)
        y2 -= 0.000000001;
    double re = -atan((x2 - x1) / (y2 - y1));
    if (y1 < y2) re += 3.1415927;
    return re;
}

double getDist(double x1, double y1, double x2, double y2) {
    return sqrt((x1 - x2)*(x1 - x2)+(y1 - y2)*(y1 - y2));
}

ParticleFilter::ParticleFilter(int particleSize, int fieldtype) {
    fieldType = fieldtype;
    srand(time(NULL));
    definitions();
    this->particleSize = particleSize;
    particles = new Particle[particleSize];
    for (int i = 0; i < particleSize; i++) {
        particles[i].x = (double) rand() / (double) RAND_MAX * 6.0;
        particles[i].y = (double) rand() / (double) RAND_MAX * 4.0;
        particles[i].a = (double) rand() / (double) RAND_MAX * 6.2831853 - 3.14159;
        particles[i].value = 1.0;
    }
    iteration = 0;
    avgValue = 1.0;
    startClock = clock();
    grid = new double[Locator::GRID_SIZE_X * Locator::GRID_SIZE_Y];
}

void ParticleFilter::definitions() {
    if (fieldType == FIELDTYPE_CROSSINGS) {
        fieldSize = 20;
    } else if (fieldType == FIELDTYPE_LINES_HALF) {
        fieldSize = 200;
    } else if (fieldType == FIELDTYPE_LINES_FULL) {
        fieldSize = 390;
    } else {
        fieldSize = 0;
    }
    field = new Spot[fieldSize];
    if (fieldType == FIELDTYPE_CROSSINGS) {
        // blue goal lines
        field[0].x = 0.0;
        field[0].y = 0.0;
        field[0].type = SPOT_LINE;
        field[1].x = 0.0;
        field[1].y = 4.0;
        field[1].type = SPOT_LINE;
        field[2].x = 0.0;
        field[2].y = 0.9;
        field[2].type = SPOT_LINE;
        field[3].x = 0.0;
        field[3].y = 3.1;
        field[3].type = SPOT_LINE;
        field[4].x = 0.6;
        field[4].y = 0.9;
        field[4].type = SPOT_LINE;
        field[5].x = 0.6;
        field[5].y = 3.1;
        field[5].type = SPOT_LINE;
        // yellow goal lines
        field[6].x = 6.0;
        field[6].y = 0.0;
        field[6].type = SPOT_LINE;
        field[7].x = 6.0;
        field[7].y = 4.0;
        field[7].type = SPOT_LINE;
        field[8].x = 6.0;
        field[8].y = 0.9;
        field[8].type = SPOT_LINE;
        field[9].x = 6.0;
        field[9].y = 3.1;
        field[9].type = SPOT_LINE;
        field[10].x = 5.4;
        field[10].y = 0.9;
        field[10].type = SPOT_LINE;
        field[11].x = 5.4;
        field[11].y = 3.1;
        field[11].type = SPOT_LINE;
        // middle line
        field[12].x = 3.0;
        field[12].y = 0.0;
        field[12].type = SPOT_LINE;
        field[13].x = 3.0;
        field[13].y = 1.4;
        field[13].type = SPOT_LINE;
        field[14].x = 3.0;
        field[14].y = 2.6;
        field[14].type = SPOT_LINE;
        field[15].x = 3.0;
        field[15].y = 4.0;
        field[15].type = SPOT_LINE;
        // blue goal
        field[16].x = 0.0;
        field[16].y = 1.3;
        field[16].type = SPOT_GOAL_B;
        field[17].x = 0.0;
        field[17].y = 2.7;
        field[17].type = SPOT_GOAL_B;
        // yellow goal
        field[18].x = 6.0;
        field[18].y = 1.3;
        field[18].type = SPOT_GOAL_Y;
        field[19].x = 6.0;
        field[19].y = 2.7;
        field[19].type = SPOT_GOAL_Y;

    } else if (fieldType == FIELDTYPE_LINES_HALF || fieldType == FIELDTYPE_LINES_FULL) {

        int fullI = (fieldType == FIELDTYPE_LINES_FULL) ? 2 : 1;
        double fullD = (fieldType == FIELDTYPE_LINES_FULL) ? 0.5 : 1.0;

        int num = 0;
        // upper line
        for (int i = 0; i <= 30 * fullI; i++) {
            field[num].x = (double) i * 0.2 * fullD;
            field[num].y = 0.0;
            field[num].type = SPOT_LINE;
            num++;
        }
        // lower line
        for (int i = 0; i <= 30 * fullI; i++) {
            field[num].x = (double) i * 0.2 * fullD;
            field[num].y = 4.0;
            field[num].type = SPOT_LINE;
            num++;
        }
        // left line
        for (int i = 0; i <= 20 * fullI; i++) {
            field[num].x = 0.0;
            field[num].y = (double) i * 0.2 * fullD;
            field[num].type = SPOT_LINE;
            num++;
        }
        // right line
        for (int i = 0; i <= 20 * fullI; i++) {
            field[num].x = 6.0;
            field[num].y = (double) i * 0.2 * fullD;
            field[num].type = SPOT_LINE;
            num++;
        }
        // middle line
        for (int i = 0; i <= 20 * fullI; i++) {
            field[num].x = 3.0;
            field[num].y = (double) i * 0.2 * fullD;
            field[num].type = SPOT_LINE;
            num++;
        }
        // left goal
        for (int i = 1; i <= 3 * fullI; i++) {
            field[num].x = (double) i * 0.2 * fullD;
            field[num].y = 0.9;
            field[num].type = SPOT_LINE;
            num++;
        }
        for (int i = 1; i <= 3 * fullI; i++) {
            field[num].x = (double) i * 0.2 * fullD;
            field[num].y = 3.1;
            field[num].type = SPOT_LINE;
            num++;
        }
        for (int i = 1; i < 11 * fullI; i++) {
            field[num].x = 0.6;
            field[num].y = 0.9 + (double) i * 0.2 * fullD;
            field[num].type = SPOT_LINE;
            num++;
        }
        // right goal
        for (int i = 0; i < 3 * fullI; i++) {
            field[num].x = 5.4 + (double) i * 0.2 * fullD;
            field[num].y = 0.9;
            field[num].type = SPOT_LINE;
            num++;
        }
        for (int i = 0; i < 3 * fullI; i++) {
            field[num].x = 5.4 + (double) i * 0.2 * fullD;
            field[num].y = 3.1;
            field[num].type = SPOT_LINE;
            num++;
        }
        for (int i = 1; i < 11 * fullI; i++) {
            field[num].x = 5.4;
            field[num].y = 0.9 + (double) i * 0.2 * fullD;
            field[num].type = SPOT_LINE;
            num++;
        }
        // circle
        for (int i = 0; i <= 36 * fullI; i++) {
            field[num].x = 3.0 + sin((double) i * 0.174532925 * fullD)*0.6;
            field[num].y = 2.0 + cos((double) i * 0.174532925 * fullD)*0.6;
            field[num].type = SPOT_LINE;
            num++;
        }
        // 11 meter points
        field[num].x = 1.8;
        field[num].y = 2.0;
        field[num].type = SPOT_LINE;
        num++;
        field[num].x = 4.2;
        field[num].y = 2.0;
        field[num].type = SPOT_LINE;
        num++;
        // blue goal
        field[num].x = 0.0;
        field[num].y = 1.3;
        field[num].type = SPOT_GOAL_B;
        num++;
        field[num].x = 0.0;
        field[num].y = 2.7;
        field[num].type = SPOT_GOAL_B;
        num++;
        // yellow goal
        field[num].x = 6.0;
        field[num].y = 1.3;
        field[num].type = SPOT_GOAL_Y;
        num++;
        field[num].x = 6.0;
        field[num].y = 2.7;
        field[num].type = SPOT_GOAL_Y;

        //printf("num: %d\n",num);
    }
}

void ParticleFilter::setSpots(std::vector<Spot*> input) {
    //delete [] spots;
    spots = input;
    spotSize = (int) spots.size();
}

void ParticleFilter::evaluate(double* avgX,double* avgY,double* avgA) {
    if (spots.size() == 0)
        return;
    avgValue = 0.0;
    *avgX = 0.0;
    *avgY = 0.0;
    *avgA = 0.0;
    
    for (int x = 0; x < Locator::GRID_SIZE_X; x++)
        for (int y = 0; y < Locator::GRID_SIZE_Y; y++)
            grid[x + y * Locator::GRID_SIZE_X] = 0.0;

    //calculate values
    for (int i = 0; i < particleSize; i++) { // for all particles

        double *minDist = new double[spots.size()];
        double *minAngle = new double[spots.size()];

        for (int k = 0; k < spotSize; k++) {
            minDist[k] = 7.2111; // sqrt(4^2+6^2)
            minAngle[k] = 6.2832; // 360°
        }

        for (int j = 0; j < fieldSize; j++) { // for all field points

            double angle = getAngle(particles[i].x, particles[i].y, field[j].x, field[j].y) - particles[i].a;
            while (angle<-3.1415927) angle += 6.2831853;
            while (angle > 3.1415927) angle -= 6.2831853;
            if (angle < 0.404916 && angle>-0.404916) { // 46.4°/2 => is in sight
                double dist = sqrt((particles[i].x - field[j].x)*(particles[i].x - field[j].x)+
                        (particles[i].y - field[j].y)*(particles[i].y - field[j].y));

                //find best match (find nearest neigbour)
                double bestDist = 7.2111;
                double bestAngle = 6.2832;
                int bestK = 0;
                for (int k = 0; k < spotSize; k++) { // for all recognized field points
                    if (spots[k]->type == field[j].type) {
                        double curDist = (spots[k]->x - dist);
                        double curAngle = (spots[k]->y - angle);
                        if (curDist * curDist + curAngle * curAngle < bestDist * bestDist + bestAngle * bestAngle) {
                            bestDist = curDist;
                            bestAngle = curAngle;
                            bestK = k;
                        }
                    }
                }

                // save best match if no other field point was better
                if (minDist[bestK] * minDist[bestK] + minAngle[bestK] * minAngle[bestK] > bestDist * bestDist + bestAngle * bestAngle) {
                    minDist[bestK] = bestDist;
                    minAngle[bestK] = bestAngle;
                }
            }

        }

        // value is inverse of sum of errors
        particles[i].value = 0.0;
        for (int k = 0; k < spotSize; k++) {
            particles[i].value += sqrt(minDist[k] * minDist[k] + minAngle[k] * minAngle[k])*
                    ((spots[k]->type == SPOT_LINE) ? 1.0 : 5.0);
        }
        particles[i].value = 1 / particles[i].value;
        avgValue += particles[i].value;
        *avgX += particles[i].x;
        *avgY += particles[i].y;
        *avgA += particles[i].a;
        int x = particles[i].x / 4.0 * (double) Locator::GRID_SIZE_X;
        int y = particles[i].y / 6.0 * (double) Locator::GRID_SIZE_Y;
        if (x > -1 && y>-1 && x < Locator::GRID_SIZE_X && y < Locator::GRID_SIZE_Y)
            grid[x + y * Locator::GRID_SIZE_X] += particles[i].value;

        delete [] minDist;
        delete [] minAngle;
    }

    for (int x = 0; x < Locator::GRID_SIZE_X; x++)
        for (int y = 0; y < Locator::GRID_SIZE_Y; y++)
            grid[x + y * Locator::GRID_SIZE_X] /= avgValue;

    avgValue /= (double) particleSize;
    *avgX /= (double) particleSize;
    *avgY /= (double) particleSize;
    *avgA /= (double) particleSize;

    //sort out particles below average
    for (int i = 0; i < particleSize; i++) { // for all particles
        if (particles[i].value < avgValue) {

            // search for random particle which has a good value (above average + some random number)
            int k = 0;
            //do {
            k = rand() % particleSize;
            //} while (particles[k].value < avgValue);

            // place particle near previously chose one
            particles[i].x = particles[k].x + posNoise();
            particles[i].y = particles[k].y + posNoise();
            particles[i].a = particles[k].a + angleNoise();
            particles[i].value = particles[k].value;
        }
    }
    
    

    iteration++;
    //printf("%4d: %7.4f -> %6.4f|%6.4f|%6.4f\n", iteration, avgValue, *avgX, *avgY, *avgA);
}

void ParticleFilter::move(double x, double y, double angle) {
    for (int i = 0; i < particleSize; i++) { // for all particles
        particles[i].x += sin(particles[i].a) * x + cos(particles[i].a) * y + posNoise();
        particles[i].y += sin(particles[i].a) * y + cos(particles[i].a) * x + posNoise();
        particles[i].a += angle + angleNoise();
        while (particles[i].a<-3.1415927) particles[i].a += 6.2831853;
        while (particles[i].a > 3.1415927) particles[i].a -= 6.2831853;
    }
}

double ParticleFilter::posNoise() {
    return (double) rand() / (double) RAND_MAX * 0.06 - 0.03; // up to +-3 cm
}

double ParticleFilter::angleNoise() {
    return (double) rand() / (double) RAND_MAX * 0.17453293 - 0.087266463; // up to +-5°
}

ParticleFilter::~ParticleFilter() {
    delete [] particles;
    delete [] field;
    delete [] grid;
}

void ParticleFilter::debugDraw(std::string path) {
    IplImage* outputImage = cvCreateImage(cvSize(620, 420), IPL_DEPTH_8U, 3);
    uchar* atOutput;
    cvGetRawData(outputImage, (uchar**) & atOutput);
    uchar* atMax = atOutput + 620 * 420 * 3;
    while (atOutput < atMax) {
        *atOutput = 0;
        atOutput++;
    }
    cvGetRawData(outputImage, (uchar**) & atOutput);
    for (int i = 0; i < particleSize; i++) {
        if (particles[i].x > -0.09 && particles[i].x < 6.09 && particles[i].y > -0.09 && particles[i].y < 4.09) {
            uchar* at = atOutput + 1860 * (int) (particles[i].y * 100.0 + 10.0) + (int) (particles[i].x * 100.0 + 10.0)*3 + 1;
            if (*at < (uchar) (particles[i].value / avgValue * 128)) {
                if (particles[i].value / avgValue * 128 > 255) {
                    *at = (uchar) 255;
                    *(at + 3) = (uchar) 255;
                    *(at - 3) = (uchar) 255;
                    *(at + 1860) = (uchar) 255;
                    *(at - 1860) = (uchar) 255;
                } else {
                    *at = (uchar) (particles[i].value / avgValue * 128);
                    *(at + 3) = (uchar) (particles[i].value / avgValue * 128);
                    *(at - 3) = (uchar) (particles[i].value / avgValue * 128);
                    *(at + 1860) = (uchar) (particles[i].value / avgValue * 128);
                    *(at - 1860) = (uchar) (particles[i].value / avgValue * 128);
                }
            }
        }
    }
    for (int i = 0; i < fieldSize; i++) {
        fflush(stdout);
        uchar* at = atOutput + 1860 * (int) (field[i].y * 100.0 + 10.0) + (int) (field[i].x * 100.0 + 10.0)*3 + 2;
        *at = (uchar) 255;
        *(at - 3) = (uchar) 255;
        *(at + 3) = (uchar) 255;
        *(at - 1860) = (uchar) 255;
        *(at + 1860) = (uchar) 255;
    }
    char filename[512];
    sprintf(filename, "%s%04d.jpg", path.c_str(), iteration);
    //sprintf(filename, "%s%08d.jpg", path.c_str(), (int) ((clock() - startClock) / CLOCKS_PER_SEC / 1000l));
    cvSaveImage(filename, outputImage);
    cvReleaseImage(&outputImage);
}

Spot* ParticleFilter::debugSpots(double x, double y, double angle, int* size) {
    *size = 0;
    for (int j = 0; j < fieldSize; j++) { // for all field points
        double a = getAngle(x, y, field[j].x, field[j].y) - angle;
        while (a<-3.1415927) a += 6.2831853;
        while (a > 3.1415927) a -= 6.2831853;
        if (a < 0.404916 && a>-0.404916) { // 46.4°/2 => is in sight
            (*size)++;
        }
    }
    Spot* re = new Spot[*size];
    int num = 0;
    for (int j = 0; j < fieldSize; j++) { // for all field points
        double a = getAngle(x, y, field[j].x, field[j].y) - angle;
        if (a < 0.404916 && a>-0.404916) { // 46.4°/2 => is in sight
            double dist = sqrt((x - field[j].x)*(x - field[j].x)+ (y - field[j].y)*(y - field[j].y));
            re[num].x = dist;
            re[num].y = a;
            re[num].type = field[j].type;
            num++;
        }
    }
    return re;
}

