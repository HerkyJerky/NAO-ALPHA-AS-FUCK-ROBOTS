#ifndef LEARNING_LEARNINGNAO_H_
#define LEARNING_LEARNINGNAO_H_

#include <string>
#include "../base/robotStatus.h"
#include "../NaoMDP/MarkovDecisionProcess.h"
#include "../qtable/QTable.h"
#include "../qtable/State.h"
#include "../qtable/Action.h"

#include "../base/Singleton.h"

// Q-Learning
#define LN_INITIAL_Q 0.0

// Feature constants:
#define LN_MAX_ANGLE_TO_GOAL      20.0
#define LN_MIN_ANGLE_TO_GOAL     -20.0
#define LN_ANGLE_TO_GOAL_RES      10.0

// GRID_SIZE_X = 6, GRID_SIZE_Y = 4;
#define LN_GRID_OFFSET_LEFT    0
#define LN_GRID_OFFSET_RIGHT   0
#define LN_GRID_OFFSET_TOP     0
#define LN_GRID_OFFSET_BOTTOM  0

// Static distance to the ball
#define LN_DISTANCE_TO_BALL 0.1

// Rewards
#define LN_DEFAULT_REWARD            0.0
#define LN_HIT_GOAL_REWARD         100.0
#define LN_MISSED_GOAL_REWARD     -100.0
#define LN_MISSED_BALL_REWARD     -200.0

// Action IDs
#define LN_KICK_ACTION              "Kick"
#define LN_CIRCLE_LEFT_ACTION       "Circle Left"
#define LN_CIRCLE_RIGHT_ACTION      "Circle Right"
#define LN_WALK_FORWARD_ACTION      "Walk Forward"
#define LN_WALK_BACKWARD_ACTION     "Walk Backward"

// Forward declare RobotStatus:
class RobotStatus;

class LearningNao : public Singleton<LearningNao>
{
    public:
	    LearningNao();

        /**
         * Initializes the learning NAO and performs the first iteration.
         */
        void init(AL::ALPtr<AL::ALBroker> parentBroker, RobotStatus* robotStatus);

        void buildQTable();

        /**
         * Performs an action and sets the robot into the "expecting feedback"
         * state.
         */
        void performIteration();

        /**
         * Executes the action associated with the left bumper.
         */
        void leftBumperAction();
        /**
         * Executes the action associated with the right bumper.
         */
        void rightBumperAction();
        /**
         * Executes the action associated with the chest button.
         */
        void chestButtonAction();

        void setExpectingFeedback(bool expectingFeedback);
        bool isExpectingFeedback();

        void startLearning();

        State* estimateState();
	private:
        QTable* qTable;
        State* hitGoalState;
        State* missedGoalState;
        State* missedBallState;

        /**
         * Determines whether the NAO has just executed an action and is expecting
         * feedback through the buttons.
         */
        bool expectingFeedback;
        RobotStatus* robotStatus;
		/**
		 * Builds an id string  for the markov states including the feature values.
		 */
		std::string buildId(int x, int y, double angleToGoal, double distanceToBall);
		MarkovDecisionProcess* mdp;

        /**
         * Rewards a goal hit and, exits the "expecting feedback" mode and
         * calls the next iteration.
         */
        void rewardHitGoal();

        /**
         * Rewards a goal miss and, exits the "expecting feedback" mode and
         * calls the next iteration.
         */
        void rewardMissedGoal();

        /**
         * Rewards a ball miss and, exits the "expecting feedback" mode and
         * calls the next iteration.
         */
        void rewardMissedBall();

        // Actions:
        void performCircleLeftAction();
        void performCircleRightAction();
        void performWalkForwardAction();
        void performWalkBackwardAction();
        void performKickAction();
};

#endif // LEARNING_LEARNINGNAO_H_