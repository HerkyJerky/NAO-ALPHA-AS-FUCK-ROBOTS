#include "../base/robotStatus.h"

#include "LearningNao.h"
#include <string>
#include <sstream>
#include "../NaoMDP/Conf.h"
#include "../NaoMDP/MarkovState.h"
#include "../NaoMDP/MarkovAction.h"
#include "../NaoMDP/MarkovActionStateTransition.h"
#include "../NaoMDP/MarkovDecisionProcess.h"
#include "../vision/Locator.h"

// Actions:
#include "../NaoMDP/Actions/CircleAction.h"
#include "../NaoMDP/Actions/KickAction.h"
#include "../NaoMDP/Actions/WalkForwardAction.h"
#include "../NaoMDP/Actions/WalkBackwardAction.h"

// Q-Table:
#include "../qtable/Conf.h"
#include "../qtable/QTable.h"
#include "../qtable/State.h"
#include "../qtable/Action.h"

// Motions
#include "../motions/walk.h"

// Actions:
// FIXME: Actions should be taken out of the NaoMDP!!!
#include "../NaoMDP/Actions/KickAction.h"

LearningNao::LearningNao()
{
    
}

void LearningNao::init(AL::ALPtr<AL::ALBroker> parentBroker, RobotStatus* robotStatus)
{
    this->robotStatus = robotStatus;
    this->expectingFeedback = false;
}

void LearningNao::buildQTable()
{
    this->qTable = new QTable();

    // Create static states:
    this->hitGoalState     = qTable->addState("Hit Goal", LN_HIT_GOAL_REWARD);
    this->missedGoalState  = qTable->addState("Missed Goal", LN_MISSED_GOAL_REWARD);
    this->missedBallState  = qTable->addState("Missed Ball", LN_MISSED_BALL_REWARD);

    int numFieldsX = Locator::GRID_SIZE_X - (LN_GRID_OFFSET_LEFT + LN_GRID_OFFSET_RIGHT);
    int numFieldsY = Locator::GRID_SIZE_Y - (LN_GRID_OFFSET_TOP + LN_GRID_OFFSET_BOTTOM);

    std::cout << "Generating Q-Table" << std::endl;

    // Create dynamic states:
    for (int y = LN_GRID_OFFSET_TOP; y < numFieldsY; y++)
    {
        for (int x = LN_GRID_OFFSET_LEFT; x < numFieldsX; x++)
        {
            for (double angleToGoal = LN_MIN_ANGLE_TO_GOAL; angleToGoal < LN_MAX_ANGLE_TO_GOAL; angleToGoal += LN_ANGLE_TO_GOAL_RES)
            {
                // Create the state:
                State* state = qTable->addState(this->buildId(x, y, angleToGoal, LN_DISTANCE_TO_BALL), LN_DEFAULT_REWARD);
                state->addFeature(x);
                state->addFeature(y);
                state->addFeature(angleToGoal);
                state->addFeature(LN_DISTANCE_TO_BALL);

                // Create the state's actions:
                Action* kickAction          = qTable->addAction(state, LN_KICK_ACTION,          LN_INITIAL_Q, QT_LEARNING_RATE);
                Action* circleLeftAction    = qTable->addAction(state, LN_CIRCLE_LEFT_ACTION,   LN_INITIAL_Q, QT_LEARNING_RATE);
                Action* circleRightAction   = qTable->addAction(state, LN_CIRCLE_RIGHT_ACTION,  LN_INITIAL_Q, QT_LEARNING_RATE);
                Action* walkBackwardAction  = qTable->addAction(state, LN_WALK_BACKWARD_ACTION, LN_INITIAL_Q, QT_LEARNING_RATE);
                Action* walkForwardAction   = qTable->addAction(state, LN_WALK_FORWARD_ACTION,  LN_INITIAL_Q, QT_LEARNING_RATE);

                std::cout << "Adding state \"" << state->getId() << "\"" << std::endl;
            }
        }
    }

    // Estimate the current state:
    //int x;
    //int y;
    //this->robotStatus->getHighestProbField(x, y);

    // Create the feature vector:
    /*std::vector<double>* features = new std::vector<double>();
    features->push_back(x);
    features->push_back(y);
    features->push_back(0);
    features->push_back(LN_DISTANCE_TO_BALL);*/
    
    // std::cout << "ANGLE TO GOAL: " << this->robotStatus->getAngleToGoal(false) << std::endl;

    // qTable->getStateByFeatures();

    qTable->setCurrentState(estimateState());
}

void LearningNao::startLearning()
{
    // Build the q-table:
    this->buildQTable();

    // Perform first iteration:
    this->performIteration();
}

State* LearningNao::estimateState()
{
    int x;
    int y;
    this->robotStatus->getHighestProbField(x, y);
    std::cout << "ANGLE TO GOAL: " << this->robotStatus->getAngleToGoal(false) << std::endl;

    // Create the feature vector:
    std::vector<double>* features = new std::vector<double>();
    features->push_back(x);
    features->push_back(y);
    features->push_back(0);
    features->push_back(LN_DISTANCE_TO_BALL);

    // Query the state:
    State* state = qTable->getStateByFeatures(features);
    return state;
}


void LearningNao::performIteration()
{
    if (!this->expectingFeedback)
    {
        // Determine the max-q action of the current state:
        Action* maxQAction = qTable->getCurrentState()->getMaxQAction();

        // Check whether the state has returned an action:
        if (maxQAction == NULL)
        {
            std::cout << "Current state has no actions." << std::endl;
            return;
        }

        // Perform the action:
        if (maxQAction->getId().compare(LN_KICK_ACTION))
        {
            std::cout << "Performing kick action." << std::endl;
            KickAction* kickAction = new KickAction(LN_KICK_ACTION);
            kickAction->executeAction();
        }
        else if (maxQAction->getId().compare(LN_CIRCLE_LEFT_ACTION))
        {
            std::cout << "Performing circle left action." << std::endl;
            // this->circleLeftAction();
        }
        else if (maxQAction->getId().compare(LN_CIRCLE_RIGHT_ACTION))
        {
            std::cout << "Performing circle right action." << std::endl;
            // this->circleRightAction();
        }
        //else if (maxQAction->getId().compare(LN_WALK_BACKWARD_ACTION))
        //{
            // std::cout << "Performing walk backward action." << std::endl;
        //}
        //else if (maxQAction->getId().compare(LN_WALK_FORWARD_ACTION))
        //{
          //  std::cout << "Performing walk forward action." << std::endl;
        //}

        // Set the last action of the q-table to the performed action.
        this->qTable->setLastAction(maxQAction);

        // Block further actions until feedback is given:
        this->expectingFeedback = true;
        std::cout << "Action performed. Expecting feedback..." << std::endl;
    }   
}

void LearningNao::leftBumperAction()
{
    if (this->expectingFeedback)
    {
        rewardHitGoal();
    }
}

void LearningNao::rightBumperAction()
{
    if (this->expectingFeedback)
    {
        rewardMissedGoal();
    }
}

void LearningNao::chestButtonAction()
{
    if (this->expectingFeedback)
    {
        rewardMissedBall();
    }
}

void LearningNao::setExpectingFeedback(bool expectingFeedback)
{
    this->expectingFeedback = expectingFeedback;
}

bool LearningNao::isExpectingFeedback()
{
    return this->expectingFeedback;
}

std::string LearningNao::buildId(int x, int y, double angleToGoal, double distanceToBall)
{
    std::stringstream id;
    id << "x = " << x << "; ";
    id << "y = " << y << "; ";
    id << "angleToGoal = " << angleToGoal << "; ";
    id << "distanceToBall = " << distanceToBall << ";";

    return id.str();
}


void LearningNao::rewardHitGoal()
{
    if (this->expectingFeedback)
    {
        this->qTable->updateQ(this->hitGoalState);
        this->expectingFeedback = false;
        std::cout << "Reward hit goal with " << LN_HIT_GOAL_REWARD << "." << std::endl;
        qTable->print();
        this->performIteration();
    }
}

void LearningNao::rewardMissedGoal()
{
    if (this->expectingFeedback)
    {
        qTable->updateQ(this->missedGoalState);
        expectingFeedback = false;
        std::cout << "Reward missed goal with " << LN_MISSED_GOAL_REWARD << "." << std::endl;
        qTable->print();
        performIteration();
    }
}

void LearningNao::rewardMissedBall()
{
    if (this->expectingFeedback)
    {
        qTable->updateQ(this->missedBallState);
        expectingFeedback = false;
        std::cout << "Reward missed ball with " << LN_MISSED_BALL_REWARD << "." << std::endl;
        qTable->print();
        performIteration();
    }
}

void LearningNao::performCircleLeftAction()
{
    if (this->expectingFeedback)
    {
        qTable->updateQ(this->estimateState());
        expectingFeedback = false;
        qTable->print();
        performIteration();
    }
}

void LearningNao::performCircleRightAction()
{
    if (this->expectingFeedback)
    {
        qTable->updateQ(this->estimateState());
        expectingFeedback = false;
        qTable->print();
        performIteration();
    }
}

//void LearningNao::performWalkForwardAction()
//{
//}

// void LearningNao::performWalkBackwardAction()
// {
// }

void LearningNao::performKickAction()
{
}