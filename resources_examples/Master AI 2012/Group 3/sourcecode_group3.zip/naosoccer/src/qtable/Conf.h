/*
 * Conf.h
 *
 * Author: Henning Metzmacher
 */

#ifndef QTABLE_CONF_H_
#define QTABLE_CONF_H_

#define QT_DEFAULT_Q		0
#define QT_DISCOUNT_FACTOR	0.5 // Lambda
#define QT_LEARNING_RATE	0.5 // Alpha

#endif /* CONF_H_ */
