/*
 * State.cpp
 *
 * Author: Henning Metzmacher
 */

#include "State.h"
#include <iostream>
#include <string>
#include <vector>

State::State(std::string id, double reward)
{
	this->id = id;
	this->reward = reward;
	this->actions = new std::vector<Action*>();
    this->features = new std::vector<double>();
}

State::~State()
{
}

std::string State::getId()
{
	return this->id;
}

void State::setId(std::string id)
{
	this->id = id;
}

double State::getReward()
{
	return this->reward;
}

void State::setReward(double reward)
{
	this->reward = reward;
}

void State::setActions(std::vector<Action*>* actions)
{
	this->actions = actions;
}

std::vector<Action*>* State::getActions()
{
	return this->actions;
}

void State::addAction(Action* action)
{
	this->actions->push_back(action);
}

Action* State::getMaxQAction()
{
	if (this->actions->size() == 0)
	{
		return NULL;
	}

	Action* maxQAction = this->actions->front();

    // Softmax selection:
    // t = 1.0;

    // double e = exp(1.0) // Natural logarithm

    // Sum over states:
    // double sum = 0;
    // for (std::vector<Action*>::iterator it this->actions->begin(); it != this->actions->end(); it++)
    //{
    //    sum += e ^ (*it)->getQ() / t;
    //}

    // int p = 0;
    // for (std::vector<Action*>::iterator it this->actions->begin(); it != this->actions->end(); it++)
    //{
    //    p = (e ^ (*it)->getQ() / t) / sum;
    //}

	for (std::vector<Action*>::iterator it = this->actions->begin(); it != this->actions->end(); it++)
	{
		if ((*it)->getQ() > maxQAction->getQ())
		{
			maxQAction = *it;
		}
	}
	return maxQAction;
}

std::vector<double>* State::getFeatures()
{
    return this->features;
}

void State::setFeatures(std::vector<double>* features)
{
    this->features = features;
}

void State::addFeature(double feature)
{
    this->features->push_back(feature);
}