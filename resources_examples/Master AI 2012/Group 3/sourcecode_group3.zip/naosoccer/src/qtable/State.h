/*
 * State.h
 *
 * Author: Henning Metzmacher
 */

#ifndef QTABLE_STATE_H_
#define QTABLE_STATE_H_

#include <string>
#include <vector>

#include "Action.h"

class State {
public:
	State(std::string id, double reward);
	virtual ~State();

	std::string getId();
	void setId(std::string id);

	double getReward();
	void setReward(double reward);

	void setActions(std::vector<Action*>* actions);
	std::vector<Action*>* getActions();

	/**
	 * Adds an action to the state.
	 */
	void addAction(Action* action);

	/**
	 * Returns the action with the maximum Q-value.
	 */
	Action* getMaxQAction();

    std::vector<double>* getFeatures();
    void setFeatures(std::vector<double>* features);
    void addFeature(double feature);
    
private:
	std::string id;
	double reward;

    /**
     * List of numerical features:
     */
    std::vector<double>* features;

	std::vector<Action*>* actions;
};

#endif /* STATE_H_ */
