/*
 * QTable.h
 *
 * Author: Henning Metzmacher
 */

#ifndef QTABLE_QTABLE_H_
#define QTABLE_QTABLE_H_

#include <string>
#include <vector>

#include "Action.h"
#include "State.h"

class QTable {
public:
	QTable();
	virtual ~QTable();

	std::vector<State*>* getStates();
	void setStates(std::vector<State*>* states);

	std::vector<Action*>* getActions();
	void setActions(std::vector<Action*>* actions);

	/**
	 * Returns a state by its id.
	 */
	State* getStateById(std::string id);

    /**
     * Compares a vector of numerical feature values to the features of
     * a state. Returns true if the values are identical. Returns false
     * if not.
     */
    bool compareFeatures(State* state, std::vector<double>* features);

    /**
     * Returns a state by its features.
     */
    State* getStateByFeatures(std::vector<double>* features);

	/**
	 * Returns an action by its id.
	 */
	Action* getActionById(std::string id);

	State* addState(std::string id, double reward);
	Action* addAction(State* state, std::string id, double q, double learningRate);

	State* getCurrentState();
	void setCurrentState(State* currentState);

    /**
     * Returns the last action that was performed:
     */
    Action* getLastAction();

    /**
     * Sets the last action that was performed.
     */
    void setLastAction(Action* lastAction);

	/**
	 * Calls a value operation update. BEFORE THIS METHOD IS EXECUTED, lastAction
     * NEEDS TO BE SET TO THE EXECUTED ACTION.
	 *
	 * @param resultingState    Actual state this action has resulted in
	 */
	void updateQ(State* resultingState);

	void print();

private:
	std::vector<Action*>* actions;
	std::vector<State*>* states;
	bool verboseUpdate;
    Action* lastAction;
	State* currentState;
};

#endif /* QTABLE_H_ */
