/*
 * QTable.cpp
 *
 * Author: Henning Metzmacher
 */

#include <iostream>
#include <vector>
#include "Conf.h"
#include "QTable.h"

QTable::QTable()
{
	this->actions = new std::vector<Action*>();
	this->states = new std::vector<State*>();
	this->verboseUpdate = false;
}

QTable::~QTable()
{
	// TODO Auto-generated destructor stub
}

std::vector<State*>* QTable::getStates()
{
	return this->states;
}

void QTable::setStates(std::vector<State*>* states)
{
	this->states = states;
}

std::vector<Action*>* QTable::getActions()
{
	return this->actions;
}

void QTable::setActions(std::vector<Action*>* actions)
{
	this->actions = actions;
}

State* QTable::getStateById(std::string id)
{
	for (std::vector<State*>::iterator it = this->states->begin(); it != this->states->end(); it++)
	{
		if ((*it)->getId().compare(id))
		{
			return *it;
		}
	}
	return NULL;
}

bool QTable::compareFeatures(State* state, std::vector<double>* features)
{
    // If the size of the vectors don't match return false:
    if (state->getFeatures()->size() != features->size())
    {
        return false;
    }
  
    // Compare the values:
    for (int i = 0; i < state->getFeatures()->size(); i++)
    {
        if (state->getFeatures()->at(i) != features->at(i))
        {
            return false;
        }
    }

    return true;
}

State* QTable::getStateByFeatures(std::vector<double>* features)
{
    for (std::vector<State*>::iterator it = this->states->begin(); it != this->states->end(); it++)
	{
        if (compareFeatures(*it, features))
        {
            return *it;
        }
	}
	return NULL;
}

Action* QTable::getActionById(std::string id)
{
	for (std::vector<Action*>::iterator it = this->actions->begin(); it != this->actions->end(); it++)
	{
		if ((*it)->getId().compare(id))
		{
			return *it;
		}
	}
	return NULL;
}

State* QTable::addState(std::string id, double reward)
{
	State* state = new State(id, reward);
	this->states->push_back(state);
	return state;
}

Action* QTable::addAction(State* state, std::string id, double q, double learningRate)
{
	Action* action = new Action(id, q, learningRate);
	state->addAction(action);
	this->getActions()->push_back(action);
	return action;
}

State* QTable::getCurrentState()
{
	return this->currentState;
}

void QTable::setCurrentState(State* currentState)
{
	this->currentState = currentState;
}

Action* QTable::getLastAction()
{
    return this->lastAction;
}

void QTable::setLastAction(Action* lastAction)
{
    this->lastAction = lastAction;
}

void QTable::updateQ(State* resultingState)
{
	double oldQ         = lastAction->getQ();
	double reward       = resultingState->getReward();
	double learningRate = lastAction->getLearningRate();
	double maxQ         = 0;

	Action* maxQAction = resultingState->getMaxQAction();
	if (maxQAction != NULL)
	{
		maxQ = maxQAction->getQ();
	}

	// Simple update:
	// double newQ = reward + (learningRate * maxQ);

	// Full update:
	double newQ = oldQ + learningRate * (reward + (QT_DISCOUNT_FACTOR * maxQ) - oldQ);

	if (this->verboseUpdate)
	{
		std::cout << "Current state: \"" << this->currentState->getId() << "\"" << std::endl;
		std::cout << "Action \"" << lastAction->getId() << "\" " << "resulted in state \"" << resultingState->getId() << "\"" << std::endl;
		std::cout << "   Received reward: " << reward << std::endl;
		std::cout << "   Old Q: " << oldQ << std::endl;
		std::cout << "   New Q: " << newQ << std::endl;
		std::cout << std::endl;
	}

	lastAction->setQ(newQ);
	this->currentState = resultingState;
}

void QTable::print()
{
	for (std::vector<State*>::iterator sIt = this->states->begin(); sIt != this->states->end(); sIt++)
	{
		std::cout << "State \"" << (*sIt)->getId() << "\" ";
		std::cout << "(Reward = " << (*sIt)->getReward() << ")" << std::endl;

		// Iterate through the state's actions:
		std::vector<Action*>* stateActions = (*sIt)->getActions();
		for (std::vector<Action*>::iterator aIt = stateActions->begin(); aIt != stateActions->end(); aIt++)
		{
			std::cout << "    Action \"" << (*aIt)->getId() << "\" ";
			std::cout << "(Q = " << (*aIt)->getQ() << ")" << std::endl;
		}

		std::cout << std::endl;
	}
}
