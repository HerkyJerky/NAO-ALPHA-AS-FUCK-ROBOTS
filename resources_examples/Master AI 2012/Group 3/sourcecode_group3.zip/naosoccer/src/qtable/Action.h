/*
 * Action.h
 *
 * Author: Henning Metzmacher
 */

#ifndef QTABLE_ACTION_H_
#define QTABLE_ACTION_H_

#include <string>

class Action {
public:
	Action(std::string id, double q, double learningRate);
	virtual ~Action();

	std::string getId();
	void setId(std::string id);

	double getQ();
	void setQ(double q);

	double getLearningRate();
	void setLearningRate(double learningRate);

private:
	std::string id;
	double q;
	double learningRate;
};

#endif /* ACTION_H_ */
