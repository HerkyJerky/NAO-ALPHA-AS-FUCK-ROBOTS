/*
 * Action.cpp
 *
 * Author: Henning Metzmacher
 */

#include "Action.h"
#include <string>

Action::Action(std::string id, double q, double learningRate)
{
	this->id = id;
	this->q = q;
	this->learningRate = learningRate;
}

Action::~Action()
{
	// TODO Auto-generated destructor stub
}

std::string Action::getId()
{
	return this->id;
}

void Action::setId(std::string id)
{
	this->id = id;
}

double Action::getQ()
{
	return this->q;
}

void Action::setQ(double q)
{
	this->q = q;
}

double Action::getLearningRate()
{
	return this->learningRate;
}

void Action::setLearningRate(double learningRate)
{
	this->learningRate = learningRate;
}
