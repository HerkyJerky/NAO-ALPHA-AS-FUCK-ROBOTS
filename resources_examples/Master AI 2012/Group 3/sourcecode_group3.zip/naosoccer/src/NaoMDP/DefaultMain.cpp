/*
 * DefaultMain.cpp
 *
 * Author: Henning Metzmacher
 */

#include <iostream>
#include <string>
#include "Conf.h"
#include "MarkovState.h"
#include "MarkovAction.h"
#include "MarkovActionStateTransition.h"
#include "MarkovDecisionProcess.h"
#include "Random.h"

int main()
{
	// Reset the random generator:
	Random::seed();

	MarkovDecisionProcess* mdp = new MarkovDecisionProcess();
	mdp->setAutoReset(true);

	MarkovState* s1 = mdp->addMarkovState("s1");
	MarkovState* s2 = mdp->addMarkovState("s2");
	MarkovState* s3 = mdp->addMarkovState("s3");
	MarkovState* s4 = mdp->addMarkovState("s4");
	MarkovState* s5 = mdp->addMarkovState("s5");
	MarkovState* s6 = mdp->addMarkovState("s6");

	// State 6 is a final state:
	s6->setFinalState(true);

	MarkovAction* a12 = new MarkovAction("a12");
	MarkovAction* a21 = new MarkovAction("a21");
	MarkovAction* a23 = new MarkovAction("a23");
	MarkovAction* a32 = new MarkovAction("a32");
	MarkovAction* a14 = new MarkovAction("a14");
	MarkovAction* a41 = new MarkovAction("a41");
	MarkovAction* a45 = new MarkovAction("a45");
	MarkovAction* a54 = new MarkovAction("a54");
	MarkovAction* a25 = new MarkovAction("a25");
	MarkovAction* a52 = new MarkovAction("a52");
	MarkovAction* a56 = new MarkovAction("a56");
	MarkovAction* a36 = new MarkovAction("a36");

	mdp->addQAction(s1, a12, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s1, a14, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s2, a23, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s2, a21, 0,  	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s3, a36, 100,	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s3, a32, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s4, a41, 0,  	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s4, a45, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s5, a54, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s5, a52, 0,   	DEFAULT_Q, LEARNING_RATE);
	mdp->addQAction(s5, a56, 100, 	DEFAULT_Q, LEARNING_RATE);

	// Since all actions result in one specific state with probability 1.0 the
	// MDP is deterministic:
	mdp->addMarkovActionStateTransition(a12, s2, 1.0);
	mdp->addMarkovActionStateTransition(a21, s1, 1.0);
	mdp->addMarkovActionStateTransition(a23, s3, 1.0);
	mdp->addMarkovActionStateTransition(a32, s2, 1.0);
	mdp->addMarkovActionStateTransition(a14, s4, 1.0);
	mdp->addMarkovActionStateTransition(a41, s1, 1.0);
	mdp->addMarkovActionStateTransition(a45, s5, 1.0);
	mdp->addMarkovActionStateTransition(a54, s4, 1.0);
	mdp->addMarkovActionStateTransition(a25, s5, 1.0);
	mdp->addMarkovActionStateTransition(a52, s2, 1.0);
	mdp->addMarkovActionStateTransition(a56, s6, 1.0);
	mdp->addMarkovActionStateTransition(a36, s6, 1.0);

	mdp->setInitialState(s1);

	mdp->printQTable();

	for (int i = 0; i < 10; i++)
	{
		mdp->nextState();
		mdp->printQTable();
	}
}
