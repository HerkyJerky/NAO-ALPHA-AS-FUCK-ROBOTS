/*
 * GoalieStayPos.cpp
 *
 * Author:Nora Baukloh
 */

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "GoalieStayPos.h"
#include "../../base/robotStatus.h"
#include "../../motions/goalieMotions.h"
#ifdef _WIN32
#include <windows.h>
#endif
GoalieStayPos::GoalieStayPos(std::string id) : MarkovAction(id)
{
}

void GoalieStayPos::executeAction(){
	RobotStatus *robstat = RobotStatus::getInstance();
	GoalieMotions *gm = GoalieMotions::getInstance();
	while(robstat->isGoodGoaliePosition() && !(robstat->isPenalized()) && !(robstat->isFallen()) && robstat->isSeesBall()){
#ifdef _WIN32
		Sleep(2000);
		std::cout << "Sleeping" << std::endl;
#elif __linux__
		sleep(2);
#endif
	} 
	gm->fromCrouchToStand();
	std::cout << "Not in good GoaliePosition anymore!" << std::endl;
}

