/*
* KickAction.cpp
*
* Author: Nora Baukloh
*/

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/kicks.h"
#include "KickAction.h"
#include "../../base/robotStatus.h"
#include "../../motions/walk.h"


KickAction::KickAction(std::string id) : MarkovAction(id)
{
}

void KickAction::executeAction(){
	std::cout << "Execute Action: Kick" << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();
	Walk *walker = Walk::getInstance();
	//Locator *loc = Locator::getInstance();
	if(rs->getDistanceToBall() <= 0.25f){ //only kick when the ball is close.
		if(!rs->isObstacleInFront()){
			
			if(rs->getDistanceToBall() <= 0.3f){
				kick(true);
			}
		} else {
			//TODO: Obstacle avoidance
			std::cout << "Obstacle in front! We should turn now a little bit!" << std::endl;
                        if (rs->isObstacleInFront()) walker->moveAroundBall();
			std::cout << "Assuming we have turned" << std::endl;
			kick(false);
		}
	}

}

void KickAction::kick(bool strong){
	Kicks *kicker = Kicks::getInstance();
	Walk *walker = Walk::getInstance();
	RobotStatus *rs = RobotStatus::getInstance();
	//good angles for kicking:
	//left leg: -0.15 to -0.3
	//right leg: 0.15 to 0.3
	if(strong){

		if(rs->getAngleToBall() < 0) {
			if(rs->getAngleToBall() > -0.15){
				walker->stepRight(0.04,0.0);
			}else if(rs->getAngleToBall() < -0.3){
				walker->stepLeft(0.04,0.0);
			}
			kicker->kickBallLeftStrong();
		} else {
			if(rs->getAngleToBall() < 0.15){
				walker->stepLeft(0.04,0.0);
			}else if(rs->getAngleToBall() > 0.3){
				walker->stepRight(0.04,0.0);
			}
			kicker->kickBallRightStrong();
		}

	}else{
		if(rs->getAngleToBall() < 0) {
			if(rs->getAngleToBall() > -0.15){
				walker->stepRight(0.04,0.0);
			}else if(rs->getAngleToBall() < -0.3){
				walker->stepLeft(0.04,0.0);
			}
			kicker->kickBallLeftWeak();
		} else {
			if(rs->getAngleToBall() < 0.15){
				walker->stepLeft(0.04,0.0);
			}else if(rs->getAngleToBall() > 0.3){
				walker->stepRight(0.04,0.0);
			}
			kicker->kickBallRightWeak();
		}

	}

}