/**
 * @author Henning Metzmacher
 */

#ifndef NAOMDP_ACTIONS_WALKBACKWARDACTION_H_
#define NAOMDP_ACTIONS_WALKBACKWARDACTION_H_

#include <string>
#include "../MarkovDecisionProcess.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"

class WalkBackwardAction : public MarkovAction
{
public:
    WalkBackwardAction(std::string id);
    virtual void executeAction();
};

#endif // NAOMDP_ACTIONS_WALKBACKWARDACTION_H_