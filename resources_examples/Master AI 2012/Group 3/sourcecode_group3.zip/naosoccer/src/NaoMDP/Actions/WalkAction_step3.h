/*
 * WalkAction.h
 *
 * Author: Nora Baukloh
 */

#ifndef WALKACTION_step3_H_
#define WALKACTION_step3_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class WalkAction_step3 : public MarkovAction
{
public:
	WalkAction_step3(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();
private:
	bool isEpsilonEqual(double angle, double epsilon);
};

#endif /* WALKACTION_step3_H_ */
