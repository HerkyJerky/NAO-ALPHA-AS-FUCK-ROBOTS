/*
 * WalkAction.cpp
 *
 * Author: Nora Baukloh
 */
#define _USE_MATH_DEFINES
#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/walk.h"
#include "WalkAction_step3.h"
#include "../../vision/Locator.h"
#include "../../base/robotStatus.h"
#include <cmath>

WalkAction_step3::WalkAction_step3(std::string id) : MarkovAction(id)
{
}

void WalkAction_step3::executeAction(){
	std::cout << "Execute Action: Walk Step 3: adjusting angle to ball to prepare kick" << std::endl;
	//std::cout << "walking..." << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();

	Walk *walker = Walk::getInstance();

	rs->setSearchBall(true);
			std::cout << rs->getAngleToBall() << std::endl;
		while(rs->getAngleToBall() > 0.25 && !(rs->isFallen()) && !(rs->isPenalized())){
			std::cout << "step right" << std::endl;
			walker->stepRight(0.02,0.0);
		}
		while(rs->getAngleToBall() < -0.25 && !(rs->isFallen()) && !(rs->isPenalized())){
				std::cout << "step left" << std::endl;
			walker->stepLeft(0.02,0.0);

		}
}

bool WalkAction_step3::isEpsilonEqual(double angle, double epsilon){
	//std::cout << "abs current angle: " << abs(angle) << " eps: " << epsilon << " ok? " << (abs(angle) < epsilon) <<std::endl;
	return abs(angle) < epsilon;

}