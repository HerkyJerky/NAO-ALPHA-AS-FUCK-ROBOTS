/*
 * WalkAction.h
 *
 * Author: Nora Baukloh
 */

#ifndef WALKACTION_step1_H_
#define WALKACTION_step1_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class WalkAction_step1 : public MarkovAction
{
public:
	WalkAction_step1(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();
private:
	bool isEpsilonEqual(double angle, double epsilon);
};

#endif /* WALKACTION_step1_H_ */
