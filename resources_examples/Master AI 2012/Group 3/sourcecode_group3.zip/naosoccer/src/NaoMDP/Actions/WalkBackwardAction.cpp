/**
 * @author Henning Metzmacher
 */

#include <string>
#include "WalkBackwardAction.h"

WalkBackwardAction::WalkBackwardAction(std::string id) : MarkovAction(id)
{
    this->setId(id);
}

void WalkBackwardAction::executeAction()
{

}