/*
 * Wait_Unpenalize.cpp
 *
 * Author:Nora Baukloh
 */

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/kicks.h"
#include "Wait_Unpenalize.h"
#include "../../base/robotStatus.h"
#include "../../motions/standardMotions.h"
#ifdef _WIN32
#include <windows.h>
#endif
Wait_Unpenalize::Wait_Unpenalize(std::string id) : MarkovAction(id)
{
}

void Wait_Unpenalize::executeAction(){
	std::cout << "executeAction Wait_Unpenalize" << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();
	StandardMotions *sm = StandardMotions::getInstance();
	sm->poseInit();
	do{
		std::cout << "In Sleep loop: rs->isPenalized: " << rs->isPenalized() << std::endl;
		
#ifdef _WIN32
		Sleep(3000);
#elif __linux__
		sleep(3);
#endif

	} while(rs->isPenalized() && !(rs->isRestartStateMachine()));
	std::cout << "After sleeping: rs->isPenalized: " << rs->isPenalized() << std::endl;
	
}

