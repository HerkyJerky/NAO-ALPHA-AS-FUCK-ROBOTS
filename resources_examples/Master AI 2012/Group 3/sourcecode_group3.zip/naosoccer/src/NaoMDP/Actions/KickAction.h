/*
 * KickAction.h
 *
 * Author: Nora Baukloh
 */

#ifndef KICKACTION_H_
#define KICKACTION_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class KickAction : public MarkovAction
{
public:
	KickAction(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();
private:
	void kick(bool strong);
};

#endif /* KICKACTION_H_ */
