/*
 * StandUp_Action.h
 *
 * Author: Nora Baukloh
 */

#ifndef STANDUP_ACTION_H_
#define STANDUP_ACTION_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class StandUp_Action : public MarkovAction
{
public:
	StandUp_Action(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();

};

#endif /* StandUp_Action_H_ */
