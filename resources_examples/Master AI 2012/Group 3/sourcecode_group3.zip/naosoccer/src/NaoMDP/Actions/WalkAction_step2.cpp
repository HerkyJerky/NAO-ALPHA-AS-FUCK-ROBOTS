/*
* WalkAction.cpp
*
* Author: Nora Baukloh
*/
#define _USE_MATH_DEFINES
#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/walk.h"
#include "WalkAction_step2.h"
#include "../../vision/Locator.h"
#include "../../base/robotStatus.h"
#include <cmath>

WalkAction_step2::WalkAction_step2(std::string id) : MarkovAction(id)
{
}

void WalkAction_step2::executeAction(){
	//std::cout << "walking..." << std::endl;
	std::cout << "Execute Action: Walk Step 2" << std::endl;
	int counter = 0;
	RobotStatus *rs = RobotStatus::getInstance();

	Walk *walker = Walk::getInstance();
	double r = rs->getDistanceToBall();
	double d = 0.02;
	double alpha,x,y;
	rs->setSearchBall(false); //look at goal

	double epsilon = 10 * M_PI/180; //10 degree threshold...
	//std::cout << "Angle to Goal: " << rs->getAngleToGoal(rs->getTargetGoal())<< std::endl;
	while((!(isEpsilonEqual(rs->getAngleToGoal(rs->getTargetGoal()),epsilon)) || !(rs->isSeesGoal(rs->getTargetGoal()))) && !(rs->isFallen()) && !(rs->isPenalized())){
		//std::cout << "Step 2: Looking for a better angle to the Goal!" << std::endl;
		std::cout << "calculating with distance to ball: " << r << std::endl;
		if(r < 0.15){
			walker->stepTo(-0.04,0.0,0.0);
			//walker->stepTo(-0.04,0.0,0.0);
		}
		

		 alpha=acos( 1 - ( ( d*d )/( 2*r*r ) ) );
		 x = ( d*d )/( 2*r );

		 y = sqrt( ( d*d ) - ( d*d*d*d )/( 4*r*r ));

		//std::cout << "x:"<<x<<"   y:"<<y << "   alpha:" << alpha << std::endl;
		if(rs->getAngleToGoal(rs->getTargetGoal()) < 0 || rs->getAngleToGoal(rs->getTargetGoal()) == 100 ){
			walker->stepTo(x,-y,alpha);
		} else {

			walker->stepTo(x,y,-alpha);

		}
		counter++;
		if(counter == 2){
			rs->setSearchBall(true);
			while(!(rs->isSeesBall())){
#ifdef _WIN32
				Sleep(1000);
#elif __linux__
				sleep(1);
#endif
			}
				r=rs->getDistanceToBall();
				counter = 0;
				rs->setSearchBall(false);
			
		}
	}
	int ix, iy;
	rs->getHighestProbField(ix,iy);
	std::cout << "y: " << iy << std::endl;
	 alpha=acos( 1 - ( ( d*d )/( 2*r*r ) ) );
		 x = ( d*d )/( 2*r );

		 y = sqrt( ( d*d ) - ( d*d*d*d )/( 4*r*r ));
	if(iy < 2) {
		// top of the field
		
		 walker->stepTo(x,-y,alpha);
		 walker->stepTo(x,-y,alpha);
	} else {
		 walker->stepTo(x,y,-alpha);
		 walker->stepTo(x,y,-alpha);
	}
		//std::cout << "Step 2: While loop done!" << std::endl;
		rs->setSearchBall(true);
#ifdef _WIN32
		Sleep(1000);
#elif __linux__
		sleep(1);
#endif
}

bool WalkAction_step2::isEpsilonEqual(double angle, double epsilon){
	//std::cout << "abs current angle: " << abs(angle) << " eps: " << epsilon << " ok? " << (abs(angle) < epsilon) <<std::endl;
	return abs(angle) < epsilon;

}