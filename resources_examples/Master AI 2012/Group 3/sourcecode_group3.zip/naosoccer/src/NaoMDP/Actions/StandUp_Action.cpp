/*
 * StandUp_Action.cpp
 *
 * Author:Nora Baukloh
 */

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "StandUp_Action.h"
#include "../../motions/standardMotions.h"
#include "../../base/robotStatus.h"

StandUp_Action::StandUp_Action(std::string id) : MarkovAction(id)
{
	

}

void StandUp_Action::executeAction(){
	std::cout << "execute Action: standUp_Action" << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();
	StandardMotions *sm = StandardMotions::getInstance();
	std::string pose = rs->getPose();
	if(pose.compare("Back")==0){
		sm->standUpBack();
	} else if(pose.compare("Belly")==0){
		sm->standUpFront();
	} else {
		sm->sideToBack();
	}
}

