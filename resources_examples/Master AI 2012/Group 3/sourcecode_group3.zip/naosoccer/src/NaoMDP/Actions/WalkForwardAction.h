/**
 * @author Henning Metzmacher
 */

#ifndef NAOMDP_ACTIONS_WALKFORWARDACTION_H_
#define NAOMDP_ACTIONS_WALKFORWARDACTION_H_

#include <string>
#include "../MarkovDecisionProcess.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"

class WalkForwardAction : public MarkovAction
{
public:
    WalkForwardAction(std::string id);
    virtual void executeAction();
};

#endif // NAOMDP_ACTIONS_WALKFORWARDACTION_H_