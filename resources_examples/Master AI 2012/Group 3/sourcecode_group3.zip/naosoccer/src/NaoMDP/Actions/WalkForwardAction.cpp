/**
 * @author Henning Metzmacher
 */

#include <string>
#include "WalkForwardAction.h"

WalkForwardAction::WalkForwardAction(std::string id) : MarkovAction(id)
{
    this->setId(id);
}

void WalkForwardAction::executeAction()
{

}