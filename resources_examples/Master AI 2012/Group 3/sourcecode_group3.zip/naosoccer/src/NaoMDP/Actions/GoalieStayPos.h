/*
 * GoalieStayPos.h
 *
 * Author: Nora Baukloh
 */

#ifndef GOALIESTAYPOS_H_
#define GOALIESTAYPOS_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class GoalieStayPos : public MarkovAction
{
public:
	GoalieStayPos(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();

};

#endif /*GOALIESTAYPOS_H */
