/**
 * @author Henning Metzmacher
 */

#include <string>
#include "CircleAction.h"

CircleAction::CircleAction(std::string id) : MarkovAction(id)
{
    this->setId(id);
}

void CircleAction::executeAction()
{

}