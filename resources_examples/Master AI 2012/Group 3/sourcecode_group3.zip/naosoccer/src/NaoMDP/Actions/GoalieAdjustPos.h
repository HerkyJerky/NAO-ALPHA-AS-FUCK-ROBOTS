/*
 * GoalieAdjustPos.h
 *
 * Author: Nora Baukloh
 */

#ifndef GOALIEADJUSTPOS_H_
#define GOALIEADJUSTPOS_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class GoalieAdjustPos : public MarkovAction
{
public:
	GoalieAdjustPos(std::string id);

	virtual void executeAction();

	//virtual bool isFinal();

};

#endif /* GOALIEADJUSTPOS_H_ */
