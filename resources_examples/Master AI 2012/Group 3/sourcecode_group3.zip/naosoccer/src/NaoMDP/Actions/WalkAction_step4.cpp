/*
 * WalkAction.cpp
 *
 * Author: Nora Baukloh
 */
#define _USE_MATH_DEFINES
#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/walk.h"
#include "WalkAction_step4.h"
#include "../../vision/Locator.h"
#include "../../base/robotStatus.h"
#include <cmath>

WalkAction_step4::WalkAction_step4(std::string id) : MarkovAction(id)
{
}

void WalkAction_step4::executeAction(){
	std::cout << "Execute Action: Walk Step 4: stepping close to the ball!" << std::endl;
	//std::cout << "walking..." << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();

	Walk *walker = Walk::getInstance();

	rs->setSearchBall(true);

	//walk blindly, because the distance calculation on the real nao is too inaccurate.
	int counter = 0;
	while(!(rs->isFallen()) && !(rs->isPenalized()) && counter < 2){
		if(!rs->isSeesBall()){
		walker->stepForward(0.02);
		counter++;
		} else {
			if(rs->getDistanceToBall()<=0.15){
				counter = 5;
			} else {
				walker->stepForward(0.04);
			}
		}
	}
}

bool WalkAction_step4::isEpsilonEqual(double angle, double epsilon){
	//std::cout << "abs current angle: " << abs(angle) << " eps: " << epsilon << " ok? " << (abs(angle) < epsilon) <<std::endl;
	return abs(angle) < epsilon;

}