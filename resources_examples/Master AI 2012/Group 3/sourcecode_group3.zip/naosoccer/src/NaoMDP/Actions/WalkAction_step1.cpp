/*
 * WalkAction.cpp
 *
 * Author: Nora Baukloh
 */
#define _USE_MATH_DEFINES
#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "../../motions/walk.h"
#include "WalkAction_step1.h"
#include "../../vision/Locator.h"
#include "../../base/robotStatus.h"
#include <cmath>

WalkAction_step1::WalkAction_step1(std::string id) : MarkovAction(id)
{
}

void WalkAction_step1::executeAction(){
	//std::cout << "walking..." << std::endl;
	std::cout << "Execute Action: Walk Step 1" << std::endl;
	RobotStatus *rs = RobotStatus::getInstance();

	Walk *walker = Walk::getInstance();

	while((rs->getDistanceToBall() > 0.3) && !(rs->isFallen()) && !(rs->isPenalized())){
		if(rs->isSeesBall()){
		walker->goToTarget(-rs->getAngleToBall(), rs->getDistanceToBall());
                //TODO this have to be test
                if (rs->isObstacleInFront())
                {
                    walker->avoidObstacle();
                }
                //TODO -- this have to be test
		}
		std::cout << "Distance to Ball: " << rs->getDistanceToBall() << std::endl;
		std::cout << "Angle to Ball:" << rs->getAngleToBall() << std::endl;
	}
	

}

bool WalkAction_step1::isEpsilonEqual(double angle, double epsilon){
	//std::cout << "abs current angle: " << abs(angle) << " eps: " << epsilon << " ok? " << (abs(angle) < epsilon) <<std::endl;
	return abs(angle) < epsilon;

}