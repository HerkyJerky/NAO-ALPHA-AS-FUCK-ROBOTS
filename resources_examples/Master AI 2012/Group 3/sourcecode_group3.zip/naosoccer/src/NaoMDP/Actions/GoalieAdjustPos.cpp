/*
* GoalieAdjustPos.cpp
*
* Author: Nora Baukloh
*/

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "GoalieAdjustPos.h"
#include <iostream>
#include "../../motions/walk.h"
#include "../../motions/standardMotions.h"
#include "../../base/robotStatus.h"
#include "../../motions/goalieMotions.h"
#ifdef _WIN32
#include <windows.h>
#endif
GoalieAdjustPos::GoalieAdjustPos(std::string id) : MarkovAction(id)
{
}

void GoalieAdjustPos::executeAction(){
	RobotStatus *rs = RobotStatus::getInstance();
	Walk *walker = Walk::getInstance();
	StandardMotions *sm = StandardMotions::getInstance();
	GoalieMotions *gm = GoalieMotions::getInstance();
	sm->poseInit();
	int counter = 0;
	while(!rs->isSeesBall() || rs->getAngleToBall()==100.0 && !(rs->isFallen()) && !(rs->isPenalized())){
#ifdef _WIN32
		Sleep(1000);
#elif __linux__
		sleep(1);
#endif
	}
	while(!rs->isGoodGoaliePosition() && !(rs->isFallen()) && !(rs->isPenalized())){
		if(rs->isBallAtLeft()){
			walker->stepLeft(0.04f,0.2f);
		} else {
			walker->stepRight(0.04f,0.2f);
		}
	}
	//one more step due to position switch when crouching down
	if(rs->isBallAtLeft() && !(rs->isFallen()) && !(rs->isPenalized())){
		walker->stepLeft(0.04f,0.2f);
		//walker->stepLeft(0.04f,0.2f);
		sm->poseInit();
		gm->goToCrouching();
	} else if (!(rs->isBallAtLeft()) && !(rs->isFallen()) && !(rs->isPenalized())) {
		walker->stepRight(0.04f,0.2f);
		walker->stepRight(0.04f,0.2f);
		sm->poseInit();
		gm->goToCrouching();
	}


	//std::cout << "Goalie adjusting his position!" << std::endl;
}


