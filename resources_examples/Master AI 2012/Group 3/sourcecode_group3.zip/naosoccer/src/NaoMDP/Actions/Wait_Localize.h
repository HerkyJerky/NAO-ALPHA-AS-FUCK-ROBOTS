/*
 * Wait_Localize.h
 *
 * Author: Nora Baukloh
 */

#ifndef WAIT_LOCAL_H_
#define WAIT_LOCAL_H_

#include <vector>
#include <string>
#include "../MarkovActionStateTransition.h"
#include "../MarkovState.h"
#include "../MarkovAction.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class Wait_Localize : public MarkovAction
{
public:
	Wait_Localize(std::string id);

	virtual void executeAction();
	

//	virtual bool isFinal();

};

#endif /* WAIT_LOCAL_H_ */
