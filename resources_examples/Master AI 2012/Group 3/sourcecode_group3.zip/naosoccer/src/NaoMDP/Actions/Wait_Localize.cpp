/*
* Wait_Localize.cpp
*
* Author:Nora Baukloh
*/

#include "../MarkovAction.h"
#include "../MarkovState.h"
#include <string>
#include <vector>
#include "Wait_Localize.h"
#include "../../base/robotStatus.h"
#include "../../motions/walk.h"
#ifdef _WIN32
#include <windows.h>
#endif
Wait_Localize::Wait_Localize(std::string id) : MarkovAction(id)
{
}

void Wait_Localize::executeAction(){
	std::cout << "Execute Action: Wait Localize" << std::endl;
	//if ball and own position are determined, this state is left
	RobotStatus *rs = RobotStatus::getInstance();
	Walk *walker = Walk::getInstance();
	rs->setSearchBall(true);
	while(!rs->isSeesBall() && !rs->isFallen() && !rs->isPenalized()){
		if(!(rs->isGoalie())){
			//turn 90�
			walker->walkTo(0.0,0.0,1.57);
		} else {

#ifdef _WIN32
			Sleep(1000);
#elif __linux__
			sleep(1);
#endif
		}
	}

}

