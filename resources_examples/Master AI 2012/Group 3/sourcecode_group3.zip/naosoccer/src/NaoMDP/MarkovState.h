/*
 * MarkovState.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVSTATE_H_
#define MARKOVSTATE_H_

#include <vector>
#include <string>
#include "QAction.h"

// Forward declare MarkovAction:
class QAction;

class MarkovState {
public:
	MarkovState(std::string id);
	virtual ~MarkovState();
	std::string getId();
	void setId(std::string id);
	std::vector<QAction*>* getQActions();
	void setQActions(std::vector<QAction*>* qActions);
	bool isFinalState();
	void setFinalState(bool finalState);
private:
	std::vector<QAction*>* qActions;
	std::string id;
	bool finalState;
};

#endif /* MARKOVSTATE_H_ */
