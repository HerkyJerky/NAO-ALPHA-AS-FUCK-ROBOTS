/*
 * MarkovState.cpp
 *
 * Author: Henning Metzmacher
 */

#include <vector>
#include <string>
#include "MarkovState.h"
#include "QAction.h"
#include "Conf.h"

// Forward declare QAction:
class QAction;

MarkovState::MarkovState(std::string id)
{
	this->qActions = new std::vector<QAction*>();
	this->id = id;
	this->finalState = false;
}

MarkovState::~MarkovState()
{
	// TODO Implement
}

std::string MarkovState::getId()
{
	return this->id;
}

void MarkovState::setId(std::string id)
{
	this->id = id;
}

std::vector<QAction*>* MarkovState::getQActions()
{
	return this->qActions;
}

void MarkovState::setQActions(std::vector<QAction*>* qActions)
{
	this->qActions = qActions;
}

bool MarkovState::isFinalState()
{
	return this->finalState;
}

void MarkovState::setFinalState(bool finalState)
{
	this->finalState = finalState;
}
