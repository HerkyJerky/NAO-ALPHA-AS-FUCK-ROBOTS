/*
 * MarkovActionStateTransition.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVTRANSITION_H_
#define MARKOVTRANSITION_H_

#include "MarkovState.h"

// Forward declare MarkovState:
class MarkovState;

class MarkovActionStateTransition {
public:
	MarkovActionStateTransition(MarkovState* destination, double probability);
	virtual ~MarkovActionStateTransition();
	double getProbability();
	void setProbablity(double probability);
	MarkovState* getDestination();
	void setDestination(MarkovState* destination);
private:
	double probability;
	double reward;
	MarkovState* destination;
};

#endif /* MARKOVTRANSITION_H_ */
