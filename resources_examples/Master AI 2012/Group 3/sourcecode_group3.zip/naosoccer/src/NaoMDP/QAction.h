/*
 * QAction.h
 *
 * Author: Henning Metzmacher
 */

#ifndef QACTION_H_
#define QACTION_H_

#include "MarkovAction.h"
#include "MarkovState.h"

// Forward declare MarkovAction:
class MarkovAction;

// Forward declare MarkovState:
class MarkovState;

/**
 * This class encapsulates a MarkovAction, Q-value pair.
 */
class QAction {
public:
	QAction(MarkovState* markovState, MarkovAction* markovAction, double reward, double q, double learningRate);
	virtual ~QAction();
	MarkovState* getMarkovState();
	void setMarkovState(MarkovState* markovState);
	MarkovAction* getMarkovAction();
	void setMarkovAction(MarkovAction* markovAction);
	double getReward();
	void setReward();
	double getLearningRate();
	void setLearningRate(double learningRate);
	double getQ();
	void setQ(double q);
private:
	MarkovState* markovState;
	MarkovAction* markovAction;
	double reward;
	double learningRate; // Alpha
	double q;
};

#endif /* QACTION_H_ */
