/*
 * Random.cpp
 *
 * Author: Henning Metzmacher
 */

#include "Random.h"
#include <iostream>
#include <stdlib.h>
#include <ctime>
using namespace std;

Random::Random() {
    // TODO Auto-generated constructor stub

}

Random::~Random() {
    // TODO Auto-generated destructor stub
}

double Random::unifRand() {
    return (double) rand() / (double) RAND_MAX;
}

double Random::unifRand(double a, double b) {
    return (b - a)*unifRand() + a;
}

long Random::unifRand(long n) {

    if (n < 0) n = -n;
    if (n == 0) return 0;
    /* There is a slight error in that this code can produce a return value of n+1
     **
     **  return long(unifRand()*n) + 1;
     */
    //Fixed code
    long guard = (long) (unifRand() * n) + 1;
    return (guard > n) ? n : guard;
}

void Random::seed() {
    srand(time(0));
}
