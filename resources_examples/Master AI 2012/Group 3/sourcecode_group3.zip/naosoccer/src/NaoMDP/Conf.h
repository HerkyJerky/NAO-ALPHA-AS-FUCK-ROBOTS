/*
 * Conf.h
 *
 * Author: Henning Metzmacher
 */

#ifndef CONF_H_
#define CONF_H_

#define DEFAULT_Q		0
#define DISCOUNT_FACTOR	0.5 // Lambda
#define LEARNING_RATE	0.5 // Alpha

#endif /* CONF_H_ */
