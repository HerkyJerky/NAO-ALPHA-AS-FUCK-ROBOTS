/*
 * Random.h
 *
 * Author: Henning Metzmacher
 */

#ifndef RANDOM_H_
#define RANDOM_H_

class Random {
public:
	Random();
	virtual ~Random();

	/**
	 * Generates. a random number between 0 and 1.
	 *
	 * @return a uniform number in [0,1].
	 */
	static double unifRand();

	/**
	 * Generates a random number in a real interval.
	 *
	 * @param	a Lower bound of the interval
	 * @param	b Upper part of the interval
	 * @return	A uniform random number in [a, b]
	 */
	static double unifRand(double a, double b);

	/**
	 * Generate a random integer between 1 and a given value.
	 *
	 * @param	n the largest value
	 * @return	A uniform random value in [1,...,n]
	 */
	static long unifRand(long n);

	/**
	 * Resets the random number generator with the system clock.
	 */
	static void seed();
};

#endif /* RANDOM_H_ */
