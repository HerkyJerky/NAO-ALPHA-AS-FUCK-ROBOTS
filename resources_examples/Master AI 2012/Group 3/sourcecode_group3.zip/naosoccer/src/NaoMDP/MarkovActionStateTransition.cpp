/*
 * MarkovActionStateTransition.cpp
 *
 * Author: Henning Metzmacher
 */

#include "MarkovActionStateTransition.h"
#include <iostream>

MarkovActionStateTransition::MarkovActionStateTransition(MarkovState* destination, double probability)
{
	this->destination = destination;
	this->probability = probability;
}

MarkovActionStateTransition::~MarkovActionStateTransition() {
	// TODO Auto-generated destructor stub
}

double MarkovActionStateTransition::getProbability()
{
	return this->probability;
}

void MarkovActionStateTransition::setProbablity(double probability)
{
	this->probability = probability;
}

MarkovState* MarkovActionStateTransition::getDestination()
{
	return this->destination;
}

void MarkovActionStateTransition::setDestination(MarkovState* destination)
{
	this->destination = destination;
}
