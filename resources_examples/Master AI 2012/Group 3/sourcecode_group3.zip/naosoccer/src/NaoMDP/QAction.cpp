/*
 * QAction.cpp
 *
 * Author: Henning Metzmacher
 */

#include "QAction.h"
#include <iostream>

QAction::QAction(MarkovState* markovState, MarkovAction* markovAction, double reward, double q, double learningRate)
{
	this->markovState = markovState;
	this->markovAction = markovAction;
	this->reward = reward;
	this->q = q;
	this->learningRate = learningRate;
}

QAction::~QAction() {
	// TODO Auto-generated destructor stub
}

MarkovState* QAction::getMarkovState()
{
	return this->markovState;
}

void QAction::setMarkovState(MarkovState* markovState)
{
	this->markovState = markovState;
}

MarkovAction* QAction::getMarkovAction()
{
	return this->markovAction;
}

void QAction::setMarkovAction(MarkovAction* markovAction)
{
	this->markovAction = markovAction;
}


double QAction::getReward()
{
	return this->reward;
}

void QAction::setReward()
{
	this->reward = reward;
}

double QAction::getLearningRate()
{
	return this->learningRate;
}

void QAction::setLearningRate(double learningRate)
{
	this->learningRate = learningRate;
}

double QAction::getQ()
{
	return this->q;
}

void QAction::setQ(double q)
{
	this->q = q;
}
