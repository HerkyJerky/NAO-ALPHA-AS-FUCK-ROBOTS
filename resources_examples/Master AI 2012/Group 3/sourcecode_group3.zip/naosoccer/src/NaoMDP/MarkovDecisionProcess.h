/*
 * MarkovDecisionProcess.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVDECISIONPROCESS_H_
#define MARKOVDECISIONPROCESS_H_

#include <string>
#include <vector>
#include <stdlib.h>
#include "MarkovState.h"
#include "QAction.h"
#include "../base/Singleton.h"
// Forward declare MarkovState:
class MarkovState;

// Forward declare QAction:
class QAction;

class MarkovDecisionProcess : public Singleton<MarkovDecisionProcess> {
public:
	MarkovDecisionProcess();
	MarkovDecisionProcess(MarkovState* initialState);
	virtual ~MarkovDecisionProcess();
	void init();
	void printQTable();
	MarkovState* nextState();
	void setInitialState(MarkovState* initialState);
	MarkovState* getInitialState();
	void setCurrentState(MarkovState* currentState);
	MarkovState* getCurrentState();
	bool isAutoReset();
	void setAutoReset(bool autoReset);

    /**
     * Deletes all states and actions and sets the initial state and current state to NULL.
     */
    void clearAll();

	/**
	 * Returns the QAction that yields the highest Q-value for the state.
	 *
	 * @param markovState A MarkovState
	 */
	QAction* maxQAction(MarkovState* markovState);

	/**
	 * Returns the QAction that yields the highest reward for this state.
	 *
	 * @param markovState A MarkovState
	 */
	QAction* maxRewardQAction(MarkovState* markovState);

	MarkovState* addMarkovState(std::string id);
	void addQAction(MarkovState* markovState, MarkovAction* markovAction, double reward, double q, double discountFactor);

    void setMarkovActionStateTransitions(std::vector<MarkovActionStateTransition*>* markovActionStateTransitions);
    std::vector<MarkovActionStateTransition*>* getMarkovActionStateTransitions();

	void addMarkovActionStateTransition(MarkovAction* markovAction, MarkovState* destination, double probability);
	void addMarkovActionStateTransition(MarkovAction* markovAction, MarkovActionStateTransition* markovActionStateTransition);
private:
	MarkovState* initialState;
	MarkovState* currentState;
	std::vector<MarkovState*>* markovStates;
	std::vector<QAction*>* qActions;
    std::vector<MarkovActionStateTransition*>* markovActionStateTransitions;
	/**
	 * Determines if the machine is set back to the initial state after reaching
	 * a final state.
	 */
	bool autoReset;
};

#endif /* MARKOVDECISIONPROCESS_H_ */
