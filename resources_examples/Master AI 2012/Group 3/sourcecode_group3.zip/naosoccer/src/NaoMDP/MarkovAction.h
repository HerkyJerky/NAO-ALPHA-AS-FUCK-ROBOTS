/*
 * MarkovAction.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVACTION_H_
#define MARKOVACTION_H_

#include <vector>
#include <string>
#include "MarkovActionStateTransition.h"
#include "MarkovState.h"

// Forward declare MarkovState:
class MarkovState;

// Forward declare MarkovActionStateTransition:
class MarkovActionStateTransition;

class MarkovAction
{
public:
	MarkovAction(std::string id);
	virtual ~MarkovAction();

	virtual void executeAction()
	{
		// Override
	}

	virtual bool isFinal()
	{
		// Override
		return false;
	}

	std::string getId();
	void setId(std::string id);
	
	/**
	 * Normalizes the probabilities of the transitions.
	 */
	void normalize();
	MarkovState* getNextState();
	std::vector<MarkovActionStateTransition*>* getMarkovActionStateTransitions();
	void setMarkovActionStateTransitions(std::vector<MarkovActionStateTransition*>* markovActionStateTransitions);

private:
	std::vector<MarkovActionStateTransition*>* markovActionStateTransitions;
	std::string id;
};

#endif /* MARKOVACTION_H_ */
