/*
 * MarkovDecisionProcess.cpp
 *
 * Author: Henning Metzmacher
 */

#include <iostream>
#include <vector>
#include "Conf.h"
#include "MarkovDecisionProcess.h"
#include "MarkovState.h"

MarkovDecisionProcess::MarkovDecisionProcess()
{
	this->init();
}

MarkovDecisionProcess::MarkovDecisionProcess(MarkovState* initialState)
{
	this->initialState = initialState;
	this->currentState = initialState;

	this->init();
}

void MarkovDecisionProcess::init()
{
	this->setAutoReset(false);
	this->qActions = new std::vector<QAction*>();
	this->markovStates = new std::vector<MarkovState*>();
    this->markovActionStateTransitions = new std::vector<MarkovActionStateTransition*>();
}

void MarkovDecisionProcess::printQTable()
{
	for (std::vector<QAction*>::iterator it = this->qActions->begin(); it != this->qActions->end(); it++)
	{
		std::cout << "Q(" << (*it)->getMarkovState()->getId() << ", ";
		std::cout << (*it)->getMarkovAction()->getId() << ") = ";
		std::cout << (*it)->getQ();
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

MarkovState* MarkovDecisionProcess::nextState()
{
	// Get the max reward action: 
	QAction* qAction = this->maxRewardQAction(this->currentState);

	if (qAction == NULL)
	{
		if (currentState->isFinalState())
		{
			// If auto reset is on, reset the machine:
			if (isAutoReset())
			{
				currentState = initialState;
				return currentState;
			}
			// Otherwise remain in the current state:
			else
			{
				return currentState;
			}
		}
		else
		{
			throw std::exception();
		}
	}

	// Get the next state:
	MarkovState* nextState = qAction->getMarkovAction()->getNextState();

	// Update Q:
	QAction* maxQ = maxQAction(nextState);

	// Simple update:
	qAction->setQ(qAction->getReward() + qAction->getLearningRate() * ((maxQ != NULL) ? maxQ->getQ() : 0));

	// Full update:
	// qAction->setQ(qAction->getQ() + qAction->getLearningRate() * ((qAction->getReward() + (DISCOUNT_FACTOR * ((maxQ != NULL) ? maxQ->getQ() : 0))) - qAction->getQ()));

	// Execute the action:
	qAction->getMarkovAction()->executeAction();

	std::cout << "From state " << currentState->getId() << " choose action " << qAction->getMarkovAction()->getId() << std::endl;
	//std::cout << " (Reward = " << qAction->getReward() << ")" << std::endl << std::endl;

	this->currentState = nextState;
	return this->currentState;
}

MarkovDecisionProcess::~MarkovDecisionProcess()
{
	delete qActions;
	delete markovStates;
	// TODO Implement
}

void MarkovDecisionProcess::setInitialState(MarkovState* initialState)
{
	this->initialState = initialState;
	this->currentState = initialState;
}

MarkovState* MarkovDecisionProcess::getInitialState()
{
	return this->initialState;
}

void MarkovDecisionProcess::setCurrentState(MarkovState* currentState)
{
	this->currentState = currentState;
}

MarkovState* MarkovDecisionProcess::getCurrentState()
{
	return this->currentState;
}

bool MarkovDecisionProcess::isAutoReset()
{
	return this->autoReset;
}

void MarkovDecisionProcess::setAutoReset(bool autoReset)
{
	this->autoReset = autoReset;
}

void MarkovDecisionProcess::clearAll()
{
    // Delete markov states:
    while (this->markovStates->size() > 0)
    {
        // MarkovState* markovState = *(this->markovStates->end());
        this->markovStates->pop_back();
        // delete(markovState);
    }

    // Delete markov action state transitions:
    while (this->markovActionStateTransitions->size() > 0)
    {
        // MarkovActionStateTransition* markovActionStateTransition = *(this->markovActionStateTransitions->end());
        this->markovActionStateTransitions->pop_back();
        // delete(markovActionStateTransition);
    }

    // Delete q-actions:
    while (this->qActions->size() > 0)
    {
        // QAction* qAction = *(this->qActions->end());
        this->qActions->pop_back();
        // delete(qAction->getMarkovAction());
        // delete(qAction);
    }

    this->currentState = NULL;
    this->initialState = NULL;
}

QAction* MarkovDecisionProcess::maxRewardQAction(MarkovState* markovState)
{
	// Current state has no actions:
	if (markovState->getQActions()->size() == 0)
	{
		return NULL;
	}

	QAction* currentMaxRewardQAction = *(markovState->getQActions()->begin());
	for (std::vector<QAction*>::iterator it = markovState->getQActions()->begin(); it != markovState->getQActions()->end(); it++)
	{
		if ((*it)->getReward() > currentMaxRewardQAction->getReward())
		{
			currentMaxRewardQAction = *it;
		}
	}
	return currentMaxRewardQAction;
}

QAction* MarkovDecisionProcess::maxQAction(MarkovState* markovState)
{
	// Current state has no actions:
	if (markovState->getQActions()->size() == 0)
	{
		return NULL;
	}

	QAction* currentMaxQAction = *(markovState->getQActions()->begin());
	for (std::vector<QAction*>::iterator it = markovState->getQActions()->begin(); it != markovState->getQActions()->end(); it++)
	{
		if ((*it)->getQ() > currentMaxQAction->getReward())
		{
			currentMaxQAction = *it;
		}
	}
	return currentMaxQAction;
}

MarkovState* MarkovDecisionProcess::addMarkovState(std::string id)
{
	MarkovState* markovState = new MarkovState(id);
	this->markovStates->push_back(markovState);
	return markovState;
}

void MarkovDecisionProcess::addQAction(MarkovState* markovState, MarkovAction* markovAction, double reward, double q, double learningRate)
{
	// Create the QAction:
	QAction* qAction = new QAction(markovState, markovAction, reward, q, learningRate);

	// Add the QAction to the MDP table:
	this->qActions->push_back(qAction);

	// Add the QAction to the MarkovState:
	markovState->getQActions()->push_back(qAction);
}

void MarkovDecisionProcess::setMarkovActionStateTransitions(std::vector<MarkovActionStateTransition*>* markovActionStateTransitions)
{
    this->markovActionStateTransitions = markovActionStateTransitions;
}

std::vector<MarkovActionStateTransition*>* MarkovDecisionProcess::getMarkovActionStateTransitions()
{
    return this->markovActionStateTransitions;
}

void MarkovDecisionProcess::addMarkovActionStateTransition(MarkovAction* markovAction, MarkovState* destination, double probability)
{
	MarkovActionStateTransition* markovActionStateTransition = new MarkovActionStateTransition(destination, probability);
	this->addMarkovActionStateTransition(markovAction, markovActionStateTransition);
}

void MarkovDecisionProcess::addMarkovActionStateTransition(MarkovAction* markovAction, MarkovActionStateTransition* markovActionStateTransition)
{
	markovAction->getMarkovActionStateTransitions()->push_back(markovActionStateTransition);
    this->markovActionStateTransitions->push_back(markovActionStateTransition);
}
