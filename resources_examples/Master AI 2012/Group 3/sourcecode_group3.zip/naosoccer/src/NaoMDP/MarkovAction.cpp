/*
 * MarkovAction.cpp
 *
 * Author: Henning Metzmacher
 */

#include <iostream>
#include <string>
#include <vector>
#include "Conf.h"
#include "MarkovAction.h"
#include "MarkovState.h"
#include "Random.h"

MarkovAction::MarkovAction(std::string id)
{	
	this->id = id;
	this->markovActionStateTransitions = new std::vector<MarkovActionStateTransition*>();
}

MarkovAction::~MarkovAction()
{
	// TODO Implement
}

std::vector<MarkovActionStateTransition*>* MarkovAction::getMarkovActionStateTransitions()
{
	return this->markovActionStateTransitions;
}

void MarkovAction::setMarkovActionStateTransitions(std::vector<MarkovActionStateTransition*>* markovActionStateTransitions)
{
	this->markovActionStateTransitions = markovActionStateTransitions;
}

std::string MarkovAction::getId()
{
	return this->id;
}

void MarkovAction::setId(std::string id)
{
	this->id = id;
}

void MarkovAction::normalize()
{
	double sum = 0;
	for (std::vector<MarkovActionStateTransition*>::iterator it = markovActionStateTransitions->begin(); it != markovActionStateTransitions->end(); it++)
	{
		sum += (*it)->getProbability();
	}

	// Probabilities do not add up to one. Normalize:
	if (sum > 1)
	{
		for (std::vector<MarkovActionStateTransition*>::iterator it = markovActionStateTransitions->begin(); it != markovActionStateTransitions->end(); it++)
		{
			(*it)->setProbablity((*it)->getProbability() / sum);
		}
	}
}

MarkovState* MarkovAction::getNextState()
{
	// Cumulative probability:
	double cP = 0;
	double r = Random::unifRand();

	for(std::vector<MarkovActionStateTransition*>::iterator it = markovActionStateTransitions->begin(); it != markovActionStateTransitions->end(); it++)
	{
		// Probability of the transition:
		double p = (*it)->getProbability();

		// std::cout << "p = " << p << std::endl;
		// std::cout << "r = " << r << std::endl;
		// std::cout << "cP = " << cP << std::endl;
		// std::cout << "cP + p = " << cP + p << std::endl;
		// std::cout << std::endl;

		if ((r >= cP && r < (cP + p)) || (r == (cP + p) && (cP + p) == 1))
		{
		//	std::cout << "Action " << this->getId() << " results in state " << (*it)->getDestination()->getId() << std::endl << std::endl;
			return (*it)->getDestination();
		}

		cP += p;
	}

	return NULL;
}
