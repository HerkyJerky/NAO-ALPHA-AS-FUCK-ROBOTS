/**
 * @author Nora Baukloh
 *
 * should override the normal walk methods, and implement obstacle avoidance, fall detection etc...
 */

#ifndef NAOSOCCER_WALK_H
#define NAOSOCCER_WALK_H

#include <iostream>
#include <alcommon/alproxy.h>
#include <alproxies/alsonarproxy.h>
#include <alproxies/almemoryproxy.h>
#include <alproxies/almotionproxy.h>
#include <alcore/alptr.h>

#include "../base/Singleton.h"
class Walk : public Singleton<Walk>
{
public:
	Walk(void);
	virtual ~Walk(void);
	void init(AL::ALPtr<AL::ALBroker> parentBroker);
        void avoidObstacle();
        void moveAroundBall();
	void endlessWalk(); //testing purposes
	bool goToTarget(float angle, double dist);
	void stepLeft(float stepsize, float turner);
	void stepRight(float stepsize, float turner);
	void stepTo(float x, float y, float alpha);
	void stepForward(float stepsize);
	void walkTo(float x, float y, float angle);
	void stop();
private:
	  AL::ALPtr<AL::ALMotionProxy> pmotion;
	  AL::ALPtr<AL::ALMemoryProxy> pmemory;
	 // AL::ALPtr<AL::ALSonarProxy> psonar;
	  AL::ALSonarProxy *psonar;

};
#endif  // NAOSOCCER_WALK_H