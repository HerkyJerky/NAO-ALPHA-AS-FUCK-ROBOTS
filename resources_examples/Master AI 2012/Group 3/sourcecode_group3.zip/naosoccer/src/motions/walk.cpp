#include "walk.h"
#include "../vision/Locator.h"
Walk::Walk(void)
{
}

Walk::~Walk(void)
{
	psonar->unsubscribe("Sonar");
}
void Walk::init(AL::ALPtr<AL::ALBroker> parentBroker){
	try{
			pmotion = parentBroker->getMotionProxy();
			pmemory = parentBroker->getMemoryProxy();
			psonar = new AL::ALSonarProxy(parentBroker);
	}catch( AL::ALError& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	psonar->subscribe("Sonar", 500, 1.0);
	pmotion->setWalkArmsEnable(false, false);
}


void Walk::stepLeft(float stepsize, float turner){
//	std::cout << " stepLeft " << std::endl;
	//void stepTo (const string& legName, const float& x, const float& y, const float& theta)
	Locator *loc = Locator::getInstance();
	loc->stepTo("LLeg", 0.0f,stepsize,turner);
    loc->stepTo("RLeg", 0.0f,stepsize,turner);
}

void Walk::stepRight(float stepsize, float turner){
//	std::cout << " stepRight " << std::endl;
	Locator *loc = Locator::getInstance();
	loc->stepTo("RLeg", 0.0f,-stepsize,-turner);
	loc->stepTo("LLeg", 0.0f,-stepsize,-turner);
}

void Walk::stepTo(float x, float y, float alpha){
//	std::cout << " stepTo " << std::endl;
	Locator *loc = Locator::getInstance();
	loc->stepTo("RLeg",x,y,alpha);
	loc->stepTo("LLeg",x,y,alpha);
}

void Walk::stepForward(float stepsize){
	//std::cout << " stepForward " << std::endl;
	Locator *loc = Locator::getInstance();
	loc->stepTo("RLeg",stepsize,0.0f,0.0f);
	loc->stepTo("LLeg",stepsize,0.0f,0.0f);
}
bool Walk::goToTarget(float angle, double dist) {
	//std::cout << " goToTarget " << std::endl;
    //float angle = (float) -getAngle(ballX, true);
    //double dist = getDistance(ballY);
	//pmotion->setAngles("HeadYaw", 0.0f, 0.2f);
		Locator *loc = Locator::getInstance();
	if(dist/2 > 0.3f){
		loc->walkTo(cos(angle)*dist/2, sin(angle)*dist/2, angle);
		return false;
	}else {  
		loc->walkTo(cos(angle)*0.2f, sin(angle)*0.2f, angle);
        return false;
	}
    return true;
}

void Walk::walkTo(float x, float y, float angle){
Locator *loc = Locator::getInstance();
loc->walkTo(x, y, angle);
}
//TODO blind add should be test
void Walk::avoidObstacle(){
    return;
        (Locator::getInstance()->getWalkMotionProxy())->post.stopWalk();
        RobotStatus *rs = RobotStatus::getInstance();
	while (rs->isObstacleInFront() && !(rs->isFallen()) && !(rs->isPenalized())) {
            float angle=(rs->getLeftSonar() - rs->getRightSonar() )*2.0f;
			
            if(angle<-1.0f) angle=-1.0f;
            if(angle>1.0f) angle=1.0f;
            (Locator::getInstance()->getWalkMotionProxy())->setWalkTargetVelocity((((float) rs->getLeftSonar() < 0.3f) || ((float) rs->getRightSonar() < 0.3f)) ? -1.0f : 1.0f,
                    0.0f, angle, 1.0f);
        }
}

void Walk::moveAroundBall(){
    return;
        (Locator::getInstance()->getWalkMotionProxy())->post.stopWalk();
        RobotStatus *rs = RobotStatus::getInstance();
        bool loop=true;
        while (loop && !(rs->isFallen()) && !(rs->isPenalized())) {
        if (( rs->getLeftSonar()>0.5f)&&( rs->getRightSonar()>0.5f)) loop=false;
            else if (rs->getLeftSonar()<=rs->getRightSonar()) { (Locator::getInstance()->getWalkMotionProxy())->setWalkTargetVelocity(0.2f,-0.9f,0.3f,0.3f);}
            else { (Locator::getInstance()->getWalkMotionProxy())->setWalkTargetVelocity(0.2f,0.9f,-0.3f,0.3f);}
        }

}

//testing purposes
void Walk::endlessWalk(){
	while (true) {
            AL::ALValue leftFound = pmemory->getData("Device/SubDeviceList/US/Left/Sensor/Value", 0);
            AL::ALValue leftFoundDet = pmemory->getData("SonarLeftDetected");
            AL::ALValue rightFound = pmemory->getData("Device/SubDeviceList/US/Right/Sensor/Value", 0);
            AL::ALValue rightFoundDet = pmemory->getData("SonarRightDetected");

          //  printf("%f,%f,%f,%f\n", (float) leftFound, (float) leftFoundDet, (float) rightFound, (float) rightFoundDet);

            float angle=((float) leftFound - (float) rightFound )*2.0f;
			// printf("%s,%f\n","Angle ",angle);
            if(angle<-1.0f) angle=-1.0f;
            if(angle>1.0f) angle=1.0f;
            (Locator::getInstance()->getWalkMotionProxy())->setWalkTargetVelocity((((float) leftFound < 0.3f) || ((float) rightFound < 0.3f)) ? -1.0f : 1.0f,
                    0.0f, angle, 1.0f);
        }
}

void Walk::stop(){
	Locator *loc = Locator::getInstance();
        loc->killWalkMotions();
}