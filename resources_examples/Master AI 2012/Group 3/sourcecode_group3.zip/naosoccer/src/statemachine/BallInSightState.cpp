/*
 * BallInSightState.cpp
 *
 * Author: Henning Metzmacher
 */

#include "BallInSightState.h"

BallInSightState::BallInSightState()
{
}

BallInSightState::~BallInSightState()
{
}

void BallInSightState::executeAction()
{
	// TODO: Implement

	kicker = Kicks::getInstance();
	kicker->kickBallRightStrong();
}

bool BallInSightState::isFinal()
{
	return false;
}
