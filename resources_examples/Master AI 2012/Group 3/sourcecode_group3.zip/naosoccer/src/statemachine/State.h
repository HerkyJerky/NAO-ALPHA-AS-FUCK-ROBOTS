/*
 * State.h
 *
 * Author: Henning Metzmacher
 */

#ifndef STATE_H_
#define STATE_H_

class State
{
public:
	/**
	 * Is called when the state machine enters the state and should implement
	 * the action of the state.
	 */
	virtual void executeAction()
	{
		// Override
	}
	virtual bool isFinal()
	{
		return false;
	}
private:
};

#endif /* STATE_H_ */
