/*
 * Condition.h
 *
 * Author: Henning Metzmacher
 */

#ifndef CONDITION_H_
#define CONDITION_H_

class Condition
{
public:
	/**
	 * Should return whether the condition is satisfied.
	 */
	virtual bool isSatisfied()
	{
		// Override
		return false;
	}
};

#endif /* CONDITION_H_ */
