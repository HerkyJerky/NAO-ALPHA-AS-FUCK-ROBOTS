/*
 * MarkovDecisionProcess.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVDECISIONPROCESS_H_
#define MARKOVDECISIONPROCESS_H_

class MarkovDecisionProcess
{
public:
private:
};

#endif /* MARKOVDECISIONPROCESS_H_ */
