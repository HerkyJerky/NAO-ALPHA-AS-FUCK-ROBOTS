/*
* StateMachine.cpp
*
* Author: Henning Metzmacher
*/

#include <iostream>
#include "StateMachine.h"
#include "NonFinalStateException.h"

StateMachine::StateMachine() {}

StateMachine::StateMachine(Vertex<State*, Condition*>* currentVertex)
{
	paused = false;
	this->currentVertex = currentVertex;
}

StateMachine::~StateMachine()
{
	// TODO Implement
}

State* StateMachine::nextState()
{
	if(!paused){
		std::vector<Edge<State*, Condition*>* >* outIncidentEdges = currentVertex->outIncidentEdges();
		for (std::vector<Edge<State*, Condition*>* >::iterator it = outIncidentEdges->begin(); it != outIncidentEdges->end(); it++)
		{
			if ((*it)->origin() == currentVertex)
			{
				if ((*it)->getElement()->isSatisfied())
				{
					this->setCurrentVertex((*it)->destination());
					this->getCurrentVertex()->getElement()->executeAction();
					return this->getCurrentVertex()->getElement();
				}
			}
		}

		// No next state has been found, check if the state is final:
		if (currentVertex->getElement()->isFinal())
		{
			return NULL;
		}
		else
		{
			// No satisfied conditions in non-final state:
			NonFinalStateException e;
			throw e;
		}
	}
}

Vertex<State*, Condition*>* StateMachine::getCurrentVertex()
{
	return this->currentVertex;
}

void StateMachine::setCurrentVertex(Vertex<State*, Condition*>* currentVertex)
{
	this->currentVertex = currentVertex;
}

void StateMachine::pause(){
	paused= true;
}
void StateMachine::unpause(){
	paused = false;
}
