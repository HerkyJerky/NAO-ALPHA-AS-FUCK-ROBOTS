/*
 * Edge.h
 *
 * Author: Henning Metzmacher
 */

#ifndef EDGE_H_
#define EDGE_H_

#include "Vertex.h"

// Forward declaration of vertex:
template<typename V, typename E>
class Vertex;

template<typename V, typename E>
class Edge
{
public:
	Edge(E element);
	~Edge();
	E				getElement();
	void			setElement(E element);
	Vertex<V, E>*	origin();
	Vertex<V, E>*	destination();
	Vertex<V, E>*	vertices();
	Vertex<V, E>*	getV();
	Vertex<V, E>*	getW();
	void			setV(Vertex<V, E>* v);
	void			setW(Vertex<V, E>* w);
	void			setOrigin(Vertex<V, E>* origin);
	void			setDestination(Vertex<V, E>* destination);
	bool			isDirected();
	void			setDirected(bool directed);
private:
	E element;
	bool directed;
	Vertex<V, E>* v;
	Vertex<V, E>* w;
};

template<typename V, typename E>
Edge<V, E>::Edge(E element)
{
	this->element = element;
}

template<typename V, typename E>
Edge<V, E>::~Edge()
{
	// TODO: Implement
}

template<typename V, typename E>
E Edge<V, E>::getElement()
{
	return this->element;
}

template<typename V, typename E>
void Edge<V, E>::setElement(E element)
{
	this->element = element;
}

template<typename V, typename E>
Vertex<V, E>* Edge<V, E>::origin()
{
	return this->v;
}

template<typename V, typename E>
Vertex<V, E>* Edge<V, E>::destination()
{
	return this->w;
}

template<typename V, typename E>
Vertex<V, E>* Edge<V, E>::vertices()
{
	Vertex<V, E>* vertices[2];
	vertices[0] = this->v;
	vertices[1] = this->w;
	return vertices;
}

template<typename V, typename E>
Vertex<V, E>* Edge<V, E>::getV()
{
	return this->v;
}

template<typename V, typename E>
Vertex<V, E>* Edge<V, E>::getW()
{
	return this->w;
}

template<typename V, typename E>
void Edge<V, E>::setV(Vertex<V, E>* v)
{
	this->v = v;
}

template<typename V, typename E>
void Edge<V, E>::setW(Vertex<V, E>* w)
{
	this->w = w;
}

template<typename V, typename E>
void Edge<V, E>::setOrigin(Vertex<V, E>* origin)
{
	this->v = origin;
}

template<typename V, typename E>
void Edge<V, E>::setDestination(Vertex<V, E>* destination)
{
	this->w = destination;
}

template<typename V, typename E>
bool Edge<V, E>::isDirected()
{
	return this->directed;
}

#endif /* EDGE_H_ */
