/*
 * BallLocatedCondition.cpp
 *
 * Author: Henning Metzmacher
 */

#include "BallLocatedCondition.h"

BallLocatedCondition::BallLocatedCondition()
{
	// TODO Auto-generated constructor stub
}

BallLocatedCondition::~BallLocatedCondition()
{
	// TODO Auto-generated destructor stub
}

bool BallLocatedCondition::isSatisfied()
{
	// TODO Ball recognition
	return true;
}
