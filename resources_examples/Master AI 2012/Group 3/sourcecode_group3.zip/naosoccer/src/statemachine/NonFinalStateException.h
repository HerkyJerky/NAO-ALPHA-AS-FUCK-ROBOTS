/*
 * NonFinalStateException.h
 *
 * Author: Henning Metzmacher
 */

#ifndef NONFINALSTATEEXCEPTION_H_
#define NONFINALSTATEEXCEPTION_H_

class NonFinalStateException : std::exception
{
	virtual const char* what() const throw()
	{
		return "NonFinalStateException: No condition is satisfied in a non final state.";
	}
};

#endif /* NONFINALSTATEEXCEPTION_H_ */
