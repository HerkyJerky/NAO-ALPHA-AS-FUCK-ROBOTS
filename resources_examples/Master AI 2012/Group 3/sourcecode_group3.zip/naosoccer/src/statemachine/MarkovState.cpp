/*
 * MarkovState.cpp
 *
 * Author: Henning Metzmacher
 */
