/*
 * BallInSightState.h
 *
 * Author: Henning Metzmacher
 */

#ifndef BALLINSIGHTSTATE_H_
#define BALLINSIGHTSTATE_H_

#include "State.h"
#include "../motions/kicks.h"
class BallInSightState : public State
{
public:
	BallInSightState();
	virtual ~BallInSightState();
	virtual void executeAction();
	virtual bool isFinal();
private:
	Kicks *kicker;
};

#endif /* BALLINSIGHTSTATE_H_ */
