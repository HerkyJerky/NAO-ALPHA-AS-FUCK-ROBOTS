/*
 * BallNotInSightState.h
 *
 * Author: Henning Metzmacher
 */

#ifndef BALLNOTINSIGHTSTATE_H_
#define BALLNOTINSIGHTSTATE_H_

#include "State.h"
#include "../motions/kicks.h"

class BallNotInSightState : public State
{
public:
	BallNotInSightState();
	virtual ~BallNotInSightState();
	virtual void executeAction();
	virtual bool isFinal();
private:
	Kicks *kicker;
};

#endif /* BALLNOTINSIGHTSTATE_H_ */
