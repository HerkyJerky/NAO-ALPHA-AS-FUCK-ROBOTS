/*
 * Graph.h
 *
 * Author: Henning Metzmacher
 */

#ifndef GRAPH_H_
#define GRAPH_H_

#include <vector>
#include "Vertex.h"
#include "Edge.h"

template<typename V, typename E>
class Graph
{
public:
	Graph();
	~Graph();

	// General methods:
	std::vector<Edge<V, E> >*	getEdges();
	std::vector<Vertex<V, E> >*	getVertices();
	int 						numVertices();
	int 						numEdges();
	Vertex<V, E>*				aVertex();
	int 						degree(Vertex<V, E>* v);
	std::vector<Vertex<V, E> >*	adjacentVertices(Vertex<V, E>* v);
	std::vector<Vertex<V, E> >*	incidentEdges(Vertex<V, E>* v);
	Vertex<V, E>*				endVertices(Edge<V, E>* e);
	Vertex<V, E>*				opposite(Vertex<V, E>* v, Edge<V, E>* e);
	bool						areAdjacent(Vertex<V, E>* v, Vertex<V, E>* w);

	// Methods dealing with directed edges:
	int							inDegree(Vertex<V, E>* v);
	int							outDegree(Vertex<V, E>* v);
	std::vector<Edge<V, E> >*	inIncidentEdges(Vertex<V, E>* v);
	std::vector<Edge<V, E> >*	outIncidentEdges(Vertex<V, E>* v);
	std::vector<Vertex<V, E> >*	inAdjacentVertices(Vertex<V, E>* v);
	std::vector<Vertex<V, E> >*	outAdjacentVertices(Vertex<V, E>* v);

	// Methods for updating the graph:
	Edge<V, E>*					insertEdge(Vertex<V, E>* v, Vertex<V, E>* w, E element);
	Edge<V, E>*					insertDirectedEdge(Vertex<V, E>* v, Vertex<V, E>* w, E element);
	Vertex<V, E>*				insertVertex(V element);
	void						removeVertex(Vertex<V, E>* v);
	void						removeEdge(Edge<V, E>* e);
	void						makeUndirected(Edge<V, E>* e);
	void						reverseDirection(Edge<V, E>* e);
	void						setDirectionFrom(Edge<V, E>* e, Vertex<V, E>* v);
	void						setDirectionTo(Edge<V, E>* e, Vertex<V, E>* v);

private:
	std::vector<Edge<V, E>* >* edges;
	std::vector<Vertex<V, E>* >* vertices;
};

template<typename V, typename E>
Graph<V, E>::Graph()
{
	this->edges = new std::vector<Edge<V, E>* >();
	this->vertices = new std::vector<Vertex<V, E>* >();
}

template<typename V, typename E>
Graph<V, E>::~Graph()
{
	delete this->edges;
	delete this->vertices;
}

template<typename V, typename E>
std::vector<Edge<V, E> >* Graph<V, E>::getEdges()
{
	return this->edges;
}

template<typename V, typename E>
std::vector<Vertex<V, E> >* Graph<V, E>::getVertices()
{
	return this->vertices;
}

template<typename V, typename E>
int Graph<V, E>::numVertices()
{
	return this->vertices->size();
}

template<typename V, typename E>
int Graph<V, E>::numEdges()
{
	return this->edges->size();
}

template<typename V, typename E>
Vertex<V, E>* Graph<V, E>::aVertex()
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
int Graph<V, E>::degree(Vertex<V, E>* v)
{
	return v->getIncidentEdges()->size();
}

template<typename V, typename E>
std::vector<Vertex<V, E> >* Graph<V, E>::adjacentVertices(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
std::vector<Vertex<V, E> >* Graph<V, E>::incidentEdges(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
Vertex<V, E>* Graph<V, E>::endVertices(Edge<V, E>* e)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
Vertex<V, E>* Graph<V, E>::opposite(Vertex<V, E>* v, Edge<V, E>* e)
{
	if (v == e->getV())
		return e->getW();
	else
		return e->getV();
}

template<typename V, typename E>
bool Graph<V, E>::areAdjacent(Vertex<V, E>* v, Vertex<V, E>* w)
{
	// TODO: Implement
	return false;
}

template<typename V, typename E>
int	Graph<V, E>::inDegree(Vertex<V, E>* v)
{
	// TODO: Implement
	return 0;
}

template<typename V, typename E>
int	Graph<V, E>::outDegree(Vertex<V, E>* v)
{
	// TODO: Implement
	return 0;
}

template<typename V, typename E>
std::vector<Edge<V, E> >*	Graph<V, E>::inIncidentEdges(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
std::vector<Edge<V, E> >*	Graph<V, E>::outIncidentEdges(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
std::vector<Vertex<V, E> >* Graph<V, E>::inAdjacentVertices(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
std::vector<Vertex<V, E> >* Graph<V, E>::outAdjacentVertices(Vertex<V, E>* v)
{
	// TODO: Implement
	return NULL;
}

template<typename V, typename E>
Edge<V, E>*	Graph<V, E>::insertEdge(Vertex<V, E>* v, Vertex<V, E>* w, E element)
{
	Edge<V, E>* edge = new Edge<V, E>(element);
	edge->setV(v);
	edge->setW(w);

	// Add a reference to the vertices' edge lists:
	v->getIncidentEdges()->push_back(edge);
	w->getIncidentEdges()->push_back(edge);

	// Add a reference to the graph's edges list:
	edges->push_back(edge);

	return edge;
}

template<typename V, typename E>
Edge<V, E>* Graph<V, E>::insertDirectedEdge(Vertex<V, E>* origin, Vertex<V, E>* destination, E element)
{
	Edge<V, E>* edge = new Edge<V, E>(element);
	edge->setOrigin(origin);
	edge->setDesination(destination);
	edge->setDirected(true);

	// Add a reference to the vertices' edge lists:
	origin->getIncidentEdges()->push_back(edge);
	destination->getIncidentEdges()->push_back(edge);

	// Add a reference to the graph's edges list:
	edges->push_back(edge);

	return edge;
}

template<typename V, typename E>
Vertex<V, E>* Graph<V, E>::insertVertex(V element)
{
	Vertex<V, E>* vertex = new Vertex<V, E>(element);
	this->vertices->push_back(vertex);
	return vertex;
}

template<typename V, typename E>
void Graph<V, E>::removeVertex(Vertex<V, E>* v)
{
	// TODO: Implement
}

template<typename V, typename E>
void Graph<V, E>::removeEdge(Edge<V, E>* e)
{
	// TODO: Implement
}

template<typename V, typename E>
void Graph<V, E>::makeUndirected(Edge<V, E>* e)
{
	e->setDirected(false);
}

template<typename V, typename E>
void Graph<V, E>::reverseDirection(Edge<V, E>* e)
{
	Vertex<V, E>* origin = e->origin();
	e->setOrigin(e->destination());
	e->setDestination(origin);
}

template<typename V, typename E>
void Graph<V, E>::setDirectionFrom(Edge<V, E>* e, Vertex<V, E>* v)
{
	e->setOrigin(v);
}

template<typename V, typename E>
void Graph<V, E>::setDirectionTo(Edge<V, E>* e, Vertex<V, E>* v)
{
	e->setDestination(v);
}

#endif /* GRAPH_H_ */
