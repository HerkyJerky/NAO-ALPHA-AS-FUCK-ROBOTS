/*
 * StateMachine.h
 *
 * Author: Henning Metzmacher
 */

#ifndef STATEMACHINE_H_
#define STATEMACHINE_H_

#include "Graph.h"
#include "State.h"
#include "Condition.h"

class StateMachine : public Graph<State*, Condition*>
{
public:
	StateMachine();
	StateMachine(Vertex<State*, Condition*>* currentVertex);
	~StateMachine();
	/**
	 * Checks the leaving conditions and returns the next state after executing
	 * its action.
	 */
	State* nextState();
	Vertex<State*, Condition*>* getCurrentVertex();
	void setCurrentVertex(Vertex<State*, Condition*>* currentVertex);
	void pause();
	void unpause();
private:
	Vertex<State*, Condition*>* currentVertex;
	bool paused;
};

#endif /* STATEMACHINE_H_ */
