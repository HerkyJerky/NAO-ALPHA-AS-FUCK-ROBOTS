/*
 * Vertex.h
 *
 * Author: Henning Metzmacher
 */

#ifndef VERTEX_H_
#define VERTEX_H_

#include "Edge.h"
#include <vector>

// Forward declaration of edge:
template<typename V, typename E>
class Edge;

template<typename V, typename E>
class Vertex
{
public:
	Vertex(V element);
	~Vertex();

	V 							getElement();
	void 						setElement(V element);
	std::vector<Edge<V, E>* >*	getIncidentEdges();
	void						setIncidentEdges(std::vector<Edge<V, E>* >* incidentEdges);
	/**
	 * Returns an iterator of the outgoing edges of v. CAUTION: This method
	 * creates an iterator dynamically. Hence the size or the iterator itself
	 * must be stored before the actual iteration.
	 */
	std::vector<Edge<V, E>* >*	outIncidentEdges();
	/**
	 * Returns an iterator of the ingoing edges of v. CAUTION: This method
	 * creates an iterator dynamically. Hence the size or the iterator itself
	 * must be stored before the actual iteration.
	 */
	std::vector<Edge<V, E>* >* 	inIncidentEdges();
private:
	V element;
	std::vector<Edge<V, E>* >* incidentEdges;
};

template<typename V, typename E>
Vertex<V, E>::Vertex(V element)
{
	this->element = element;
	incidentEdges = new std::vector<Edge<V, E>* >();
}

template<typename V, typename E>
Vertex<V, E>::~Vertex()
{
	// TODO: Implement
}

template<typename V, typename E>
V Vertex<V, E>::getElement()
{
	return this->element;
}

template<typename V, typename E>
void Vertex<V, E>::setElement(V element)
{
	this->element = element;
}

template<typename V, typename E>
std::vector<Edge<V, E>* >* Vertex<V, E>::getIncidentEdges()
{
	return this->incidentEdges;
}

template<typename V, typename E>
void Vertex<V, E>::setIncidentEdges(std::vector<Edge<V, E>* >* incidentEdges)
{
	this->incidentEdges = incidentEdges;
}

template<typename V, typename E>
std::vector<Edge<V, E>* >* Vertex<V, E>::outIncidentEdges()
{
	std::vector<Edge<V, E>* >* outIncidentEdges = new std::vector<Edge<V, E>* >();

	// Find outgoing edges:
	for (typename std::vector<Edge<V, E>* >::iterator it = incidentEdges->begin(); it != incidentEdges->end(); it++)
	{
		if ((*it)->origin() == this)
		{
			// Add outgoing edge:
			outIncidentEdges->push_back(*it);
		}
	}
	return outIncidentEdges;
}

template<typename V, typename E>
std::vector<Edge<V, E>* >* Vertex<V, E>::inIncidentEdges()
{
	std::vector<Edge<V, E>* >* inIncidentEdges = new std::vector<Edge<V, E>* >();

	// Find outgoing edges:
	for (typename std::vector<Edge<V, E>* >::iterator it = incidentEdges->begin(); it != incidentEdges->end(); it++)
	{
		if ((*it)->destination() == this)
		{
			// Add outgoing edge:
			inIncidentEdges->push_back(*it);
		}
	}

	return inIncidentEdges;
}

#endif /* VERTEX_H_ */
