/*
 * BallNotInSightState.cpp
 *
 * Author: Henning Metzmacher
 */

#include "BallNotInSightState.h"


BallNotInSightState::BallNotInSightState()
{
	// TODO Implement
}

BallNotInSightState::~BallNotInSightState()
{
	// TODO Implement
}

void BallNotInSightState::executeAction()
{
	

	kicker = Kicks::getInstance();
	kicker->kickBallLeftStrong();
}

bool BallNotInSightState::isFinal()
{
	return false;
}
