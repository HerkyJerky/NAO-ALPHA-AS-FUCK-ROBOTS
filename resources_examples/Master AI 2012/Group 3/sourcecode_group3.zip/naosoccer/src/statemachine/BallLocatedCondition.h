/*
 * BallLocatedCondition.h
 *
 * Author: Henning Metzmacher
 */

#ifndef BALLLOCATEDCONDITION_H_
#define BALLLOCATEDCONDITION_H_

#include "Condition.h"

class BallLocatedCondition : public Condition
{
public:
	BallLocatedCondition();
	virtual ~BallLocatedCondition();
	virtual bool isSatisfied();
};

#endif /* BALLLOCATEDCONDITION_H_ */
