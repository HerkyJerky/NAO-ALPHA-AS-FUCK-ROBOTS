/*
 * DefaultMain.cpp
 *
 * Author: Henning Metzmacher
 */

#include <iostream>
#include "StateMachine.h"
#include "BallInSightState.h"
#include "BallNotInSightState.h"
#include "BallLocatedCondition.h"

int main()
{
	BallInSightState* ballInSightState 			= new BallInSightState();
	BallNotInSightState* ballNotInSightState 	= new BallNotInSightState();
	BallLocatedCondition* ballLocatedCondition 	= new BallLocatedCondition();

	StateMachine* stateMachine = new StateMachine();
	Vertex<State*, Condition*>* v1 = stateMachine->insertVertex(ballInSightState);
	Vertex<State*, Condition*>* v2 = stateMachine->insertVertex(ballNotInSightState);
	stateMachine->insertEdge(v2, v1, ballLocatedCondition);
	stateMachine->setCurrentVertex(v2);

	std::cout << "Expected: " << ballInSightState << std::endl;
	std::cout << "Actual:   " << stateMachine->nextState();
}
