/*
 * MarkovState.h
 *
 * Author: Henning Metzmacher
 */

#ifndef MARKOVSTATE_H_
#define MARKOVSTATE_H_

class MarkovState
{
public:
private:
};

#endif /* MARKOVSTATE_H_ */
