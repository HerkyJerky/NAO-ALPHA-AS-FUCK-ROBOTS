/*
* Standard Singleton implementation
*/

#ifndef SINGLETON_H_
#define SINGLETON_H_

#include <iostream>

template< class C >
class Singleton {

public:
	static C* getInstance()
	{
		if( Singleton<C>::uniqueInstance == NULL ){
			Singleton<C>::uniqueInstance = new C();
			//std::cout << "creating a new instance" << std::endl;
		}

		return Singleton<C>::uniqueInstance;
	}

	static void removeInstance()
	{
	
		if( Singleton<C>::uniqueInstance != NULL )
		{
			std::cout << "deleting instance " << std::endl;
			delete Singleton<C>::uniqueInstance;
			Singleton<C>::uniqueInstance = NULL;
		}
	}

private:
	static C *uniqueInstance;
};

// Initialize the static member CurrentInstance
template< class C >
C* Singleton<C>::uniqueInstance = NULL;

#endif /* SINGLETON_H_ */
