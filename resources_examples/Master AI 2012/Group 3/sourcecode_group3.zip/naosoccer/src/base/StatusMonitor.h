/* 
 * File:   STatusMonitor.h
 * Author: Nora Baukloh
 *
 */

#include <alcore/alptr.h>
#include <alproxies/alrobotposeproxy.h>
#include <alproxies/almemoryproxy.h>
#include "robotStatus.h"
#include <pthread.h>

#ifndef STATUSMONITOR_H
#define	STATUSMONITOR_H

class StatusMonitor {
public:
    StatusMonitor(const char* ip,int port);
    ~StatusMonitor();
	static StatusMonitor* getInstance(const char* ip,int port);
private:
    static StatusMonitor* instance;
    pthread_t worker;
    bool running;
    friend void* WorkerCode_StatusMonitor(void* arguments);
    RobotStatus* robstat;
	
    AL::ALRobotPoseProxy probotpose;
	AL::ALMemoryProxy pmemory;

    float rightBumpState, leftBumpState, chestState;
};
#endif	/*STATUSMONITOR_H */

