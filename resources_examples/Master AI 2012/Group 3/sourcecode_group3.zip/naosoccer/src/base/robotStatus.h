/*
 * robotStatus.h
 *
 * Author: Nora Baukloh
 */

// TODOS
/*
Read IP and Team Color from config File on Runtime
Permanently set goalie and field player

 */

#ifndef ROBOTSTATUS_H_
#define ROBOTSTATUS_H_

#include <iostream>
#include "constantValues.h"
#include "Leds.h"
#include <string>
#include <alproxies/almotionproxy.h>
#include <alcommon/albroker.h>
#include <alcore/alptr.h>

#include "../learning/LearningNao.h"

#define PLAYER1 1
#define PLAYER2 2

class NAOSoccer;
class LearningNao;

class RobotStatus : public Singleton<RobotStatus> {
public:
    RobotStatus();
    ~RobotStatus();

    void init(AL::ALPtr<AL::ALBroker> parentBroker, NAOSoccer *socs);
    int getTeamColor();
    int getPlayerNumber();
	
	bool getHighestProbField(int &x,int &y);
    bool isPenalized();
    bool isObstacleInFront();
    bool isSeesBall();
    bool isSeesGoal(bool blue);
    bool isGoalie();
    bool isGoodDistance();
    bool isGoodGoaliePosition();
    bool isSearchBall();
	bool getTargetGoal();
    bool isBallAtLeft();
	bool isFallen();
	bool isRestartStateMachine();
	int getSteps();
    double getDistanceToBall();
    double getDistanceToGoal(bool blue);
    double getAngleToBall();
    double getAngleToGoal(bool blue);
   // double getDistanceToObstacle();
	
	float getLeftSonar();
	float getRightSonar();
	
	std::string getPose();
    std::string getIP();
	
	void setSteps(int nStep);
    void setPenalized(bool pen);
	void setFallen(bool fell);
	void setTargetGoal(bool goal);
    void setWorking(bool work);
    void setGoodDistance(bool distanceGood);
    void setGoalie(bool goalierole);
    void setDistanceToBall(double distance);
    void setDistanceToGoalB(double distance);
    void setDistanceToGoalY(double distance);
    void setAngleToBall(double angle);
    void setAngleToGoalB(double angle);
    void setAngleToGoalY(double angle);
  //  void setDistanceToObstacle(double obstacle);
    void setSeesBall(bool seeing);
    void setSeesGoalB(bool seeing);
    void setSeesGoalY(bool seeing);
 //   void setObstacleInFront(bool isObstacle);
    void setIP(std::string ip);
	void setSearchBall(bool search);
    void setGoodGoaliePosition(bool goodGoalie);
    void switchTeamColor();
	void setPose(std::string str);
	void setSonars(float left, float right);
	void setButtons(float chest, float rightBump, float leftBump);
	void setRestartStateMachine(bool restart);
    bool isLeftBumperPressed();
    bool isRightBumperPressed();
    bool isChestButtonPressed();

    void setLearning(bool learning);
    bool isLearning();

private:
	bool targetGoal;
    ledcolor teamColor;
    int playernumber;
    std::string ip;
    Leds *leds;
    
    /**
     * Determines whether the NAO is in learning mode.
     */
    bool learning;

    bool fallen;
    bool penalized;
    bool seesBall;
    bool seesGoalB;
    bool seesGoalY;
    bool obstacleInFront;
    bool goalie;
    bool goodDistance;
    bool goodGoaliePosition;
    bool searchBall;
	bool restartStateMachine;
    double distanceToObstacle;
    double distanceToBall;
    double distanceToGoalB;
    double distanceToGoalY;
    double angleToBall;
    double angleToGoalB;
    double angleToGoalY;

    bool ballAtLeft;
	
	float leftSonar;
	float rightSonar;
	float chestButton;
	float rightBumper;
	float leftBumper;

	int steps;
	std::string pose;

	NAOSoccer *soc;
    LearningNao* learningNao;
};

#endif /* ROBOTSTATUS_H_ */
