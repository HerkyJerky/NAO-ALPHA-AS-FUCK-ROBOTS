/*
 * Leds.cpp
 *
 * author: Nora
 */

#include "Leds.h"


Leds::Leds() {
}

Leds::~Leds() {
}


void
Leds::init(AL::ALPtr<AL::ALBroker> parentBroker)
{
	try{
		pleds = AL::ALPtr<AL::ALLedsProxy>(new AL::ALLedsProxy(parentBroker));
	}catch( AL::ALError& e){
		std::cerr<<"[Leds::init] : "<<e.toString()<< std::endl;
	}
	leftFootColor = NOCOLOR;
	rightFootColor = NOCOLOR;
}



void Leds::setLed(int led, ledcolor color)
{
	std::cout << " setLED. led: " << led << " color: " << color << std::endl;
	switch(led){
		case(LEFTFOOT): 
			if(color==RED){
				  pleds->on(LEFTFOOTRED);
				  if(leftFootColor==BLUE){
					  pleds->off(LEFTFOOTBLUE);
				  }
				  leftFootColor=RED;
			} else if(color==BLUE){
				  pleds->on(LEFTFOOTBLUE);
				  if(leftFootColor==RED){
					  pleds->off(LEFTFOOTRED);
				  }
				  leftFootColor=BLUE;
			} else if (color==NOCOLOR){
				  pleds->off(LEFTFOOTBLUE);
				  pleds->off(LEFTFOOTRED);
				  leftFootColor=NOCOLOR;
			}else{
				std::cout << "wrong color at Leds::setLed(int led,int color " << color <<std::endl;
			}
			break;
		case RIGHTFOOT:	
			if(color==RED){
				  pleds->on(RIGHTFOOTRED);
				  if(rightFootColor==BLUE){
					  pleds->off(RIGHTFOOTBLUE);
				  }
				  rightFootColor=RED;
			} else if(color==BLUE){
				  pleds->on(RIGHTFOOTBLUE);
				  if(leftFootColor==RED){
					  pleds->off(RIGHTFOOTRED);
				  }
				  rightFootColor=BLUE;
			}
				  break;
		default:
			std::cout << "No viable led!: LED::setLed(intled, int color)" << std::endl;
			break;
	}
}




