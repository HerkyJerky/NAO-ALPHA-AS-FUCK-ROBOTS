/*
 * Leds.h
 *
 * Author: Nora
 */

#ifndef CONSTANT_VALUES_H_
#define CONSTANT_VALUES_H_
#include <string>

static const std::string LEFTFOOTRED = "LFoot/Led/Red/Actuator/Value";
static const std::string LEFTFOOTBLUE = "LFoot/Led/Blue/Actuator/Value";
static const std::string RIGHTFOOTRED = "RFoot/Led/Red/Actuator/Value";
static const std::string RIGHTFOOTBLUE = "RFoot/Led/Blue/Actuator/Value";

static const int LEFTFOOT = 2;
static const int RIGHTFOOT =1;
static const bool BLUEGOAL = true;
static const bool YELLOWGOAL = false;

static const bool NOT_PENALIZED = false;
static const bool PENALIZED = true;

static const int INITIAL_ST = 1;
static const int PENALIZED_ST = 2;
static const int FALLEN_ST = 3;

static const bool LEARNING_MODE = false;

enum ledcolor {
	RED = 1, BLUE = 2, NOCOLOR = 3
};

#endif /* CONSTANT_VALUES_H_ */
