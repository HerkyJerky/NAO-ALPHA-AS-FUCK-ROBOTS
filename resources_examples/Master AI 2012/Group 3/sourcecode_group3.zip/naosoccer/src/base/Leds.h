/*
 * Leds.h
 *
 * Author: Nora
 */

#ifndef LEDS_H_
#define LEDS_H_

#include "alproxies/alledsproxy.h"
#include "alcore/alptr.h"
#include "alcore/alerror.h"
#include "Singleton.h"
#include "constantValues.h"
class Leds: public Singleton<Leds>
{
public:
	Leds();
	virtual ~Leds();
	void init( AL::ALPtr<AL::ALBroker> parentBroker);
	void setLed(int led, ledcolor color);


private:
	AL::ALPtr<AL::ALLedsProxy> pleds;
    int leftFootColor;
	int rightFootColor;
};

#endif /* LEDS_H_ */
