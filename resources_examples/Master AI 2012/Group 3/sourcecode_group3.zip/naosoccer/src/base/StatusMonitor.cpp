/* 
 * File:   StatusMonitor.cpp
 * Author: Nora Baukloh
 * 
 */

#include "StatusMonitor.h"
#include <pthread.h>
#include <string>
#ifdef _WIN32
#include <windows.h>
#endif


StatusMonitor* StatusMonitor::instance = NULL;

void* WorkerCode_StatusMonitor(void* arguments) {
	StatusMonitor* me = (StatusMonitor*) arguments;
	std::string pose = "";
	std::string beforePose = "";
	while(me->running){
                pose = (std::string) me->probotpose.getActualPoseAndTime()[0];
		if(pose.compare(beforePose) != 0){
			beforePose = pose;
			me->robstat->setPose(pose);
		}
		//std::cout << "statusmonitor still running" << std::endl;
		//me->robstat->setSonars(me->pmemory.getData("Device/SubDeviceList/US/Left/Sensor/Value", 0),me->pmemory.getData("Device/SubDeviceList/US/Right/Sensor/Value", 0));
		me->robstat->setButtons(me->pmemory.getData("Device/SubDeviceList/ChestBoard/Button/Sensor/Value"),me->pmemory.getData("Device/SubDeviceList/RFoot/Bumper/Left/Sensor/Value"),me->pmemory.getData("Device/SubDeviceList/LFoot/Bumper/Left/Sensor/Value"));
		#ifdef _WIN32
		Sleep(50);
#elif __linux__
		usleep(50000);
#endif
	}
	std::cout << " THIS IS HAMENS COUT " << std::endl;
	return NULL;
}


StatusMonitor::StatusMonitor(const char* ip,int port) : pmemory(ip,port), probotpose(ip,port){
	robstat = RobotStatus::getInstance();
	running = true;
	//psonar->subscribe("Sonar", 500, 1.0);
	pthread_create(&worker, NULL, WorkerCode_StatusMonitor, (void*) this);
}

StatusMonitor::~StatusMonitor() {
	std::cout << "destroying statusmonitor" << std::endl;
    running = false;
    pthread_join(worker, NULL);
    
}

StatusMonitor* StatusMonitor::getInstance(const char* ip,int port){
	if (instance == NULL) {
        instance = new StatusMonitor(ip,port);
    }
    return instance;
}