#include "robotStatus.h"
#include <pthread.h>
#include "../vision/Locator.h"
#include "../motions/walk.h"

#include "../NaoMDP/MarkovState.h"
#include "../learning/LearningNao.h"
#include "../NAOSoccer.h"

RobotStatus::RobotStatus() {

}

RobotStatus::~RobotStatus(){}

void RobotStatus::init(AL::ALPtr<AL::ALBroker> parentBroker, NAOSoccer *socs) {
    penalized = NOT_PENALIZED;
    teamColor = RED;
	targetGoal = BLUEGOAL;
    playernumber = PLAYER1;
    leds = Leds::getInstance();
    leds->setLed(LEFTFOOT, teamColor);
    leds->setLed(RIGHTFOOT, RED);
	goodDistance = false;
    obstacleInFront = false;

    this->learning = LEARNING_MODE;

    steps = 0;
    goalie = false; //Fieldplayer red color
    goodGoaliePosition = true;
    seesBall = false;
    searchBall = true;
	fallen = false;
	soc = socs;
	rightBumper = 0;
	leftBumper = 0;
	chestButton = 0;
	restartStateMachine = false;
    learningNao = learningNao;
	
    this->learningNao = LearningNao::getInstance();
}

void RobotStatus::setGoodDistance(bool distanceGood) {
    goodDistance = distanceGood;
}

void RobotStatus::setPenalized(bool pen){
	penalized = pen;
}

bool RobotStatus::isGoodDistance() {
    return goodDistance;
}

int RobotStatus::getTeamColor() {
    return teamColor;
}

bool RobotStatus::isPenalized() {
    return penalized;
}

int RobotStatus::getPlayerNumber() {
    return playernumber;
}

bool RobotStatus::isBallAtLeft() {
    return ballAtLeft;
}

bool RobotStatus::isGoalie() {
    return goalie;
}


void RobotStatus::setGoalie(bool goalierole) {
    goalie = goalierole;
	
}

bool RobotStatus::isSeesBall() {
    return seesBall;
}

bool RobotStatus::isSeesGoal(bool blue) {
    if (blue) return seesGoalB;
    else return seesGoalY;
}

bool RobotStatus::isSearchBall() {
    return searchBall;
}

void RobotStatus::setSeesBall(bool seeing) {
    seesBall = seeing;
	if(seesBall){
        if (angleToBall < -0.4f) {
            ballAtLeft = true;
            goodGoaliePosition = false;
        } else if (angleToBall > 0.4f) {
            ballAtLeft = false;
            goodGoaliePosition = false;
        } else {
            goodGoaliePosition = true;
        }
	}
}

void RobotStatus::setSeesGoalB(bool seeing) {
	
    seesGoalB = seeing;
	
}

void RobotStatus::setSeesGoalY(bool seeing) {
    seesGoalY = seeing;
}

void RobotStatus::setDistanceToBall(double distance) {
    distanceToBall = distance;

}

double RobotStatus::getDistanceToBall() {
    return distanceToBall;
}

double RobotStatus::getDistanceToGoal(bool blue) {
    if (blue) return distanceToGoalB;
    else return distanceToGoalY;
}

double RobotStatus::getAngleToBall() {
    return angleToBall;
}

double RobotStatus::getAngleToGoal(bool blue) {
    if (blue) return angleToGoalB;
    else return angleToGoalY;
}

bool RobotStatus::isObstacleInFront() {
    return obstacleInFront;
}

void RobotStatus::setGoodGoaliePosition(bool goodGoalie) {
    goodGoaliePosition = goodGoalie;
}

bool RobotStatus::isGoodGoaliePosition() {
    return goodGoaliePosition;
}

void RobotStatus::switchTeamColor() {
    //The team color should be displayed during the whole game on the LED of the left foot (blue/red).
    switch (teamColor) {
        case RED:
            teamColor = BLUE;
            break;
        case BLUE:
            teamColor = RED;
            break;
        default:
            std::cerr << "RobotStatus::switchTeamColor: Error!" << std::endl;
    }
	targetGoal = !targetGoal;
    leds->setLed(LEFTFOOT, teamColor);
    std::cout << "Teamcolor now " << teamColor << std::endl;
}

void RobotStatus::setIP(std::string newIP) {
    ip = newIP;
}

std::string RobotStatus::getIP() {
    return ip;
}

void RobotStatus::setDistanceToGoalB(double distance) {
    distanceToGoalB = distance;
}

void RobotStatus::setAngleToGoalB(double angle) {
    angleToGoalB = angle;
}

void RobotStatus::setDistanceToGoalY(double distance) {
    distanceToGoalY = distance;
}

void RobotStatus::setAngleToGoalY(double angle) {
    angleToGoalY = angle;
}

void RobotStatus::setAngleToBall(double angle) {
    angleToBall = angle;
}

void RobotStatus::setSearchBall(bool search){
	searchBall = search;
}

bool RobotStatus::getTargetGoal(){
	return targetGoal;
}

void RobotStatus::setTargetGoal(bool goal){
	targetGoal = goal;
}

bool RobotStatus::getHighestProbField(int &x, int &y){
	Locator *loc = Locator::getInstance();
	double temp = 0.0;
	bool returnee = false;
	for(int i = 0; i < Locator::GRID_SIZE_X; i++){
		for(int j = 0; j < Locator::GRID_SIZE_Y; j++){
			//std::cout << "probability for x= " << i << "y = " << j << ": " << loc->getProbability(i,j) << std::endl;
			if(loc->getProbability(i,j) > temp) {
				temp = loc->getProbability(i,j);
				x=i;
				y = j;
				returnee = true;
			}
		}
	}

return returnee;

}

std::string RobotStatus::getPose(){
	return pose;
}

void RobotStatus::setPose(std::string str){
	pose = str;
	//std::cout << "RobotMonitor: Pose: " << pose << std::endl;
	if(pose.compare("Back")==0 || pose.compare("Belly") == 0 || pose.compare("Left") == 0 || pose.compare("Right")==0) {
		if(!fallen){
		fallen = true;
		//shoot a break event to the state machine here!
		
		}
	}
}

bool RobotStatus::isFallen(){
	return fallen;
}


void RobotStatus::setSonars(float l, float r){
	leftSonar = l;
	rightSonar = r;
	if(leftSonar < 0.3f || rightSonar < 0.3f){
		obstacleInFront = true;
	} else {
		obstacleInFront = false;
	}
}

float RobotStatus::getLeftSonar(){
	return leftSonar;
}

float RobotStatus::getRightSonar(){
	return rightSonar;
}

void RobotStatus::setFallen(bool fell){
	fallen = fell;
}
void RobotStatus::setButtons(float nChest, float nRightBump, float nLeftBump){
	// 1 means bumped
	// std::cout << "setButtons " << nChest << nRightBump << nLeftBump << std::endl;

    // Call learning functions if NAO is in learning mode and a button is
    // pressed:
    if (LEARNING_MODE)
    {
        if (nChest == 1)
        {
            this->learningNao->chestButtonAction();
        }
        if (nRightBump == 1)
        {
            this->learningNao->rightBumperAction();
        }
        if (nLeftBump == 1)
        {
            this->learningNao->leftBumperAction();
        }
    }
    else
    {
        if(nChest == 1 && chestButton ==0) // toggles penalized and reacts on the toggle
	    {
		    if(penalized){
			    penalized = NOT_PENALIZED;
			    std::cout  << "RobotStatus: Robot was unpenalized!" << std::endl;
		    } else {
		        penalized = PENALIZED;
			    std::cout << "RobotStatus: Robot was Penalized!" << std::endl;
			    //mdp->nextState();
    		
		    }
	    }
    	
	    if ((nRightBump == 1) && penalized && rightBumper == 0){ // determins if goaly or Fieldplayer
		    if(goalie){
			    std::cout << "switching to field player!" << std::endl;
			    goalie = false;
    			
			    leds->setLed(RIGHTFOOT,RED);
		    } else {
			    std::cout << "switching to goalie!" << std::endl;
			    goalie = true;
    			
			    leds->setLed(RIGHTFOOT, BLUE);
		    }	
		  restartStateMachine = true;
    	
    	
	    } else if ((nLeftBump == 1) /*&& penalized */&& leftBumper == 0){
		   /* std::cout << "Switching Team Color!" << std::endl;
		    if(teamColor == RED){
			    teamColor = BLUE;
			    std::cout << "Teamcolor now blue!" << std::endl;

		    } else {
			    teamColor = RED;
			    std::cout << "Teamcolor now red!" << std::endl;
		    }
		    leds->setLed(LEFTFOOT, teamColor);
			*/
			if(penalized){
			    penalized = NOT_PENALIZED;
			    std::cout  << "RobotStatus: Robot was unpenalized!" << std::endl;
		    } else {
		        penalized = PENALIZED;
			    std::cout << "RobotStatus: Robot was Penalized!" << std::endl;
			    //mdp->nextState();
    		
		    }
		}
    }

	chestButton = nChest;
	leftBumper = nLeftBump;
	rightBumper = nRightBump;
}

bool RobotStatus::isRestartStateMachine()
{
    return restartStateMachine;
}
void RobotStatus::setRestartStateMachine(bool rest){
	restartStateMachine = rest;
}
bool RobotStatus::isLeftBumperPressed()
{
    if (this->chestButton == 1)
    {
        return true;
    }
    return false;
}

bool RobotStatus::isRightBumperPressed()
{
    if (this->rightBumper == 1)
    {
        return true;
    }
    return false;
}

bool RobotStatus::isChestButtonPressed()
{
    if (this->leftBumper == 1)
    {
        return true;
    }
    return false;
}

void RobotStatus::setLearning(bool learning)
{
    this->learning = learning;
}

bool RobotStatus::isLearning()
{
    return this->learning;
}