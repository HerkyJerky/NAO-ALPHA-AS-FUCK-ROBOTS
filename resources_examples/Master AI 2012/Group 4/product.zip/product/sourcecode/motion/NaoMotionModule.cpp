#include "NaoMotionModule.h"
#include <qi/os.hpp>

#include <alvalue/alvalue.h>
#include <alcommon/alproxy.h>
#include <alcommon/albroker.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alvideodeviceproxy.h>
#include <alcore/alerror.h>
#include <alvision/alvisiondefinitions.h>
#include <alcore/alptr.h>

#include "../MathConstants.h"

NaoMotionModule::NaoMotionModule(ALPtr<ALBroker> pBroker, const std::string& pName) : ALModule(pBroker, pName)
{}

void NaoMotionModule::doKick(void)
{
	stiffnessOnPoseInit();
	qi::os::msleep(1000);
	kick();
	qi::os::msleep(1000);
	stiffnessOnPoseInit();
}

void NaoMotionModule::raiseHead()
{
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	//----------------------------- prepare the angles ----------------------------

	// Define The Initial Position
	std::vector<float> targetAngles;

	// Head chain
	targetAngles.push_back(-23.5);            // HeadYaw
	//targetAngles.push_back(13);

	// Convert to radians
	for (unsigned int i=0; i<targetAngles.size(); ++i)
	{
		targetAngles[i] = (float)targetAngles[i] * TO_RAD;
	}

	// We use the "Body" name to signify the collection of all joints
	std::string names = "HeadPitch";

	// We set the fraction of max speed
	float maxSpeedFraction = 0.2f;

	// Ask motion to do this with a blocking call
	proxy->angleInterpolationWithSpeed(names, targetAngles, maxSpeedFraction);
}

void NaoMotionModule::rotateHead(float angle, bool isRelative)
{
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	//----------------------------- prepare the angles ----------------------------

	// Define The Initial Position
	std::vector<float> targetAngles;

	// Head chain
	targetAngles.push_back(angle);            // HeadYaw

	// Convert to radians
	for (unsigned int i=0; i<targetAngles.size(); ++i)
	{
		targetAngles[i] = (float)targetAngles[i] * TO_RAD;
	}

	// We use the "Body" name to signify the collection of all joints
	std::string names = "HeadYaw";

	// We set the fraction of max speed
	float maxSpeedFraction = 0.05f;

	if(isRelative)
	{
		proxy->changeAngles(names, targetAngles, maxSpeedFraction);
	}
	else
	{
		// Ask motion to do this with a blocking call
		proxy->setAngles(names, targetAngles, maxSpeedFraction);
	}
}

void NaoMotionModule::kick(void)
{
	std::vector<std::string> names;
	AL::ALValue times, keys;
	names.reserve(25);
	times.arraySetSize(25);
	keys.arraySetSize(25);

	names.push_back("HeadYaw");
	times[0].arraySetSize(12);
	keys[0].arraySetSize(12);

	times[0][0] = 1.00000;
	keys[0][0] = AL::ALValue::array(-4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[0][1] = 1.40000;
	keys[0][1] = AL::ALValue::array(-4.19617e-05, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[0][2] = 1.53333;
	keys[0][2] = AL::ALValue::array(-0.00310997, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[0][3] = 1.66667;
	keys[0][3] = AL::ALValue::array(-0.00310997, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[0][4] = 2.33333;
	keys[0][4] = AL::ALValue::array(0.00149204, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[0][5] = 3.00000;
	keys[0][5] = AL::ALValue::array(-0.00157596, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[0][6] = 3.13333;
	keys[0][6] = AL::ALValue::array(-0.00157596, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[0][7] = 3.20000;
	keys[0][7] = AL::ALValue::array(-0.00157596, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[0][8] = 3.26667;
	keys[0][8] = AL::ALValue::array(-0.00157596, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[0][9] = 4.00000;
	keys[0][9] = AL::ALValue::array(-0.00310997, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[0][10] = 5.00000;
	keys[0][10] = AL::ALValue::array(-4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[0][11] = 6.00000;
	keys[0][11] = AL::ALValue::array(-4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("HeadPitch");
	times[1].arraySetSize(12);
	keys[1].arraySetSize(12);

	times[1][0] = 1.00000;
	keys[1][0] = AL::ALValue::array(0.0122300, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[1][1] = 1.40000;
	keys[1][1] = AL::ALValue::array(0.0214340, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[1][2] = 1.53333;
	keys[1][2] = AL::ALValue::array(0.0214340, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[1][3] = 1.66667;
	keys[1][3] = AL::ALValue::array(0.0214340, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[1][4] = 2.33333;
	keys[1][4] = AL::ALValue::array(0.0229680, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[1][5] = 3.00000;
	keys[1][5] = AL::ALValue::array(0.0122300, AL::ALValue::array(3, -0.222222, 0.00371879), AL::ALValue::array(3, 0.0222222, -0.000371879));
	times[1][6] = 3.06667;
	keys[1][6] = AL::ALValue::array(0.0106960, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[1][7] = 3.20000;
	keys[1][7] = AL::ALValue::array(0.0106960, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[1][8] = 3.26667;
	keys[1][8] = AL::ALValue::array(0.0122300, AL::ALValue::array(3, -0.0222222, -0.000170445), AL::ALValue::array(3, 0.244444, 0.00187489));
	times[1][9] = 4.00000;
	keys[1][9] = AL::ALValue::array(0.0168320, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[1][10] = 5.00000;
	keys[1][10] = AL::ALValue::array(0.0152980, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[1][11] = 6.00000;
	keys[1][11] = AL::ALValue::array(0.0152980, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LShoulderPitch");
	times[2].arraySetSize(12);
	keys[2].arraySetSize(12);

	times[2][0] = 1.00000;
	keys[2][0] = AL::ALValue::array(1.41737, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[2][1] = 1.40000;
	keys[2][1] = AL::ALValue::array(1.44192, AL::ALValue::array(3, -0.133333, -0.00766984), AL::ALValue::array(3, 0.0444444, 0.00255661));
	times[2][2] = 1.53333;
	keys[2][2] = AL::ALValue::array(1.44805, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[2][3] = 1.66667;
	keys[2][3] = AL::ALValue::array(1.44652, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[2][4] = 2.33333;
	keys[2][4] = AL::ALValue::array(1.54930, AL::ALValue::array(3, -0.222222, -0.00613592), AL::ALValue::array(3, 0.222222, 0.00613592));
	times[2][5] = 3.00000;
	keys[2][5] = AL::ALValue::array(1.55543, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[2][6] = 3.06667;
	keys[2][6] = AL::ALValue::array(1.54930, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[2][7] = 3.20000;
	keys[2][7] = AL::ALValue::array(1.54930, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[2][8] = 3.26667;
	keys[2][8] = AL::ALValue::array(1.54930, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[2][9] = 4.00000;
	keys[2][9] = AL::ALValue::array(1.55237, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[2][10] = 5.00000;
	keys[2][10] = AL::ALValue::array(1.54470, AL::ALValue::array(3, -0.333333, 0.00766897), AL::ALValue::array(3, 0.333333, -0.00766897));
	times[2][11] = 6.00000;
	keys[2][11] = AL::ALValue::array(1.42504, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LShoulderRoll");
	times[3].arraySetSize(12);
	keys[3].arraySetSize(12);

	times[3][0] = 1.00000;
	keys[3][0] = AL::ALValue::array(0.340507, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[3][1] = 1.40000;
	keys[3][1] = AL::ALValue::array(0.331302, AL::ALValue::array(3, -0.133333, 0.00268475), AL::ALValue::array(3, 0.0444444, -0.000894916));
	times[3][2] = 1.53333;
	keys[3][2] = AL::ALValue::array(0.329768, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[3][3] = 1.66667;
	keys[3][3] = AL::ALValue::array(0.329768, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[3][4] = 2.33333;
	keys[3][4] = AL::ALValue::array(0.179436, AL::ALValue::array(3, -0.222222, 0.0168740), AL::ALValue::array(3, 0.222222, -0.0168740));
	times[3][5] = 3.00000;
	keys[3][5] = AL::ALValue::array(0.162562, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[3][6] = 3.13333;
	keys[3][6] = AL::ALValue::array(0.164096, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[3][7] = 3.20000;
	keys[3][7] = AL::ALValue::array(0.162562, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[3][8] = 3.33333;
	keys[3][8] = AL::ALValue::array(0.162562, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[3][9] = 4.00000;
	keys[3][9] = AL::ALValue::array(0.145688, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[3][10] = 5.00000;
	keys[3][10] = AL::ALValue::array(0.161028, AL::ALValue::array(3, -0.333333, -0.0153400), AL::ALValue::array(3, 0.333333, 0.0153400));
	times[3][11] = 6.00000;
	keys[3][11] = AL::ALValue::array(0.311360, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LElbowYaw");
	times[4].arraySetSize(12);
	keys[4].arraySetSize(12);

	times[4][0] = 1.00000;
	keys[4][0] = AL::ALValue::array(-1.38831, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[4][1] = 1.40000;
	keys[4][1] = AL::ALValue::array(-1.38218, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[4][2] = 1.53333;
	keys[4][2] = AL::ALValue::array(-1.38218, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[4][3] = 1.66667;
	keys[4][3] = AL::ALValue::array(-1.38218, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[4][4] = 2.33333;
	keys[4][4] = AL::ALValue::array(-1.32082, AL::ALValue::array(3, -0.222222, -0.0107388), AL::ALValue::array(3, 0.222222, 0.0107388));
	times[4][5] = 3.00000;
	keys[4][5] = AL::ALValue::array(-1.31008, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[4][6] = 3.13333;
	keys[4][6] = AL::ALValue::array(-1.31008, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[4][7] = 3.20000;
	keys[4][7] = AL::ALValue::array(-1.31008, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[4][8] = 3.26667;
	keys[4][8] = AL::ALValue::array(-1.31008, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[4][9] = 4.00000;
	keys[4][9] = AL::ALValue::array(-1.31621, AL::ALValue::array(3, -0.244444, 0.00237966), AL::ALValue::array(3, 0.333333, -0.00324499));
	times[4][10] = 5.00000;
	keys[4][10] = AL::ALValue::array(-1.32695, AL::ALValue::array(3, -0.333333, 0.0107373), AL::ALValue::array(3, 0.333333, -0.0107373));
	times[4][11] = 6.00000;
	keys[4][11] = AL::ALValue::array(-1.38218, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LElbowRoll");
	times[5].arraySetSize(12);
	keys[5].arraySetSize(12);

	times[5][0] = 1.00000;
	keys[5][0] = AL::ALValue::array(-1.02467, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[5][1] = 1.40000;
	keys[5][1] = AL::ALValue::array(-0.989389, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[5][2] = 1.53333;
	keys[5][2] = AL::ALValue::array(-0.989389, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[5][3] = 1.66667;
	keys[5][3] = AL::ALValue::array(-0.989389, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[5][4] = 2.33333;
	keys[5][4] = AL::ALValue::array(-0.242330, AL::ALValue::array(3, -0.222222, -0.0107388), AL::ALValue::array(3, 0.222222, 0.0107388));
	times[5][5] = 3.00000;
	keys[5][5] = AL::ALValue::array(-0.231591, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[5][6] = 3.13333;
	keys[5][6] = AL::ALValue::array(-0.231591, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[5][7] = 3.20000;
	keys[5][7] = AL::ALValue::array(-0.231591, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[5][8] = 3.26667;
	keys[5][8] = AL::ALValue::array(-0.231591, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[5][9] = 4.00000;
	keys[5][9] = AL::ALValue::array(-0.233125, AL::ALValue::array(3, -0.244444, 0.00151447), AL::ALValue::array(3, 0.333333, -0.00206519));
	times[5][10] = 5.00000;
	keys[5][10] = AL::ALValue::array(-0.242330, AL::ALValue::array(3, -0.333333, 0.00920487), AL::ALValue::array(3, 0.333333, -0.00920487));
	times[5][11] = 6.00000;
	keys[5][11] = AL::ALValue::array(-1.02007, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LWristYaw");
	times[6].arraySetSize(12);
	keys[6].arraySetSize(12);

	times[6][0] = 1.00000;
	keys[6][0] = AL::ALValue::array(-0.0123140, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[6][1] = 1.40000;
	keys[6][1] = AL::ALValue::array(-0.0353239, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[6][2] = 1.53333;
	keys[6][2] = AL::ALValue::array(-0.0353239, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[6][3] = 1.66667;
	keys[6][3] = AL::ALValue::array(-0.0353239, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[6][4] = 2.33333;
	keys[6][4] = AL::ALValue::array(-0.349794, AL::ALValue::array(3, -0.222222, 0.0230101), AL::ALValue::array(3, 0.222222, -0.0230101));
	times[6][5] = 3.00000;
	keys[6][5] = AL::ALValue::array(-0.372804, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[6][6] = 3.06667;
	keys[6][6] = AL::ALValue::array(-0.372804, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[6][7] = 3.20000;
	keys[6][7] = AL::ALValue::array(-0.372804, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[6][8] = 3.26667;
	keys[6][8] = AL::ALValue::array(-0.372804, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[6][9] = 4.00000;
	keys[6][9] = AL::ALValue::array(-0.351328, AL::ALValue::array(3, -0.244444, -0.00584106), AL::ALValue::array(3, 0.333333, 0.00796508));
	times[6][10] = 5.00000;
	keys[6][10] = AL::ALValue::array(-0.331386, AL::ALValue::array(3, -0.333333, -0.0199421), AL::ALValue::array(3, 0.333333, 0.0199421));
	times[6][11] = 6.00000;
	keys[6][11] = AL::ALValue::array(-0.0184499, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LHand");
	times[7].arraySetSize(12);
	keys[7].arraySetSize(12);

	times[7][0] = 1.00000;
	keys[7][0] = AL::ALValue::array(0.000132645, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[7][1] = 1.40000;
	keys[7][1] = AL::ALValue::array(0.000258309, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[7][2] = 1.53333;
	keys[7][2] = AL::ALValue::array(0.000258309, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[7][3] = 1.66667;
	keys[7][3] = AL::ALValue::array(0.000258309, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[7][4] = 2.33333;
	keys[7][4] = AL::ALValue::array(0.00230383, AL::ALValue::array(3, -0.222222, -1.39629e-05), AL::ALValue::array(3, 0.222222, 1.39629e-05));
	times[7][5] = 3.00000;
	keys[7][5] = AL::ALValue::array(0.00231780, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[7][6] = 3.13333;
	keys[7][6] = AL::ALValue::array(0.00231780, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[7][7] = 3.20000;
	keys[7][7] = AL::ALValue::array(0.00231082, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[7][8] = 3.26667;
	keys[7][8] = AL::ALValue::array(0.00231780, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[7][9] = 4.00000;
	keys[7][9] = AL::ALValue::array(0.000244346, AL::ALValue::array(3, -0.244444, 5.63158e-05), AL::ALValue::array(3, 0.333333, -7.67943e-05));
	times[7][10] = 5.00000;
	keys[7][10] = AL::ALValue::array(0.000167552, AL::ALValue::array(3, -0.333333, 1.86168e-05), AL::ALValue::array(3, 0.333333, -1.86168e-05));
	times[7][11] = 6.00000;
	keys[7][11] = AL::ALValue::array(0.000132645, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RShoulderPitch");
	times[8].arraySetSize(12);
	keys[8].arraySetSize(12);

	times[8][0] = 1.00000;
	keys[8][0] = AL::ALValue::array(1.42666, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[8][1] = 1.40000;
	keys[8][1] = AL::ALValue::array(1.46348, AL::ALValue::array(3, -0.133333, -0.0103546), AL::ALValue::array(3, 0.0444444, 0.00345153));
	times[8][2] = 1.53333;
	keys[8][2] = AL::ALValue::array(1.46808, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[8][3] = 1.66667;
	keys[8][3] = AL::ALValue::array(1.46808, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[8][4] = 2.33333;
	keys[8][4] = AL::ALValue::array(1.51717, AL::ALValue::array(3, -0.222222, -0.0107378), AL::ALValue::array(3, 0.222222, 0.0107378));
	times[8][5] = 3.00000;
	keys[8][5] = AL::ALValue::array(1.53251, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[8][6] = 3.06667;
	keys[8][6] = AL::ALValue::array(1.53251, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[8][7] = 3.20000;
	keys[8][7] = AL::ALValue::array(1.53251, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[8][8] = 3.26667;
	keys[8][8] = AL::ALValue::array(1.53251, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[8][9] = 4.00000;
	keys[8][9] = AL::ALValue::array(1.53251, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[8][10] = 5.00000;
	keys[8][10] = AL::ALValue::array(1.52024, AL::ALValue::array(3, -0.333333, 0.0122713), AL::ALValue::array(3, 0.333333, -0.0122713));
	times[8][11] = 6.00000;
	keys[8][11] = AL::ALValue::array(1.42973, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RShoulderRoll");
	times[9].arraySetSize(12);
	keys[9].arraySetSize(12);

	times[9][0] = 1.00000;
	keys[9][0] = AL::ALValue::array(-0.309909, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[9][1] = 1.40000;
	keys[9][1] = AL::ALValue::array(-0.276162, AL::ALValue::array(3, -0.133333, -0.0103542), AL::ALValue::array(3, 0.0444444, 0.00345139));
	times[9][2] = 1.53333;
	keys[9][2] = AL::ALValue::array(-0.268493, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[9][3] = 1.66667;
	keys[9][3] = AL::ALValue::array(-0.268493, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[9][4] = 2.33333;
	keys[9][4] = AL::ALValue::array(-0.167248, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[9][5] = 3.00000;
	keys[9][5] = AL::ALValue::array(-0.177985, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[9][6] = 3.13333;
	keys[9][6] = AL::ALValue::array(-0.177985, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[9][7] = 3.20000;
	keys[9][7] = AL::ALValue::array(-0.177985, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[9][8] = 3.26667;
	keys[9][8] = AL::ALValue::array(-0.177985, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[9][9] = 4.00000;
	keys[9][9] = AL::ALValue::array(-0.170316, AL::ALValue::array(3, -0.244444, -0.00216322), AL::ALValue::array(3, 0.333333, 0.00294984));
	times[9][10] = 5.00000;
	keys[9][10] = AL::ALValue::array(-0.162646, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[9][11] = 6.00000;
	keys[9][11] = AL::ALValue::array(-0.314512, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RElbowYaw");
	times[10].arraySetSize(12);
	keys[10].arraySetSize(12);

	times[10][0] = 1.00000;
	keys[10][0] = AL::ALValue::array(1.38056, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[10][1] = 1.40000;
	keys[10][1] = AL::ALValue::array(1.37135, AL::ALValue::array(3, -0.133333, 0.00268430), AL::ALValue::array(3, 0.0444444, -0.000894767));
	times[10][2] = 1.53333;
	keys[10][2] = AL::ALValue::array(1.36982, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[10][3] = 1.66667;
	keys[10][3] = AL::ALValue::array(1.36982, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[10][4] = 2.33333;
	keys[10][4] = AL::ALValue::array(0.420274, AL::ALValue::array(3, -0.222222, 0.00920362), AL::ALValue::array(3, 0.222222, -0.00920362));
	times[10][5] = 3.00000;
	keys[10][5] = AL::ALValue::array(0.411070, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[10][6] = 3.13333;
	keys[10][6] = AL::ALValue::array(0.411070, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[10][7] = 3.20000;
	keys[10][7] = AL::ALValue::array(0.411070, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[10][8] = 3.26667;
	keys[10][8] = AL::ALValue::array(0.411070, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[10][9] = 4.00000;
	keys[10][9] = AL::ALValue::array(0.417205, AL::ALValue::array(3, -0.244444, -0.00216329), AL::ALValue::array(3, 0.333333, 0.00294994));
	times[10][10] = 5.00000;
	keys[10][10] = AL::ALValue::array(0.426410, AL::ALValue::array(3, -0.333333, -0.00920485), AL::ALValue::array(3, 0.333333, 0.00920485));
	times[10][11] = 6.00000;
	keys[10][11] = AL::ALValue::array(1.37902, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RElbowRoll");
	times[11].arraySetSize(12);
	keys[11].arraySetSize(12);

	times[11][0] = 1.00000;
	keys[11][0] = AL::ALValue::array(1.01402, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[11][1] = 1.40000;
	keys[11][1] = AL::ALValue::array(0.984870, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[11][2] = 1.53333;
	keys[11][2] = AL::ALValue::array(0.984870, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[11][3] = 1.66667;
	keys[11][3] = AL::ALValue::array(0.984870, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[11][4] = 2.33333;
	keys[11][4] = AL::ALValue::array(0.0890140, AL::ALValue::array(3, -0.222222, 0.0260781), AL::ALValue::array(3, 0.222222, -0.0260781));
	times[11][5] = 3.00000;
	keys[11][5] = AL::ALValue::array(0.0629359, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[11][6] = 3.13333;
	keys[11][6] = AL::ALValue::array(0.0629359, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[11][7] = 3.20000;
	keys[11][7] = AL::ALValue::array(0.0629359, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[11][8] = 3.26667;
	keys[11][8] = AL::ALValue::array(0.0629359, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[11][9] = 4.00000;
	keys[11][9] = AL::ALValue::array(0.0859459, AL::ALValue::array(3, -0.244444, -0.00692268), AL::ALValue::array(3, 0.333333, 0.00944002));
	times[11][10] = 5.00000;
	keys[11][10] = AL::ALValue::array(0.112024, AL::ALValue::array(3, -0.333333, -0.0260780), AL::ALValue::array(3, 0.333333, 0.0260780));
	times[11][11] = 6.00000;
	keys[11][11] = AL::ALValue::array(1.00941, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RWristYaw");
	times[12].arraySetSize(12);
	keys[12].arraySetSize(12);

	times[12][0] = 1.00000;
	keys[12][0] = AL::ALValue::array(-0.00310997, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[12][1] = 1.40000;
	keys[12][1] = AL::ALValue::array(0.0199001, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[12][2] = 1.53333;
	keys[12][2] = AL::ALValue::array(0.0199001, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[12][3] = 1.66667;
	keys[12][3] = AL::ALValue::array(0.0199001, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[12][4] = 2.33333;
	keys[12][4] = AL::ALValue::array(0.0183660, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[12][5] = 3.00000;
	keys[12][5] = AL::ALValue::array(0.0306380, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[12][6] = 3.06667;
	keys[12][6] = AL::ALValue::array(0.0306380, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[12][7] = 3.20000;
	keys[12][7] = AL::ALValue::array(0.0306380, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[12][8] = 3.26667;
	keys[12][8] = AL::ALValue::array(0.0306380, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[12][9] = 4.00000;
	keys[12][9] = AL::ALValue::array(0.0245020, AL::ALValue::array(3, -0.244444, 0.00151433), AL::ALValue::array(3, 0.333333, -0.00206499));
	times[12][10] = 5.00000;
	keys[12][10] = AL::ALValue::array(0.0199001, AL::ALValue::array(3, -0.333333, 0.00102265), AL::ALValue::array(3, 0.333333, -0.00102265));
	times[12][11] = 6.00000;
	keys[12][11] = AL::ALValue::array(0.0183661, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RHand");
	times[13].arraySetSize(12);
	keys[13].arraySetSize(12);

	times[13][0] = 1.00000;
	keys[13][0] = AL::ALValue::array(0.000111701, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[13][1] = 1.40000;
	keys[13][1] = AL::ALValue::array(0.000216421, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[13][2] = 1.53333;
	keys[13][2] = AL::ALValue::array(0.000216421, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[13][3] = 1.66667;
	keys[13][3] = AL::ALValue::array(0.000216421, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[13][4] = 2.33333;
	keys[13][4] = AL::ALValue::array(0.000600393, AL::ALValue::array(3, -0.222222, -6.98157e-06), AL::ALValue::array(3, 0.222222, 6.98157e-06));
	times[13][5] = 3.00000;
	keys[13][5] = AL::ALValue::array(0.000607375, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[13][6] = 3.13333;
	keys[13][6] = AL::ALValue::array(0.000607375, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[13][7] = 3.20000;
	keys[13][7] = AL::ALValue::array(0.000614356, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[13][8] = 3.26667;
	keys[13][8] = AL::ALValue::array(0.000614356, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[13][9] = 4.00000;
	keys[13][9] = AL::ALValue::array(0.000216421, AL::ALValue::array(3, -0.244444, 5.63158e-05), AL::ALValue::array(3, 0.333333, -7.67943e-05));
	times[13][10] = 5.00000;
	keys[13][10] = AL::ALValue::array(0.000139627, AL::ALValue::array(3, -0.333333, 1.62897e-05), AL::ALValue::array(3, 0.333333, -1.62897e-05));
	times[13][11] = 6.00000;
	keys[13][11] = AL::ALValue::array(0.000118683, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LHipYawPitch");
	times[14].arraySetSize(12);
	keys[14].arraySetSize(12);

	times[14][0] = 1.00000;
	keys[14][0] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[14][1] = 1.40000;
	keys[14][1] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[14][2] = 1.53333;
	keys[14][2] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[14][3] = 1.66667;
	keys[14][3] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[14][4] = 2.33333;
	keys[14][4] = AL::ALValue::array(0.00157596, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[14][5] = 3.00000;
	keys[14][5] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[14][6] = 3.13333;
	keys[14][6] = AL::ALValue::array(0.00157596, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[14][7] = 3.20000;
	keys[14][7] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[14][8] = 3.26667;
	keys[14][8] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[14][9] = 4.00000;
	keys[14][9] = AL::ALValue::array(0.00464395, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[14][10] = 5.00000;
	keys[14][10] = AL::ALValue::array(0.00464395, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[14][11] = 6.00000;
	keys[14][11] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LHipRoll");
	times[15].arraySetSize(12);
	keys[15].arraySetSize(12);

	times[15][0] = 1.00000;
	keys[15][0] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[15][1] = 1.40000;
	keys[15][1] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[15][2] = 1.53333;
	keys[15][2] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[15][3] = 1.66667;
	keys[15][3] = AL::ALValue::array(0.0138480, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[15][4] = 2.33333;
	keys[15][4] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[15][5] = 3.00000;
	keys[15][5] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[15][6] = 3.06667;
	keys[15][6] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[15][7] = 3.20000;
	keys[15][7] = AL::ALValue::array(0.0153820, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[15][8] = 3.26667;
	keys[15][8] = AL::ALValue::array(0.0138480, AL::ALValue::array(3, -0.0222222, 8.52220e-05), AL::ALValue::array(3, 0.244444, -0.000937442));
	times[15][9] = 4.00000;
	keys[15][9] = AL::ALValue::array(0.0123140, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[15][10] = 5.00000;
	keys[15][10] = AL::ALValue::array(0.0123140, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[15][11] = 6.00000;
	keys[15][11] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LHipPitch");
	times[16].arraySetSize(12);
	keys[16].arraySetSize(12);

	times[16][0] = 1.00000;
	keys[16][0] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[16][1] = 1.40000;
	keys[16][1] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[16][2] = 1.53333;
	keys[16][2] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[16][3] = 1.66667;
	keys[16][3] = AL::ALValue::array(-0.688724, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[16][4] = 2.33333;
	keys[16][4] = AL::ALValue::array(-0.691792, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[16][5] = 3.00000;
	keys[16][5] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.222222, -0.00127828), AL::ALValue::array(3, 0.0444444, 0.000255656));
	times[16][6] = 3.13333;
	keys[16][6] = AL::ALValue::array(-0.687190, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[16][7] = 3.20000;
	keys[16][7] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[16][8] = 3.26667;
	keys[16][8] = AL::ALValue::array(-0.690259, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[16][9] = 4.00000;
	keys[16][9] = AL::ALValue::array(-0.685656, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[16][10] = 5.00000;
	keys[16][10] = AL::ALValue::array(-0.685656, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[16][11] = 6.00000;
	keys[16][11] = AL::ALValue::array(-0.435613, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LKneePitch");
	times[17].arraySetSize(12);
	keys[17].arraySetSize(12);

	times[17][0] = 1.00000;
	keys[17][0] = AL::ALValue::array(1.13512, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[17][1] = 1.40000;
	keys[17][1] = AL::ALValue::array(1.13512, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[17][2] = 1.53333;
	keys[17][2] = AL::ALValue::array(1.13819, AL::ALValue::array(3, -0.0444444, -0.000766791), AL::ALValue::array(3, 0.0444444, 0.000766791));
	times[17][3] = 1.66667;
	keys[17][3] = AL::ALValue::array(1.13972, AL::ALValue::array(3, -0.0444444, -0.000340840), AL::ALValue::array(3, 0.222222, 0.00170420));
	times[17][4] = 2.33333;
	keys[17][4] = AL::ALValue::array(1.14432, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[17][5] = 3.00000;
	keys[17][5] = AL::ALValue::array(1.14279, AL::ALValue::array(3, -0.222222, 0.00139477), AL::ALValue::array(3, 0.0222222, -0.000139477));
	times[17][6] = 3.06667;
	keys[17][6] = AL::ALValue::array(1.13972, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[17][7] = 3.20000;
	keys[17][7] = AL::ALValue::array(1.13972, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[17][8] = 3.26667;
	keys[17][8] = AL::ALValue::array(1.14125, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[17][9] = 4.00000;
	keys[17][9] = AL::ALValue::array(1.14125, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[17][10] = 5.00000;
	keys[17][10] = AL::ALValue::array(1.14586, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[17][11] = 6.00000;
	keys[17][11] = AL::ALValue::array(0.700996, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LAnklePitch");
	times[18].arraySetSize(12);
	keys[18].arraySetSize(12);

	times[18][0] = 1.00000;
	keys[18][0] = AL::ALValue::array(-0.515466, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[18][1] = 1.40000;
	keys[18][1] = AL::ALValue::array(-0.513931, AL::ALValue::array(3, -0.133333, -0.00115061), AL::ALValue::array(3, 0.0444444, 0.000383537));
	times[18][2] = 1.53333;
	keys[18][2] = AL::ALValue::array(-0.510863, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[18][3] = 1.66667;
	keys[18][3] = AL::ALValue::array(-0.510863, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[18][4] = 2.33333;
	keys[18][4] = AL::ALValue::array(-0.515466, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[18][5] = 3.00000;
	keys[18][5] = AL::ALValue::array(-0.515466, AL::ALValue::array(3, -0.222222, -3.99474e-07), AL::ALValue::array(3, 0.0444444, 7.98948e-08));
	times[18][6] = 3.13333;
	keys[18][6] = AL::ALValue::array(-0.512397, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[18][7] = 3.20000;
	keys[18][7] = AL::ALValue::array(-0.517000, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[18][8] = 3.26667;
	keys[18][8] = AL::ALValue::array(-0.515466, AL::ALValue::array(3, -0.0222222, -8.52304e-05), AL::ALValue::array(3, 0.244444, 0.000937534));
	times[18][9] = 4.00000;
	keys[18][9] = AL::ALValue::array(-0.513931, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[18][10] = 5.00000;
	keys[18][10] = AL::ALValue::array(-0.513931, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[18][11] = 6.00000;
	keys[18][11] = AL::ALValue::array(-0.351328, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("LAnkleRoll");
	times[19].arraySetSize(12);
	keys[19].arraySetSize(12);

	times[19][0] = 1.00000;
	keys[19][0] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[19][1] = 1.40000;
	keys[19][1] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[19][2] = 1.53333;
	keys[19][2] = AL::ALValue::array(0.237812, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[19][3] = 1.66667;
	keys[19][3] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.0444444, -4.66053e-08), AL::ALValue::array(3, 0.222222, 2.33027e-07));
	times[19][4] = 2.33333;
	keys[19][4] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[19][5] = 3.00000;
	keys[19][5] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[19][6] = 3.13333;
	keys[19][6] = AL::ALValue::array(0.240880, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[19][7] = 3.20000;
	keys[19][7] = AL::ALValue::array(0.239346, AL::ALValue::array(3, -0.0222222, 0.00102276), AL::ALValue::array(3, 0.0222222, -0.00102276));
	times[19][8] = 3.26667;
	keys[19][8] = AL::ALValue::array(0.234743, AL::ALValue::array(3, -0.0222222, -0.000000), AL::ALValue::array(3, 0.244444, 0.000000));
	times[19][9] = 4.00000;
	keys[19][9] = AL::ALValue::array(0.234743, AL::ALValue::array(3, -0.244444, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[19][10] = 5.00000;
	keys[19][10] = AL::ALValue::array(0.233209, AL::ALValue::array(3, -0.333333, 0.00153413), AL::ALValue::array(3, 0.333333, -0.00153413));
	times[19][11] = 6.00000;
	keys[19][11] = AL::ALValue::array(0.00310997, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RHipRoll");
	times[20].arraySetSize(12);
	keys[20].arraySetSize(12);

	times[20][0] = 1.00000;
	keys[20][0] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[20][1] = 1.40000;
	keys[20][1] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[20][2] = 1.53333;
	keys[20][2] = AL::ALValue::array(0.0399260, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[20][3] = 1.66667;
	keys[20][3] = AL::ALValue::array(0.0383920, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[20][4] = 2.33333;
	keys[20][4] = AL::ALValue::array(0.0798100, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[20][5] = 3.00000;
	keys[20][5] = AL::ALValue::array(0.0736740, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[20][6] = 3.13333;
	keys[20][6] = AL::ALValue::array(0.0736740, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[20][7] = 3.20000;
	keys[20][7] = AL::ALValue::array(0.0706059, AL::ALValue::array(3, -0.0222222, 0.000511343), AL::ALValue::array(3, 0.0444444, -0.00102269));
	times[20][8] = 3.33333;
	keys[20][8] = AL::ALValue::array(0.0690719, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[20][9] = 4.00000;
	keys[20][9] = AL::ALValue::array(0.0905480, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[20][10] = 5.00000;
	keys[20][10] = AL::ALValue::array(0.00924597, AL::ALValue::array(3, -0.333333, 0.00920401), AL::ALValue::array(3, 0.333333, -0.00920401));
	times[20][11] = 6.00000;
	keys[20][11] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RHipPitch");
	times[21].arraySetSize(12);
	keys[21].arraySetSize(12);

	times[21][0] = 1.00000;
	keys[21][0] = AL::ALValue::array(-0.438765, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[21][1] = 1.40000;
	keys[21][1] = AL::ALValue::array(-0.438765, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[21][2] = 1.53333;
	keys[21][2] = AL::ALValue::array(-0.478650, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[21][3] = 1.66667;
	keys[21][3] = AL::ALValue::array(-0.461776, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[21][4] = 2.33333;
	keys[21][4] = AL::ALValue::array(-0.500126, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[21][5] = 3.00000;
	keys[21][5] = AL::ALValue::array(0.371186, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[21][6] = 3.13333;
	keys[21][6] = AL::ALValue::array(-0.329852, AL::ALValue::array(3, -0.0444444, 0.211351), AL::ALValue::array(3, 0.0222222, -0.105676));
	times[21][7] = 3.20000;
	keys[21][7] = AL::ALValue::array(-0.579894, AL::ALValue::array(3, -0.0222222, 0.0669848), AL::ALValue::array(3, 0.0444444, -0.133970));
	times[21][8] = 3.33333;
	keys[21][8] = AL::ALValue::array(-0.932714, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[21][9] = 4.00000;
	keys[21][9] = AL::ALValue::array(-0.800790, AL::ALValue::array(3, -0.222222, -0.0687232), AL::ALValue::array(3, 0.333333, 0.103085));
	times[21][10] = 5.00000;
	keys[21][10] = AL::ALValue::array(-0.417291, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[21][11] = 6.00000;
	keys[21][11] = AL::ALValue::array(-0.437231, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RKneePitch");
	times[22].arraySetSize(12);
	keys[22].arraySetSize(12);

	times[22][0] = 1.00000;
	keys[22][0] = AL::ALValue::array(0.694945, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[22][1] = 1.40000;
	keys[22][1] = AL::ALValue::array(0.694945, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[22][2] = 1.53333;
	keys[22][2] = AL::ALValue::array(1.19349, AL::ALValue::array(3, -0.0444444, -0.128856), AL::ALValue::array(3, 0.0444444, 0.128856));
	times[22][3] = 1.66667;
	keys[22][3] = AL::ALValue::array(1.46808, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[22][4] = 2.33333;
	keys[22][4] = AL::ALValue::array(1.31621, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[22][5] = 3.00000;
	keys[22][5] = AL::ALValue::array(1.74880, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[22][6] = 3.13333;
	keys[22][6] = AL::ALValue::array(1.62148, AL::ALValue::array(3, -0.0444444, 0.127322), AL::ALValue::array(3, 0.0222222, -0.0636609));
	times[22][7] = 3.20000;
	keys[22][7] = AL::ALValue::array(1.11373, AL::ALValue::array(3, -0.0222222, 0.142151), AL::ALValue::array(3, 0.0444444, -0.284301));
	times[22][8] = 3.33333;
	keys[22][8] = AL::ALValue::array(0.342125, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[22][9] = 4.00000;
	keys[22][9] = AL::ALValue::array(1.52024, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[22][10] = 5.00000;
	keys[22][10] = AL::ALValue::array(0.796188, AL::ALValue::array(3, -0.333333, 0.0997089), AL::ALValue::array(3, 0.333333, -0.0997089));
	times[22][11] = 6.00000;
	keys[22][11] = AL::ALValue::array(0.696479, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RAnklePitch");
	times[23].arraySetSize(12);
	keys[23].arraySetSize(12);

	times[23][0] = 1.00000;
	keys[23][0] = AL::ALValue::array(-0.351244, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[23][1] = 1.40000;
	keys[23][1] = AL::ALValue::array(-0.351244, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[23][2] = 1.53333;
	keys[23][2] = AL::ALValue::array(-0.834454, AL::ALValue::array(3, -0.0444444, 0.122464), AL::ALValue::array(3, 0.0444444, -0.122464));
	times[23][3] = 1.66667;
	keys[23][3] = AL::ALValue::array(-1.08603, AL::ALValue::array(3, -0.0444444, 0.0194307), AL::ALValue::array(3, 0.222222, -0.0971533));
	times[23][4] = 2.33333;
	keys[23][4] = AL::ALValue::array(-1.18421, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[23][5] = 3.00000;
	keys[23][5] = AL::ALValue::array(-0.794570, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[23][6] = 3.13333;
	keys[23][6] = AL::ALValue::array(-0.803775, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[23][7] = 3.20000;
	keys[23][7] = AL::ALValue::array(-0.604353, AL::ALValue::array(3, -0.0222222, -0.149650), AL::ALValue::array(3, 0.0444444, 0.299301));
	times[23][8] = 3.33333;
	keys[23][8] = AL::ALValue::array(0.543078, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[23][9] = 4.00000;
	keys[23][9] = AL::ALValue::array(-0.940300, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[23][10] = 5.00000;
	keys[23][10] = AL::ALValue::array(-0.477032, AL::ALValue::array(3, -0.333333, -0.0986873), AL::ALValue::array(3, 0.333333, 0.0986873));
	times[23][11] = 6.00000;
	keys[23][11] = AL::ALValue::array(-0.348176, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	names.push_back("RAnkleRoll");
	times[24].arraySetSize(12);
	keys[24].arraySetSize(12);

	times[24][0] = 1.00000;
	keys[24][0] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.133333, 0.000000));
	times[24][1] = 1.40000;
	keys[24][1] = AL::ALValue::array(4.19617e-05, AL::ALValue::array(3, -0.133333, -0.000000), AL::ALValue::array(3, 0.0444444, 0.000000));
	times[24][2] = 1.53333;
	keys[24][2] = AL::ALValue::array(-0.00302603, AL::ALValue::array(3, -0.0444444, 0.000767000), AL::ALValue::array(3, 0.0444444, -0.000767000));
	times[24][3] = 1.66667;
	keys[24][3] = AL::ALValue::array(-0.00456004, AL::ALValue::array(3, -0.0444444, 0.00153400), AL::ALValue::array(3, 0.222222, -0.00767002));
	times[24][4] = 2.33333;
	keys[24][4] = AL::ALValue::array(-0.0505800, AL::ALValue::array(3, -0.222222, 0.0324696), AL::ALValue::array(3, 0.222222, -0.0324696));
	times[24][5] = 3.00000;
	keys[24][5] = AL::ALValue::array(-0.199378, AL::ALValue::array(3, -0.222222, 0.0153415), AL::ALValue::array(3, 0.0444444, -0.00306829));
	times[24][6] = 3.13333;
	keys[24][6] = AL::ALValue::array(-0.202446, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.0222222, 0.000000));
	times[24][7] = 3.20000;
	keys[24][7] = AL::ALValue::array(0.119694, AL::ALValue::array(3, -0.0222222, -0.0138060), AL::ALValue::array(3, 0.0444444, 0.0276120));
	times[24][8] = 3.33333;
	keys[24][8] = AL::ALValue::array(0.147306, AL::ALValue::array(3, -0.0444444, -0.000000), AL::ALValue::array(3, 0.222222, 0.000000));
	times[24][9] = 4.00000;
	keys[24][9] = AL::ALValue::array(0.128898, AL::ALValue::array(3, -0.222222, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[24][10] = 5.00000;
	keys[24][10] = AL::ALValue::array(0.162646, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.333333, 0.000000));
	times[24][11] = 6.00000;
	keys[24][11] = AL::ALValue::array(0.00157596, AL::ALValue::array(3, -0.333333, -0.000000), AL::ALValue::array(3, 0.000000, 0.000000));

	try
	{
		int moveId = getParentBroker()->getMotionProxy()->post.angleInterpolationBezier(names, times, keys);
	}

	catch(AL::ALError&)
	{

	}
}

void NaoMotionModule::stiffnessOnPoseInit() {
	stiffnessOn();
	poseInit();
}

/// <summary> Moves Nao to the init pose. </summary>
void NaoMotionModule::poseInit() {
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	//----------------------------- prepare the angles ----------------------------
	// Get the Type of Nao
	AL::ALValue robotConfig = proxy->getRobotConfig();
	std::string robotType = (std::string) robotConfig[1][0];

	// Feel free to experiment with these values
	float HeadYawAngle       = 0.0f;
	float HeadPitchAngle     = 0.0f;

	float ShoulderPitchAngle = 80.0f;
	float ShoulderRollAngle  = 20.0f;
	float ElbowYawAngle      = -80.0f;
	float ElbowRollAngle     = -60.0f;
	float WristYawAngle      = 0.0f;
	float HandAngle          = 0.0f;

	float HipYawPitchAngle   = 0.0f;
	float HipRollAngle       = 0.0f;
	float HipPitchAngle      = -25.0f;
	float KneePitchAngle     = 40.0f;
	float AnklePitchAngle    = -20.0f;
	float AnkleRollAngle     = 0.0f;

	// Define The Initial Position
	std::vector<float> targetAngles;

	// Head chain
	targetAngles.push_back(HeadYawAngle);                // HeadYaw
	targetAngles.push_back(HeadPitchAngle);              // HeadPitch

	// LArm chain
	if (
		(robotType == "naoH25") ||
		(robotType == "naoT14"))
	{
		targetAngles.push_back(ShoulderPitchAngle);        // LShoulderPitch
		targetAngles.push_back(ShoulderRollAngle);         // LShoulderRoll
		targetAngles.push_back(ElbowYawAngle);             // LElbowYaw
		targetAngles.push_back(ElbowRollAngle);            // LElbowRoll
		targetAngles.push_back(WristYawAngle);             // LWristYaw
		targetAngles.push_back(HandAngle);                 // LHand
	}
	else if (robotType == "naoRobocup")
	{
		targetAngles.push_back(ShoulderPitchAngle);        // LShoulderPitch
		targetAngles.push_back(ShoulderRollAngle);         // LShoulderRoll
		targetAngles.push_back(ElbowYawAngle);             // LElbowYaw
		targetAngles.push_back(ElbowRollAngle);            // LElbowRoll
	}

	// LLeg chain
	if (
		(robotType == "naoH25") ||
		(robotType == "naoRobocup"))
	{
		targetAngles.push_back(HipYawPitchAngle);          // LHipYawPitch
		targetAngles.push_back(HipRollAngle);              // LHipRoll
		targetAngles.push_back(HipPitchAngle);             // LHipPitch
		targetAngles.push_back(KneePitchAngle);            // LKneePitch
		targetAngles.push_back(AnklePitchAngle);           // LAnklePitch
		targetAngles.push_back(AnkleRollAngle);            // LAnkleRoll
	}

	// RLeg chain
	if (
		(robotType == "naoH25") ||
		(robotType == "naoRobocup"))
	{
		targetAngles.push_back(HipYawPitchAngle);          // RHipYawPitch
		targetAngles.push_back(-HipRollAngle);             // RHipRoll
		targetAngles.push_back(HipPitchAngle);             // RHipPitch
		targetAngles.push_back(KneePitchAngle);            // RKneePitch
		targetAngles.push_back(AnklePitchAngle);           // RAnklePitch
		targetAngles.push_back(-AnkleRollAngle);           // RAnkleRoll
	}

	// RArm chain
	if (
		(robotType == "naoH25") ||
		(robotType == "naoT14"))
	{
		targetAngles.push_back(ShoulderPitchAngle);        // RShoulderPitch
		targetAngles.push_back(-ShoulderRollAngle);        // RShoulderRoll
		targetAngles.push_back(-ElbowYawAngle);            // RElbowYaw
		targetAngles.push_back(-ElbowRollAngle);           // RElbowRoll
		targetAngles.push_back(WristYawAngle);             // RWristYaw
		targetAngles.push_back(HandAngle);                 // RHand
	}
	else if (robotType == "naoRobocup")
	{
		targetAngles.push_back(ShoulderPitchAngle);        // RShoulderPitch
		targetAngles.push_back(-ShoulderRollAngle);        // RShoulderRoll
		targetAngles.push_back(-ElbowYawAngle);            // RElbowYaw
		targetAngles.push_back(-ElbowRollAngle);           // RElbowRoll
	}

	// Convert to radians
	for (unsigned int i=0; i<targetAngles.size(); ++i)
	{
		targetAngles[i] = (float)targetAngles[i] * TO_RAD;
	}

	// We use the "Body" name to signify the collection of all joints
	std::string names = "Body";

	// We set the fraction of max speed
	float maxSpeedFraction = 0.2f;

	// Ask motion to do this with a blocking call
	proxy->angleInterpolationWithSpeed(names, targetAngles, maxSpeedFraction);
}

/// <summary> Sets the stiffness to the maximum value. </summary>
void NaoMotionModule::stiffnessOn() {
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	// We use the "Body" name to signify the collection of all joints
	const std::string names = "Body";
	float stiffnessLists = 1.0f;
	float timeLists      = 1.0f;

	// the interpolation command will assume that the same value is desired
	// for all joints in the collection "Body"
	proxy->stiffnessInterpolation(names, stiffnessLists, timeLists);
}

/// <summary> Sets the stiffness to the minimum value. </summary>
void NaoMotionModule::stiffnessOff() {
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	// We use the "Body" name to signify the collection of all joints
	const std::string names = "Body";
	float stiffnessLists = 0.0f;
	float timeLists      = 1.0f;

	// the interpolation command will assume that the same value is desired
	// for all joints in the collection "Body"
	proxy->stiffnessInterpolation(names, stiffnessLists, timeLists);
}

/// <summary> Walks using the walkTo command and shows odometry. </summary>
void NaoMotionModule::walkTo(float x, float y, float theta) {
	AL::ALPtr<AL::ALMotionProxy> proxy = getParentBroker()->getMotionProxy();

	// Set NAO to stiffness On
	stiffnessOn();

	//// Enable arms control by Walk algorithm
	proxy->setWalkArmsEnable(true, true);

	// Enable foor contact protection
	proxy->setMotionConfig(AL::ALValue::array(
		AL::ALValue::array("ENABLE_FOOT_CONTACT_PROTECTION", true)));

	proxy->post.walkTo(x, y, theta);
	int job = getParentBroker()->getProxy("ALMotion")->pCall("waitUntilWalkIsFinished");
	getParentBroker()->getProxy("ALMotion")->wait(job,0);
}