#include "PenalizedState.h"
#include "StateMachine.h"

#include <alproxies/alledsproxy.h>
#include <alproxies/almemoryproxy.h>

#include <iostream>
using namespace std;

PenalizedState::PenalizedState(StateMachine *s) : State(s)
{

}

cStates PenalizedState::run(void)
{
	this->init();

	while(this->sm->isPenalized())
	{
		AL::ALPtr<AL::ALMemoryProxy> proxy = AL::ALPtr<AL::ALMemoryProxy>( new AL::ALMemoryProxy(this->sm->getParentBroker()) );
		
		if(proxy->getData("RearTactilTouched").toString()[0] == '1')
		{
			cout << "Transitioning to ExitState ..." << endl;
			return CLOSE;
		}
	}

	this->exit();

	cout << "Transitioning to TrackBallState ..." << endl;
	return TRACKBALL;
}

void PenalizedState::init(void)
{
	cout << "Initializing PenalizedState ... " << endl;
	this->proxy = AL::ALPtr<AL::ALLedsProxy>( new AL::ALLedsProxy(this->sm->getParentBroker()) );
	proxy->fadeRGB("FaceLeds", 0xFF0000, 1);
}

void PenalizedState::exit(void)
{
	cout << "Exiting PenalizedState ... " << endl;
	proxy->setIntensity("FaceLeds", 0);
}