#ifndef GET_WAYPOINT
#define GET_WAYPOINT
#include "State.h"
#include <alproxies/alledsproxy.h>
#include <alcore/alptr.h>

class GetWayPointState : public State
{
public:
	GetWayPointState(StateMachine*);
	virtual cStates run(void);

private:
	virtual void init(void);
	virtual void exit(void);
	AL::ALPtr<AL::ALLedsProxy> proxy;
};
#endif