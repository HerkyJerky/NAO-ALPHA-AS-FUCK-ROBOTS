#ifndef STATE
#define STATE
class StateMachine;

enum cStates { PENALIZED, TRACKBALL, CLOSE, LOCALIZE, FINDBALL };

class State
{
protected:
	StateMachine *sm;
	State(StateMachine * _sm) : sm(_sm) {}
	virtual void init(void) = 0;
	virtual void exit(void) = 0;

public:
	virtual cStates run(void) = 0;
};
#endif