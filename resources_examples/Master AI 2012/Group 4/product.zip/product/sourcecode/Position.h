#ifndef POSITION_H
#define POSITION_H

class Position
{
private:
	float posX, posY;

public:
	Position(): posX(DEFAULT_X), posY(DEFAULT_Y) {}

	float getX() const;
	float getY() const;

	void setX(float const x);
	void setY(float const y);

	static const float DEFAULT_X;
	static const float DEFAULT_Y;
};

#endif