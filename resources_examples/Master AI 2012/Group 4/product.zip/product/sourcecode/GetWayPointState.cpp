#include "GetWayPointState.h"
#include "StateMachine.h"
#include "Field.h"
#include "NaoPosition.h"
#include "Position.h"
#include <iostream>
#include "MathConstants.h"
using namespace std;

GetWayPointState::GetWayPointState(StateMachine* s) : State(s)
{
}

cStates GetWayPointState::run()
{
	this->init();

	float naoX, naoY, naoOrientation, ballX, ballY;

	naoX = 1.00f;
	naoY = 3.10f;
	naoOrientation = 179; 
	ballX = 1.80f;
	ballY = 2.00f;

	Field f;
	f.setBallPosition(ballX, ballY);
	f.setNaoPosition(naoX, naoY, naoOrientation);
	Position const ball = f.getBallPosition();
	NaoPosition const own = f.getOwnPosition();

	NaoPosition target;


	/* Maybe another case is needed, where the Nao is actually located on the right side of the ball,
	but is to close to the ball to let this algorithm work, taking into account the Nao's motion model */
	if(ball.getX() < own.getX())
	{
		// Nao is on the right side of the ball
		if(ball.getY() < own.getY())
		{
			// Nao has to walk up
			cout << "Facing up ... " << endl;
			cout << own.getOrientation() - 270.0f << endl;
			cout << own.getY() - ball.getY() << endl;
		}
		else
		{
			// Nao has to walk down
			cout << "Facing down ... " << endl;
			cout << own.getOrientation() - 90.0 << endl;
			cout << ball.getY() - own.getY() << endl;
		}
	}
	else
	{
		cout << (- own.getOrientation()) << ", " << (- own.getOrientation()) * TO_RAD << endl;
		// Nao has to walk around the ball

		if(ball.getY() < own.getY())
		{
			// Nao has to walk up
		}
		else
		{
			// Nao has to walk down
		}
	} 

	this->exit();

	cout << "Transitioning to PenalizedState ..." << endl;
	return PENALIZED;
}

void GetWayPointState::init(void)
{
	cout << "Initializing TrackBallState ... " << endl;
	this->proxy = AL::ALPtr<AL::ALLedsProxy>( new AL::ALLedsProxy(this->sm->getParentBroker()) );
	proxy->fadeRGB("FaceLeds", 0x00FF00, 1);
}

void GetWayPointState::exit(void)
{
	cout << "Exiting TrackBallState ... " << endl;
	proxy->setIntensity("FaceLeds", 0);
}