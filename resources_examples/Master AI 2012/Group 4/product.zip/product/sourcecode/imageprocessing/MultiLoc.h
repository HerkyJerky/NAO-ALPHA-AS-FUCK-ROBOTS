#ifndef MULTILOC_H
#define MULTILOC_H 1

#include <alcommon/almodule.h>
#include <alcore/altypes.h>
#include <alcore/alptr.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alvideodeviceproxy.h>
#include <almath/types/alpose2d.h>

#include <opencv/cxtypes.h>

#include <vector>

#include "NaoLocationParticle.h"

#ifdef STATEMACHINE_IS_REMOTE_ON
#define USE_OPENCV_UI 1
#endif

using namespace AL;
using namespace std;

class MultiLoc : public ALModule
{
public:
	enum Status{STOPPED, RUNNING, SUSPENDED};

	MultiLoc(ALPtr<ALBroker> pBroker, const std::string& pName);
	virtual ~MultiLoc();
	virtual void init();

	void start();
	void stop();
	void suspend();
	void restart();

	vector<float> const & getOwnLocation();
	vector<float> const & getBallLocation();

	void waitForUpdate();

	int getCurrentStatus();

	void setVideoParams(); // was originally private

protected:
	//---- GENERAL VARIABLES ----
	vector<float> lastOwnPosition;
	vector<float> lastBallPosition;

	int imgWidth;
	int imgHeight;

	Status currentStatus;

	ALPtr<ALMotionProxy> motionProxy;
	ALPtr<ALVideoDeviceProxy> videoProxy;
	std::string videoProxyName;

	IplImage* img;

	virtual void process() = 0;
	void run();
	void initImages();

	//---- HELPERS FOR PROCESSING ----
	float realDistanceFromImage(int const x, int const y, vector<float>& camPosition);
	vector<float> realFromImage(int const x, int const y, vector<float>& camPosition);
	void translateParticles();
	float projection(AL::Math::Pose2D const & a, AL::Math::Pose2D const & b);
	
	static inline float sq(float const a) {return a*a;}
	static inline float sqrt(float const a) {return std::sqrt(a);}

	//---- IMAGES FOR PROCESSING ----
	IplImage* hsv;
	IplImage* h;
	IplImage* s;
	IplImage* v;
	IplImage* soccerfield;

	//---- IMAGES FOR DEBUG ----
	IplImage* canvas;

	//---- IMAGES FOR PROCESS2 ----
	IplImage* mask;
	IplImage* perspective;
	IplImage* perspective_tmp;
	IplImage* perspective_mask;
	CvMat* trans;

	//---- STUFF FOR PROCESSING ----
	float* measurement;
	vector<NaoLocationParticle*> ptcls[2];
	int ptidx;

	float lastX;
	float lastY;
	float lastT;

	//---- CONSTANTS ----
	static const float PI;

	static const int MEASUREMENTS;
	static const int NPARTICLES;
	static const int RAND_PARTICLES;

	static const int SPACE_NAO;
	static const int SPACE_WORLD;

	//---- STUFF FOR DEBUGGING ----
	virtual void displayImages();

#ifdef USE_OPENCV_UI
	IplImage* displayPf;
	IplImage* soccerfield_col;

	CvFont fnt;
#endif
};
#endif