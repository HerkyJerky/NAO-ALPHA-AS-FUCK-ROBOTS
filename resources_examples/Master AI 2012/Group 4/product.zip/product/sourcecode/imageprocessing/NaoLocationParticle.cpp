#include "NaoLocationParticle.h"
#include "../MathConstants.h"

const int NaoLocationParticle::MAX_Y = 400;
const int NaoLocationParticle::MAX_X = 600;
const int NaoLocationParticle::RESAMPLING_JITTER = 5;
const float NaoLocationParticle::RESAMPLING_JITTER_ANG = PI/16;

AL::ALPtr<AL::ALMutex> NaoLocationParticle::mutex = AL::ALMutex::createALMutex();

NaoLocationParticle::NaoLocationParticle(int const _x, int const _y, float const _theta)
{
	x = _x;
	y = _y;
	theta = _theta;
	weight = 1;
}

NaoLocationParticle::NaoLocationParticle(const NaoLocationParticle& p)
{
	x = p.x;
	y = p.y;
	theta = p.theta;
	weight = 1;
}

NaoLocationParticle::NaoLocationParticle(const NaoLocationParticle& p, int const jitter, float const jitterAng)
{
	x = p.x+randi(jitter,-jitter);
	y = p.y+randi(jitter,-jitter);
	theta = p.theta+randf(jitterAng,-jitterAng);
	weight = 1;
}

int NaoLocationParticle::getX(){
	return x;
}

int NaoLocationParticle::getY(){
	return y;
}

float NaoLocationParticle::getTheta(){
	return theta;
}

int NaoLocationParticle::getWeight(){
	return weight;
}

void NaoLocationParticle::setWeight(int const _weight){
	if(_weight <= 0) weight = 1;
	else weight = _weight;
}

void NaoLocationParticle::generateParticles(int const n, std::vector<NaoLocationParticle*>& dst){
	AL::ALCriticalSection section(mutex);

	for(int i=0; i<n; i++){
		dst.push_back(randomParticle());
	}
}

void NaoLocationParticle::resampleParticles(int const nTotal, int const newParticles, std::vector<NaoLocationParticle*> const &  src, std::vector<NaoLocationParticle*>& dst){
	AL::ALCriticalSection section(mutex);
	
	int nKeep = nTotal - newParticles;

	std::vector<NaoLocationParticle*> list;

	int weight = 0;
	for(int i=0; i<src.size(); i++){
		int x = src[i]->getX();
		int y = src[i]->getY();
		int neighbours = 0;
		for(int j=0; j<src.size(); j++){
			int dx = x - src[j]->getX();
			int dy = y- src[j]->getY();
			if(sqrt((double)(dx*dx + dy*dy)) < 10){
				neighbours++;
				
				if(neighbours > 9){
					break;
				}
			}
		}
		weight = src[i]->weight / (neighbours / 10 + 1) + 1;
		for(int j=0;j<weight;j++){
			list.push_back(src[i]);
		}
	}

	for(int i=0; i<nKeep; i++){
		dst.push_back(sampleRandomParticle(list));
	}
	for(int i=0; i<newParticles; i++){
		dst.push_back(randomParticle());
	}
}

NaoLocationParticle* NaoLocationParticle::sampleRandomParticle(std::vector<NaoLocationParticle*>& src){
	int pos = randi(src.size());
	return new NaoLocationParticle(*(src[pos]), RESAMPLING_JITTER, RESAMPLING_JITTER_ANG);
}

NaoLocationParticle* NaoLocationParticle::randomParticle(){
	return new NaoLocationParticle(randi(MAX_X), randi(MAX_Y), randf(-PI, PI));
}

float NaoLocationParticle::randf(float const max, float const min){
	float diff = max-min;

	return 	mersennetwister::genrand_real2()*diff + min;
}

int NaoLocationParticle::randi(int const max, int const min){
	return (int)randf(max, min);
}

void NaoLocationParticle::drawParticles(IplImage* img, std::vector<NaoLocationParticle*> const &  p, int const jitter){
	AL::ALCriticalSection section(mutex);

	for(int i=0; i<p.size(); i++){
		drawParticle(img, p[i], jitter);
	}
}

void NaoLocationParticle::drawParticle(IplImage* img, NaoLocationParticle* const p, int const jitter, int const len, int const size, CvScalar const dotColor, CvScalar const lineColor){
		CvPoint center = cvPoint(p->x+randi(jitter,-jitter), p->y+randi(jitter,-jitter));
		CvPoint direction = cvPoint(center.x+(len*cos(p->theta)), center.y+(len*sin(p->theta)));
		cvCircle(img, center, size, dotColor, size);
		cvLine(img, center, direction, lineColor, size);
}

NaoLocationParticle NaoLocationParticle::getLocationEstimate(std::vector<NaoLocationParticle*> const & p){
	AL::ALCriticalSection section(mutex);
	
	int maxNeighbours = 0;
	NaoLocationParticle* bestParicle = 0;
	for(int i=0; i<p.size(); i++){
		int x = p[i]->getX();
		int y = p[i]->getY();
		int n = 0;
		for(int j=0; j<p.size(); j++){
			int dx = x - p[j]->getX();
			int dy = y- p[j]->getY();
			if(sqrt((double)(dx*dx + dy*dy)) < 100){
				n++;
			}
		}
		if(n>maxNeighbours){
			bestParicle = p[i];
			maxNeighbours = n;
		}
	}
	
	std::vector<NaoLocationParticle*> neighbours;
	int x = bestParicle->getX();
	int y = bestParicle->getY();
	for(int j=0; j<p.size(); j++){
		int dx = x - p[j]->getX();
		int dy = y- p[j]->getY();
		if(sqrt((double)(dx*dx + dy*dy)) < 25){
			neighbours.push_back(p[j]);
		}
	}
	
	long long int sumX  = 0;
	long long int sumY  = 0;
	float sumTX = 0;
	float sumTY = 0;
	
	int nParticles = neighbours.size();

	for(int i=0; i<nParticles; i++){
		sumX += neighbours[i]->x;
		sumY += neighbours[i]->y;
		sumTX += cos(neighbours[i]->theta);
		sumTY += sin(neighbours[i]->theta);
	}

	float avgT = atan2(sumTY/nParticles, sumTX/nParticles);

	return NaoLocationParticle(sumX/nParticles, sumY/nParticles, avgT);
}

void NaoLocationParticle::translateParticles(int dxt, int dyt, float dt, std::vector<NaoLocationParticle*>& dst){
	AL::ALCriticalSection section(mutex);
	
	for(int i=0; i<dst.size();i++){
		float t = dst[i]->theta;
		int dx = dxt*cos(t) + dyt*sin(t);
		int dy = dxt*sin(t) + dyt*cos(t);
		dst[i]->theta += dt;
		dst[i]->x += dx;
		dst[i]->y += dy;
	}
}

void NaoLocationParticle::translateParticles(int l, float dt, std::vector<NaoLocationParticle*>& dst){
	AL::ALCriticalSection section(mutex);

	for(int i=0; i<dst.size();i++){
		float t = dst[i]->theta;
		int dx = l*cos(t);
		int dy = l*sin(t);
		dst[i]->x += dx;
		dst[i]->y += dy;
		dst[i]->theta += dt;
	}
}

void NaoLocationParticle::deleteParticles(std::vector<NaoLocationParticle*>& list){
	AL::ALCriticalSection section(mutex);
	
	for(int i=0; i<list.size(); i++){
		delete list[i];
	}
	list.clear();
}

NaoLocationParticle::~NaoLocationParticle(void)
{
}
