#include "MultiLoc.h"

#include <alvision/alimage.h>
#include <alcommon/almodule.h>
#include <alcommon/albroker.h>
#include <alcommon/alproxy.h>
#include <alproxies/alvideodeviceproxy.h>
#include <alproxies/almemoryproxy.h>
#include <alvisiondefinitions.h>
#include <almath/types/alpose2d.h>
#include <qi/log.hpp>
#include <qi/os.hpp>

#include <ctime>

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cxtypes.h>

const float MultiLoc::PI = 3.1415926535f;

const int MultiLoc::MEASUREMENTS = 3;
const int MultiLoc::NPARTICLES = 1000;
const int MultiLoc::RAND_PARTICLES = 50;

const int MultiLoc::SPACE_NAO = 2;
const int MultiLoc::SPACE_WORLD = 1;

MultiLoc::MultiLoc(ALPtr<ALBroker> pBroker, const std::string& pName) : ALModule(pBroker, pName)
{
	setModuleDescription("Module for localization of different things: self, ball, goal.");

	functionName("start", getName() ,"start the localization. This is a non-blocking call.");
	BIND_METHOD(MultiLoc::start);

	functionName("stop", getName() ,"stop the localization. This is a blocking call.");
	BIND_METHOD(MultiLoc::stop);

	functionName("restart", getName() ,"restart the localization. This is a blocking call.");
	BIND_METHOD(MultiLoc::restart);

	functionName("suspend", getName() ,"suspend the localization. This is a blocking call.");
	BIND_METHOD(MultiLoc::suspend);

	functionName("getOwnLocation", getName() ,"suspend the localization. This is a blocking call.");
	BIND_METHOD(MultiLoc::getOwnLocation);

	functionName("getBallLocation", getName() ,"suspend the localization. This is a blocking call.");
	BIND_METHOD(MultiLoc::getBallLocation);

	functionName("waitForUpdate", getName() ,"wait for new data.");
	BIND_METHOD(MultiLoc::waitForUpdate);

	functionName("run", getName() ,"dont call this. call start :-)");
	BIND_METHOD(MultiLoc::run);
}

MultiLoc::~MultiLoc()
{
	videoProxy->unsubscribe(videoProxyName);
	delete measurement;
	cvReleaseImageHeader(&img);
	cvReleaseImage(&hsv);
	cvReleaseImage(&h);
	cvReleaseImage(&s);
	cvReleaseImage(&v);

	cvReleaseImage(&canvas);

	//--- CLEAN STUFF FOR PROCESSING 2 ---
	cvReleaseImage(&mask);
	cvReleaseImage(&perspective);
	cvReleaseImage(&perspective_tmp);
	cvReleaseImage(&perspective_mask);
	cvReleaseMat(&trans);
}

void MultiLoc::init(){
	currentStatus = STOPPED;

	videoProxy = ALPtr<ALVideoDeviceProxy>( new ALVideoDeviceProxy(getParentBroker()));
	videoProxyName = "MultiLoc";
	videoProxyName = videoProxy->subscribe(videoProxyName, AL::kQVGA, AL::kBGRColorSpace, 30);
	imgWidth = videoProxy->resolutionToSizes(AL::kQVGA)[0];
	imgHeight= videoProxy->resolutionToSizes(AL::kQVGA)[1];

	motionProxy = ALPtr<ALMotionProxy>( new ALMotionProxy(getParentBroker()));

	lastOwnPosition.push_back(3.0f);
	lastOwnPosition.push_back(2.0f);
	lastOwnPosition.push_back(3.14159f);

	lastBallPosition.push_back(2.5f);
	lastBallPosition.push_back(1.0f);

	img = cvCreateImageHeader(cvSize(imgWidth, imgHeight), 8, 3);

	//measurement = (float*)malloc(sizeof(float)*(MEASUREMENTS));
	measurement = new float[MEASUREMENTS];
	NaoLocationParticle::generateParticles(NPARTICLES, ptcls[0]);
	ptidx = 0;

	initImages();

	setVideoParams();

	vector<float> position = motionProxy->getPosition("CameraBottom", SPACE_WORLD, true);
	AL::Math::Pose2D first(cos(lastT), sin(lastT), lastT);
	lastX = position[0];
	lastY = position[1];
	lastT = position[5];

}

void MultiLoc::initImages(){
	//--- PROCESSING 1 and 2
#ifdef USE_OPENCV_UI
	cvInitFont(&fnt, CV_FONT_HERSHEY_PLAIN, 1,1);
#endif
	CvSize size = cvSize(imgWidth, imgHeight);
	hsv = cvCreateImage(size, IPL_DEPTH_8U, 3);
	h = cvCreateImage(size, IPL_DEPTH_8U, 1);
	s = cvCreateImage(size, IPL_DEPTH_8U, 1);
	v = cvCreateImage(size, IPL_DEPTH_8U, 1);

	//--- DEBUG ---
	canvas = cvCreateImage(size, IPL_DEPTH_8U, 3);

	//--- PROCESSING 2 ---
	CvSize size2 = cvSize(size.width*2, size.height*2);
	mask = cvCreateImage(cvSize(size.width+2, size.height+2), IPL_DEPTH_8U, 1);
	perspective = cvCreateImage(size2, IPL_DEPTH_8U, 3);
	perspective_tmp = cvCreateImage(size2, IPL_DEPTH_8U, 1);
	perspective_mask = cvCreateImage(size2, IPL_DEPTH_8U, 1);

	trans = cvCreateMat(3,3,CV_32FC1);
	CvPoint2D32f srcPts[4], dstPts[4];
	// +-0----1-+
	// |        |
	// 2--------3
	srcPts[0].x = 120;	srcPts[0].y=70;
	srcPts[1].x = 240;	srcPts[1].y=70;
	srcPts[2].x = 0;	srcPts[2].y=240;
	srcPts[3].x = 320;	srcPts[3].y=240;
	// 0------1
	// |      |
	// 2------3
	dstPts[0].x = 160;	dstPts[0].y=240;
	dstPts[1].x = 480;	dstPts[1].y=240;
	dstPts[2].x = 160;	dstPts[2].y=480;
	dstPts[3].x = 480;	dstPts[3].y=480;
	cvGetPerspectiveTransform(srcPts, dstPts, trans);
#ifdef STATEMACHINE_IS_REMOTE_ON
	soccerfield = cvLoadImage("C:\\Users\\nao\\Desktop\\soccerfield.png", false);
#else
	soccerfield = cvLoadImage("/home/nao/soccerfield.png", false);
#endif

#ifdef USE_OPENCV_UI
	soccerfield_col = cvLoadImage("C:\\Users\\nao\\Desktop\\soccerfield.png", true);
	displayPf = cvCreateImage(cvGetSize(soccerfield_col),soccerfield_col->depth, soccerfield_col->nChannels);
#endif
}

void MultiLoc::setVideoParams(){
	ALMemoryProxy memory(this->getParentBroker());
	if(memory.getData("RobotConfig/Body/Version") == std::string("4.0.0")){
		return;
	}
	
	int job;
	do{
		job = videoProxy->post.setParam(AL::kCameraSelectID, 1);
		videoProxy->wait(job,0);
		qi::os::msleep(2000);
	}while(videoProxy->getActiveCamera()==0);

	
	videoProxy->setParam(AL::kCameraAutoGainID,0);
	videoProxy->setParam(AL::kCameraAutoWhiteBalanceID,0);
	videoProxy->setParam(AL::kCameraAutoExpositionID,0);

	/* Maastricht settings
	videoProxy->setParam(AL::kCameraBrightnessID,104);
	videoProxy->setParam(AL::kCameraExposureID,510);
	videoProxy->setParam(AL::kCameraContrastID,84);
	videoProxy->setParam(AL::kCameraSaturationID,255);
	videoProxy->setParam(AL::kCameraHueID,1);
	videoProxy->setParam(AL::kCameraGainID,25);
	videoProxy->setParam(AL::kCameraBlueChromaID,174);
	videoProxy->setParam(AL::kCameraRedChromaID,64);*/

	/* Aachen Settings */
	videoProxy->setParam(AL::kCameraBrightnessID,128);
	videoProxy->setParam(AL::kCameraExposureID,400);
	videoProxy->setParam(AL::kCameraContrastID,64);
	videoProxy->setParam(AL::kCameraSaturationID,163);
	videoProxy->setParam(AL::kCameraHueID,1);
	videoProxy->setParam(AL::kCameraGainID,2);
	videoProxy->setParam(AL::kCameraBlueChromaID,180);
	videoProxy->setParam(AL::kCameraRedChromaID,64);
	
}

int MultiLoc::getCurrentStatus(){
	return currentStatus;
}

void MultiLoc::start()
{
	if(currentStatus != RUNNING){
		currentStatus = RUNNING;
		// start processing queue
		this->getProxy(getName())->pCall("run");
	}
}

void MultiLoc::stop()
{
	currentStatus = STOPPED;
}

void MultiLoc::suspend()
{
	currentStatus = SUSPENDED;
}

void MultiLoc::restart()
{
	currentStatus = RUNNING;
}

vector<float> const & MultiLoc::getOwnLocation()
{
	return this->lastOwnPosition;
}

vector<float> const & MultiLoc::getBallLocation()
{
	return this->lastBallPosition;
}

void MultiLoc::waitForUpdate()
{
}

void MultiLoc::run()
{
	while(currentStatus == RUNNING)
	{
		try{
			qiLogInfo("MultiLoc") << "Enter running loop" << std::endl;
#ifdef STATEMACHINE_IS_REMOTE_OFF
			ALImage* ret = (ALImage*)videoProxy->getImageLocal(videoProxyName);
			img->imageData = (char*)ret->getData();
#else
			ALValue ret = videoProxy->getImageRemote(videoProxyName);

			if (ret.isArray() && ret.getSize() >= 7)
			{
				img->imageData = (char*)ret[6].GetBinary();
			}
#endif
			qiLogInfo("MultiLoc") << "Got image " << std::endl;

			qi::os::timeval time_before, time_after;
			qi::os::gettimeofday(&time_before);


			process();

			qiLogInfo("MultiLoc") << "Did process" << std::endl;

			displayImages();

			qiLogInfo("MultiLoc") << "Did display" << std::endl;

			qi::os::msleep(100);
			qi::log::log(qi::log::debug,"xxx","processing");

			videoProxy->releaseImage(videoProxyName);

			qiLogInfo("MultiLoc") << "Released image" << std::endl;

			qi::os::gettimeofday(&time_after);

			double timeDiff = (time_after.tv_sec-time_before.tv_sec) + (time_after.tv_usec-time_before.tv_usec)/1000.0/1000.0;

			qiLogInfo("Info") << timeDiff - 0.1  << "s" << std::endl;

		}catch(ALError& e){
			qi::log::log(qi::log::error,"error","error while getting image");
			qi::log::log(qi::log::error,"error",e.what());
		}catch(cv::Exception& e){
			qi::log::log(qi::log::error,"error","error while processing image");
			qi::log::log(qi::log::error,"error",e.file.c_str());
		}catch(...){
			qi::log::log(qi::log::error,"error","unknown error");
		}

		videoProxy->releaseImage(videoProxyName);		
	}
}

void MultiLoc::displayImages(){
#ifdef USE_OPENCV_UI
	cvCopy(soccerfield_col, displayPf);
	NaoLocationParticle loc(lastOwnPosition[0],lastOwnPosition[1],lastOwnPosition[2]);
	NaoLocationParticle::drawParticles(displayPf, ptcls[ptidx]);	
	NaoLocationParticle::drawParticle(displayPf, &loc, 0, 8, 4, CV_RGB(255,255,0),CV_RGB(0,0,255));

	cvShowImage("Input", img);
	cvShowImage("Canny(s)", s);
	cvShowImage("Particles", displayPf);
	cvWaitKey(1);
#endif
}

float MultiLoc::realDistanceFromImage(int const x, int const y, vector<float>& camPosition)
{
	vector<float> pos;
	pos.push_back((float)x / imgWidth);
	pos.push_back((float)y / imgHeight);
	vector<float> ang = videoProxy->getAngPosFromImgPos(pos);

	float t = 1.5f - camPosition[4] - ang[1]; //RAD50DEG - hPitch - ang[1]; 
	float l = tan(t) * camPosition[2]; //tan(t)*NAO_HEIGHT;
	float h = sqrt(sq(camPosition[2])+sq(l));
	float k = tan(ang[0]) * h;

	return sqrt(sq(k)+sq((float)l)) + camPosition[0];
}

vector<float> MultiLoc::realFromImage(int const x, int const y, vector<float>& camPosition)
{
	vector<float> pos;
	pos.push_back((float)x / imgWidth);
	pos.push_back((float)y / imgHeight);
	vector<float> ang = videoProxy->getAngPosFromImgPos(pos);

	float t = 1.5f - camPosition[4] - ang[1]; //RAD50DEG - hPitch - ang[1]; 
	float l = tan(t) * camPosition[2]; //tan(t)*NAO_HEIGHT;
	float h = sqrt(sq(camPosition[2])+sq(l));
	float k = tan(ang[0]) * h;
	
	vector<float> res(2);
	res[0]=l;
	res[1]=k;
	return res;
}



void MultiLoc::translateParticles()
{
	vector<float> position = motionProxy->getPosition("CameraBottom", SPACE_WORLD, true);
	AL::Math::Pose2D first(cos(lastT), sin(lastT), lastT);
	float diffX = position[0] - lastX;
	float diffY = position[1] - lastY;
	float diffT = position[5] - lastT;
	AL::Math::Pose2D second(diffX,diffY,diffT);

	float diffTx = projection(first, second);

	float temp = first.x;
	first.x = -first.y;
	first.y = temp;

	float diffTy = projection(first, second);

	lastX = position[0];
	lastY = position[1];
	lastT = position[5];

	NaoLocationParticle::translateParticles((int)(diffTx * 100), (int)(-diffTy * 100), -diffT, ptcls[ptidx]);
}

float MultiLoc::projection(AL::Math::Pose2D const & a, AL::Math::Pose2D const & b)
{
	float ab = a.x * b.x + a.y*b.y;
	/*AL::Math::Pose2D projectionX(ab*a.x, ab*a.y, 0);

	return (ab>0 ? 1: -1) * sqrt(sq(projectionX.x) + sq(projectionX.y));*/
	return ab;
}
