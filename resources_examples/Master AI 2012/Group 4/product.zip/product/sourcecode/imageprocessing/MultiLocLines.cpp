#include "MultiLocLines.h"
#include <ctime>
#include <iostream>
using namespace std;

void saveImages(IplImage* result, string suffix){
	// this is for demo purposes only!
	long time = std::time(NULL);

	//IplImage* pic = cvCreateImage(cvSize(result->width, result->height), result->depth, result->nChannels);
	//cvScale(result, pic, 255);	

	stringstream ss_res;
	ss_res << "C:\\Users\\nao\\bilder\\linebased\\img_" << time << suffix << ".png";
	cvSaveImage(ss_res.str().c_str(), result);

	//cvReleaseImage(&pic);
}

MultiLocLines::MultiLocLines(ALPtr<ALBroker> pBroker, const std::string& pName) : MultiLoc(pBroker, pName)
{
}


bool MultiLocLines::yellowDetector_polygon(void)
{
	return colorDetector_polygon(85, 15, 1);
}

bool MultiLocLines::blueDetector_polygon(void)
{
	return false; //colorDetector_polygon(120, 15, 0);
}

bool MultiLocLines::colorDetector_polygon(int const hue, int const off, int const color)
{
	IplImage* imgHeader = cvCreateImage(cvSize(img->width, img->height), 8, 3);
	IplImage* h_temp = cvCreateImage(cvSize(320, 240), 8, 1);

	cvSmooth(img,imgHeader,CV_MEDIAN, 9,9);
	cvCvtColor(imgHeader, imgHeader, CV_RGB2HSV);

	cvSplit(imgHeader, h_temp, NULL, NULL, NULL);

	cvThreshold(h_temp,h_temp, hue - off, 180, CV_THRESH_TOZERO);
	cvThreshold(h_temp,h_temp, hue +off, 180, CV_THRESH_TOZERO_INV);

	cvCanny(h_temp, h_temp, 50, 200);
	CvMemStorage* sto = cvCreateMemStorage();
	CvSeq* first;
	int n = cvFindContours(h_temp, sto, &first, 88, CV_RETR_LIST);

	cvReleaseImage(&imgHeader);
	cvReleaseImage(&h_temp);

	bool found = false;

	CvSeq* next=first;
	while(next!=NULL){
		if(abs(cvArcLength(next)) > 100){
			if(color == 1)
			{
				cvDrawContours(img, next, CV_RGB(255,255,0), CV_RGB(0,0,255), 1);
			}
			else
			{
				cvDrawContours(img, next, CV_RGB(0,0,255), CV_RGB(0,0,255), 1);
			}

			found = true;
			break;
		}
		next=next->h_next;
	}

	cvReleaseMemStorage(&sto);
	return found;
}

void MultiLocLines::process()
{
	std::cout << "line based" << std::endl;

	cvCvtColor(img, hsv, CV_BGR2HSV);
	
	cvSplit(hsv, h,s,v,NULL);
	/*saveImages(h, "h_orig");
	saveImages(s, "s_orig");
	saveImages(v, "v_orig");*/

	cvSmooth(h,h,CV_MEDIAN, 15,15);
	cvSmooth(s,s,CV_MEDIAN, 15,15);
	/*saveImages(h, "h_smoothed");
	saveImages(s, "s_smoothed");*/
	cvCanny(s, s, 50, 200);
	//saveImages(s, "s_canny");

	//--- GREEN detection ---
	cvThreshold(h,h,50,180,CV_THRESH_TOZERO);
	cvThreshold(h,h,100,180,CV_THRESH_TOZERO_INV);
	cvSmooth(h,h,CV_MEDIAN, 9,9);
	cvThreshold(h,h,20,60,CV_THRESH_BINARY);
	cvSet(mask, cvScalar(0));
	cvFloodFill(h, cvPoint(160,210), cvScalar(120), cvScalarAll(5), cvScalarAll(5), 0, 8 | (255<<8) | CV_FLOODFILL_FIXED_RANGE | CV_FLOODFILL_MASK_ONLY, mask);
	IplConvKernel* kernel = cvCreateStructuringElementEx(15,15,7,7,CV_SHAPE_RECT);
	cvDilate(mask,mask, kernel);
	cvReleaseStructuringElement(&kernel);
	//--- mask now contains green area

	// Sample code for corner detection
	// http://www.moosechips.com/2008/08/opencv-corner-detection-using-cvgoodfeaturestotrack/

	//--- Perspective transform ---
	try{
		cvWarpPerspective(img, perspective, trans);
		cvWarpPerspective(mask, perspective_mask, trans);
		cvWarpPerspective(s, perspective_tmp, trans);

		cvNot(perspective_mask, perspective_mask);
		cvAddS(perspective, CV_RGB(255,255,255), perspective, perspective_mask);
		cvSet(perspective_tmp, CV_RGB(0,0,0), perspective_mask);
		cvNot(perspective_mask, perspective_mask);			
		//cvCvtColor(perspective, perspective_tmp, CV_BGR2GRAY);
	}catch(...){
		std::cout << "error in perspective transform" << std::endl;
		return;
	}
	//perspective_mask contains green area
	//perspective contains corrected image

	//cvShowImage("perspective" , perspective_tmp);

	
	// --- Line detection ---
	CvMemStorage* sto = cvCreateMemStorage();
	CvSeq* lines = cvHoughLines2(perspective_tmp, sto, CV_HOUGH_PROBABILISTIC, 1, CV_PI/180, 50, 75, 40);
	//saveImages(perspective_tmp, "perspective_5warped");

	if(lines->total<=0){
		cvReleaseMemStorage(&sto);
		return;
	}

	// find longest line
	double bestLength = 0.0;
	CvPoint* bestLine;
	for(int i=0; i<lines->total; i++){
		CvPoint* pt_b = (CvPoint*) cvGetSeqElem(lines, i);
		CvPoint a;

		a.x = pt_b[0].x - pt_b[1].x;
		a.y = pt_b[0].y - pt_b[1].y;

		double length = a.x*a.x + a.y*a.y;

		if(length > bestLength){
			bestLength = length;
			bestLine = pt_b;
		}	
	}

	if(lines->total<=0){
		cvReleaseMemStorage(&sto);
		return;
	}

	// get angle of line
	double angle = atan2((double)bestLine[0].y - bestLine[1].y, bestLine[0].x - bestLine[1].x);

	std::cout << angle << std::endl;

	CvMat* rotateMat = cvCreateMat(2,3,CV_32FC1);
	CvPoint2D32f center = cvPoint2D32f(bestLine[1].x + (bestLine[0].x - bestLine[1].x) / 2.0, bestLine[0].y + (bestLine[0].y - bestLine[1].y) / 2.0);

	// rotate lines so the longest line is parallel to y-axis
	// this needs to be done three more times in 90deg steps.
	cv2DRotationMatrix(center, -90+(angle*180 / CV_PI), 1.0, rotateMat);

	int minX = (1<<31) - 1;
	int minY = (1<<31) - 1;
	int maxX = 0;
	int maxY = 0;
	unsigned int maxLen = -1;

	for(int i=0; i<lines->total; i++){
		CvPoint* pt_b = (CvPoint*) cvGetSeqElem(lines, i);
		CvMat* points = cvCreateMat(3,2,CV_32F);
		cvSet(points, cvScalar(1));
		cvSet2D(points,0,0,cvScalar(pt_b[0].x));
		cvSet2D(points,1,0,cvScalar(pt_b[0].y));
		cvSet2D(points,0,1,cvScalar(pt_b[1].x));
		cvSet2D(points,1,1,cvScalar(pt_b[1].y));

		CvMat* erg = cvCreateMat(2,2,CV_32F);
		cvMatMul(rotateMat, points, erg);

		pt_b[0].x = (int)cvGet2D(erg, 0,0 ).val[0];
		pt_b[0].y = (int)cvGet2D(erg, 1,0 ).val[0];
		pt_b[1].x = (int)cvGet2D(erg, 0,1 ).val[0];
		pt_b[1].y = (int)cvGet2D(erg, 1,1 ).val[0];

		int dy = pt_b[0].y-pt_b[1].y;
		int dx = pt_b[0].x-pt_b[1].x;

		if(maxLen <  dx*dx + dy*dy){
			maxLen = dx*dx + dy*dy;
		}
		if(minX > pt_b[0].x){
			minX = pt_b[0].x;
		}
		if(minX > pt_b[1].x){
			minX = pt_b[1].x;
		}
		if(minY > pt_b[0].y){
			minY = pt_b[0].y;
		}
		if(minY > pt_b[1].y){
			minY = pt_b[1].y;
		}
		if(maxX < pt_b[0].x){
			maxX = pt_b[0].x;
		}
		if(maxX < pt_b[1].x){
			maxX = pt_b[1].x;
		}
		if(maxY < pt_b[0].y){
			maxY = pt_b[0].y;
		}
		if(maxY < pt_b[1].y){
			maxY = pt_b[1].y;
		}

		cvReleaseMat(&points);
		cvReleaseMat(&erg);
	}

	cvReleaseMat(&rotateMat);

	// scale factor from nao image to soccerfield.png
	double scaleY = 0.05;//240 / sqrt((double)maxLen);
	double scaleX = 0.1;
	//minX += 160; 
	//minY += 120;

	// scale lines
	for(int i=0; i<lines->total; i++){
		CvPoint* pt_b = (CvPoint*) cvGetSeqElem(lines, i);

		pt_b[0].x = (int)((pt_b[0].x - minX) * scaleX);
		pt_b[0].y = (int)((pt_b[0].y - minY) * scaleY);
		pt_b[1].x = (int)((pt_b[1].x - minX) * scaleX);
		pt_b[1].y = (int)((pt_b[1].y - minY) * scaleY);
	}
	
	bool yellowGoal, blueGoal;
	yellowGoal = yellowDetector_polygon();
	blueGoal = blueDetector_polygon();

	if(yellowGoal)
	{
		cout << "YellowGoal found" << endl;
	}

	if(blueGoal)
	{
		cout << "BlueGoal found" << endl;
	}

	IplImage* realLines = 0;
	IplImage* realLines90 = 0;
	IplImage* result = 0;
	IplImage* result90 = 0;
	IplImage* totalResults=0;
	
	CvMat* rot090 = cvCreateMat(2,3, CV_32F);
	CvMat* rot90180 = cvCreateMat(2,3,CV_32F);

	CvSize lineSize;
	CvSize resultSize;
	CvSize result90Size;
	try{
		lineSize = cvSize(10+(maxX-minX)*scaleX, 10+(maxY-minY)*scaleY);

		cv2DRotationMatrix(cvPoint2D32f(lineSize.width/2, lineSize.height/2),90,1,rot090);
		cv2DRotationMatrix(cvPoint2D32f(lineSize.height/2, lineSize.width/2),90,1,rot90180);

		realLines = cvCreateImage(lineSize, IPL_DEPTH_8U, 1);
		realLines90 = cvCreateImage(cvSize(lineSize.height, lineSize.width), IPL_DEPTH_8U, 1);

		resultSize = cvSize(soccerfield->width - realLines->width + 1, soccerfield->height - realLines->height + 1);
		result90Size = cvSize(soccerfield->width - realLines90->width + 1, soccerfield->height - realLines90->height + 1);

		if(resultSize.width <= 0 || resultSize.height <= 0){
			cvReleaseMemStorage(&sto);
			return;
		}

		result = cvCreateImage(resultSize, IPL_DEPTH_32F, 1);
		result90 = cvCreateImage(result90Size, IPL_DEPTH_32F, 1);
		totalResults = cvCreateImage(cvSize(max(resultSize.width, result90Size.width), max(resultSize.height, result90Size.height)), IPL_DEPTH_32F, 1);
		cvZero(totalResults);
		cvZero(realLines);

		vector<float> camPositionNao = motionProxy->getPosition("CameraBottom", SPACE_NAO, true); 
		int x, y;
		float t;
		int const offset = -50 ; //realDistanceFromImage(imgWidth/2, imgHeight/2, camPositionNao) * -100;
		cout << offset << endl;

		// draw line template
		for(int i=0; i<lines->total; i++){
			CvPoint* pt_b = (CvPoint*) cvGetSeqElem(lines, i);
			cvLine(realLines, pt_b[0], pt_b[1], cvScalar(255,255,255), 5);
		}

		cvMatchTemplate(soccerfield, realLines, result, CV_TM_CCORR_NORMED);
		cvThreshold(result, result, 0.5, 1, CV_THRESH_TOZERO);
		cvDilate(result, result, 0, 5);
		cvSetImageROI(totalResults,cvRect((totalResults->width/2-result->width/2), totalResults->height/2-result->height/2, result->width, result->height));
		cvAdd(result, totalResults, totalResults);

		cvWarpAffine(realLines, realLines90, rot090);
		cvMatchTemplate(soccerfield, realLines90, result90, CV_TM_CCORR_NORMED);
		cvThreshold(result90, result90, 0.5, 1, CV_THRESH_TOZERO);
		cvDilate(result90, result90, 0, 5);
		cvSetImageROI(totalResults,cvRect(totalResults->width/2-result90->width/2, totalResults->height/2-result90->height/2, result90->width, result90->height));
		cvAdd(result90, totalResults, totalResults);

		cvWarpAffine(realLines90, realLines, rot90180);
		cvMatchTemplate(soccerfield, realLines, result, CV_TM_CCORR_NORMED);
		cvThreshold(result, result, 0.5, 1, CV_THRESH_TOZERO);
		cvDilate(result, result, 0, 5);
		cvSetImageROI(totalResults,cvRect(totalResults->width/2-result->width/2, totalResults->height/2-result->height/2, result->width, result->height));
		cvAdd(result, totalResults, totalResults);

		cvWarpAffine(realLines, realLines90, rot090);
		cvMatchTemplate(soccerfield, realLines90, result90, CV_TM_CCORR_NORMED);
		cvThreshold(result90, result90, 0.5, 1, CV_THRESH_TOZERO);
		cvDilate(result90, result90, 0, 5);
		cvSetImageROI(totalResults,cvRect(totalResults->width/2-result90->width/2, totalResults->height/2-result90->height/2, result90->width, result90->height));
		cvAdd(result90, totalResults, totalResults);

		cvErode(totalResults, totalResults);
		cvErode(totalResults, totalResults);

		try{
			//--- DO SOMETHING WITH THE RESULTS HERE!!
			for(int i=0; i<ptcls[ptidx].size();i++){
				x = ptcls[ptidx][i]->getX() + (totalResults->width/2-result->width/2);// - realLines->width/2+1;
				y = ptcls[ptidx][i]->getY() + (totalResults->height/2-result->height/2); // - realLines->height/2+1;
				t = ptcls[ptidx][i]->getTheta();
				x = x + sin(t) * offset;
				y = y + cos(t) * offset;

				float v;
				if(x < 0 || y < 0 || x >= result->width || y >= result->height){
					v=1;
				}else{
					CvScalar value = cvGet2D(result, y,x);
					v = value.val[0]*10;
				}


				if(blueGoal && x < 300)
				{
					v /= 2;
				}
				else if(yellowGoal && x > 300)
				{
					v /= 2;
				}


				ptcls[ptidx][i]->setWeight(v);
			}
		}
		catch(...)
		{
			std::cout << " " << std::endl;
		}

		//saveImages(realLines, "realLines");
		//saveImages(totalResults, "totalResults");
		cvReleaseImage(&realLines);
		cvReleaseImage(&realLines90);
		cvReleaseImage(&result);
		cvReleaseImage(&result90);
		cvReleaseMat(&rot090);
		cvReleaseMat(&rot90180);
	}catch(...){
		std::cout << "doofe exception" << std::endl;
	}

	//cvShowImage("results", totalResults);
	translateParticles();

	NaoLocationParticle::resampleParticles(NPARTICLES, RAND_PARTICLES, ptcls[ptidx], ptcls[ptidx^1]);
	NaoLocationParticle::deleteParticles(ptcls[ptidx]);
	ptidx = ptidx ^ 1;
	NaoLocationParticle loc = NaoLocationParticle::getLocationEstimate(ptcls[ptidx]);	
	lastOwnPosition[0] = loc.getX();
	lastOwnPosition[1] = loc.getY();
	lastOwnPosition[2] = loc.getTheta();

	cvReleaseImage(&totalResults);
}