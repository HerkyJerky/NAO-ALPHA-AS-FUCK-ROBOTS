#ifndef NAOLOCATIONPARTICLE_H
#define NAOLOCATIONPARTICLE_H

#include <vector>

#include <opencv/cxcore.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>

#include <almathinternal/tools/mersennetwister.h>
#include <althread/almutex.h>
#include <alcore/alptr.h>
#include <althread/alcriticalsection.h>

class NaoLocationParticle
{
public:
	NaoLocationParticle(int const x, int const y, float const theta);
	NaoLocationParticle(const NaoLocationParticle& p);
	NaoLocationParticle(const NaoLocationParticle& p, int const jitter, float const jitterAng);
	virtual ~NaoLocationParticle(void);

	int getX();
	int getY();
	float getTheta();

	void setWeight(int const _weight);
	int getWeight();

	static NaoLocationParticle* randomParticle();
	static NaoLocationParticle* sampleRandomParticle(std::vector<NaoLocationParticle*>& list);

	static void generateParticles(int const n, std::vector<NaoLocationParticle*>& dst); 
	static void resampleParticles(int const nTotal, int const newParticles, std::vector<NaoLocationParticle*> const &  src, std::vector<NaoLocationParticle*>& dst);
	static void drawParticles(IplImage* const img, std::vector<NaoLocationParticle*> const & p, int const jitter=0);
	static void drawParticle(IplImage* const img, NaoLocationParticle* const p, int const jitter=0, int const len=6, int const size=2, CvScalar const dotColor=CV_RGB(255,0,0), CvScalar const lineColor=CV_RGB(255,128,0));
	static void deleteParticles(std::vector<NaoLocationParticle*>& list);
	static NaoLocationParticle getLocationEstimate(std::vector<NaoLocationParticle*> const & p);
	static void translateParticles(int l, float dt, std::vector<NaoLocationParticle*>& dst);
	static void translateParticles(int dx, int dy, float dt, std::vector<NaoLocationParticle*>& dst);

	static const int MAX_X;
	static const int MAX_Y;

	static AL::ALPtr<AL::ALMutex> mutex;

	static const int RESAMPLING_JITTER;
	static const float RESAMPLING_JITTER_ANG;

private:
	int x;
	int y;
	float theta;
	int weight;

	static float randf(float const max=0, float const min=0);
	static int randi(int const max=INT_MAX, int const min=0);
};

#endif