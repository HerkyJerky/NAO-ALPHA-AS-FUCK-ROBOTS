#include "MultiLoc.h"

class MultiLocLines : public MultiLoc
{
public:
	MultiLocLines(ALPtr<ALBroker> pBroker, const std::string& pName);
	virtual void process();
	//~MultiLocLines();

private:
	bool yellowDetector_polygon(void);
	bool blueDetector_polygon(void);
	bool colorDetector_polygon(int const hue, int const sat, int const color);
};
