#ifndef FIELD_H
#define FIELD_H

#include "Position.h"
#include "NaoPosition.h"
#include <vector>
using namespace std;

class Field
{
private:
	//vector<Position> opposingPlayers;
	//vector<NaoPosition> teamPlayers;
	Position ball;
	NaoPosition own;

public:
	Field();
	virtual ~Field();
	void setBallPosition(float x, float y);
	void setNaoPosition(float x, float y, float t);
	Position const & getBallPosition() const;
	NaoPosition const & getOwnPosition() const;
};

#endif