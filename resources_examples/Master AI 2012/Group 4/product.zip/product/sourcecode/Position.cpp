#include "Position.h"

const float Position::DEFAULT_X=300;
const float Position::DEFAULT_Y=200;

float Position::getX() const
{
	return posX;
}

float Position::getY() const
{
	return posY;
}

void Position::setX(float const x)
{
	this->posX = x;
}

void Position::setY(float const y)
{
	this->posY = y;
}