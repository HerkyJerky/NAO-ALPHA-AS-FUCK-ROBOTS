#include "NaoPosition.h"

const float NaoPosition::DEFAULT_X=300;
const float NaoPosition::DEFAULT_Y=200;
const float NaoPosition::DEFAULT_T=0;

float NaoPosition::getX() const 
{
	return posX;
}

float NaoPosition::getY() const
{
	return posY;
}

float NaoPosition::getOrientation() const
{
	return orientation;
}

void NaoPosition::setX(float const x)
{
	posX = x;
}

void NaoPosition::setY(float const y)
{
	posY = y;
}

void NaoPosition::setOrientation(float const t)
{
	orientation = t;
}