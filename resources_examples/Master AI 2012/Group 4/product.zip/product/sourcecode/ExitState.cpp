#include "ExitState.h"
#include "StateMachine.h"
#include <iostream>
using namespace std;

ExitState::ExitState(StateMachine* s) : State(s)
{
}

cStates ExitState::run()
{
	this->exit();
	return CLOSE;
}

void ExitState::init(void)
{
}

void ExitState::exit(void)
{
	cout << "Exiting ExitState ... " << endl;
	this->proxy = AL::ALPtr<AL::ALLedsProxy>( new AL::ALLedsProxy(this->sm->getParentBroker()) );
	proxy->setIntensity("FaceLeds", 1);
}