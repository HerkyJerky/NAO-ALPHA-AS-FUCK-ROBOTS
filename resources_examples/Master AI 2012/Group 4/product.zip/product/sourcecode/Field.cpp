#include "Field.h"
#include "NaoPosition.h"
#include "Position.h"

Field::Field()
{
}

Field::~Field()
{
}

void Field::setBallPosition(float x, float y){
	ball.setX(x);
	ball.setY(y);
}

void Field::setNaoPosition(float x, float y, float t)
{
	own.setX(x);
	own.setY(y);
	own.setOrientation(t);
}

Position const & Field::getBallPosition() const
{
	return ball;
}

NaoPosition const & Field::getOwnPosition() const
{
	return own;
}
