#ifndef BALLTRACKER_H
#define BALLTRACKER_H

//OpenCV includes
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

//C++ includes
#include <iostream>
#include <list>

//Aldebaran includes
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alproxies/alvideodeviceproxy.h>

//Our includes
#include "colortracker.h"
#include "main.h"
#include "constants.h"
#include "ball.h"
#include "imagemanager.h"

using namespace std;

class BallTracker
{
private:
    VideoCapture capture;
    ImageManager *imgManager;
    std::string clientID, clientName;
    list<string> colorNames;
    list<ColorTracker*> colorTrackers;
    bool detectNewBall;
    list<Ball*> lastBalls;
    int calibrateX, calibrateY, calibrateR;

    void trackBalls(string windowName, string colorName);
    void selfCalibrate(string windowName,string colorName);
    void drawBallOnFrame(Ball* ball, Mat &frame);
    void drawSelectionOnFrame(Mat &frame);

    void clearTrackers();
    void clearBalls();

public:
    bool selectingBall, selectingCenter, selectingRadius;

    BallTracker(VideoCapture &capture, list<string> colorNames);
    BallTracker(ImageManager &imgManager, list<string> colorNames);
    ~BallTracker();

    void calibrate();
    list<Ball*> getBalls();
    list<Ball*> getBalls(Mat &frame, bool renewFrame = true);

    //Called by mouseHandler - the center of the ball in the current image should be set
    void setCenter(int x, int y);

    //Called by mouseHandler - the center of the ball in the current image should be returned
    cv::Point getCenter();
    int getCenterX();
    int getCenterY();

    //Called by mouseHandler - the radius of the ball in the current image should be set
    void setRadius(int r);

    //Called by mouseHandler - new value should be added
    void newValue(int a, int b, int c);

    //Called by mouseHandler - start calibrating a new ball
    void newBall();

    //Called by mouseHandler - reset thresholds of current frameanalyzer
    void resetThresholds();

//    void setCalibrateImg(cv::Mat &img);
    int getFrameWidth();
    int getFrameHeight();
};

#endif

