#ifndef CONSTANTS_H
#define CONSTANTS_H

const int WIDTH = 640;                      //Width of frame
const int HEIGHT = 480;                     //Height of frame

//Self calibration constants
const int minHueWindowSize = 5;
const int maxHueWindowSize = 30;
const int minValueWindowSize = 75;
const int maxValueWindowSize = 255;
const int minSaturationWindowSize = 75;
const int maxSaturationWindowSize = 255;
const int learningHueStepSize = 2;
const int learningSaturationStepSize = 5;
const int learningValueStepSize = 5;
const int minAppearance = 50;

//Self calibration costs
const float centerdistanceRadiusWeight = 0.75f;
const float correctBallScoreMultiplikator = 100;
const float wrongBallCost = 0.5f;
const float wrongBallRadiusNorm = 15;
const float noBallCost = 1500.0f;

//General settings
const bool SHOW_DEBUG_WINDOWS= !true;        //Show hsv_images or not
const bool PRINT_FRAME_RATE  = !true;
const bool PRINT_HSV_VALUES  = !true;
const bool USE_ON_NAO_REMOTE = true;
const bool SELF_CALIBRATE    = true;


enum METHOD {HOUGH, MOMENTS, MAX, CONTOURS_MOMENTS, CONTOURS_HOUGH };
const METHOD CHOSEN_METHOD = CONTOURS_MOMENTS;
const int SMALLEST_OBJECT = 100;            //Area of smallest object to track. Used in CONTOURS

const int HUE_MARGIN = 40;                  //If the hue of a new value is outside of the range by this margin
                                            //Assume it lays at the other side of the spectrum

#endif

