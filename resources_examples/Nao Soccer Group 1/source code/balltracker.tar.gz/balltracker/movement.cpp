#include "movement.h"

Movement::Movement(AL::ALMotionProxy *motionProxy)
{
    this->motionProxy = motionProxy;
}


void Movement::focusPointOnFrame(int frameWidth, int frameHeight, std::list<Ball *> &balls) {
    //calc degree the head has to turn
    float yawInRadian = 0.0f, pitchInRadian = 0.0f;
    bool isAbsolute = false;

    int numBalls = balls.size();
    std::cout << "Number of Balls: " << numBalls << std::endl;
    if(numBalls > 0) {
        //get pixel per radian for the X-Axis
        float pprx = CAM_HFOV_RAD/((float)frameWidth);
        //get pixel per degree for the Y-Axis
        float ppry = CAM_VFOV_RAD/((float)frameHeight);

        int bx = 0, by = 0, maxBr = 0;

        for(std::list<Ball *>::iterator it = balls.begin(); it != balls.end(); it++) {
            Ball *tempBall = *it;

            if(tempBall->getR() > maxBr) {
                maxBr = tempBall->getR();
                bx = tempBall->getX();
                by = tempBall->getY();
                std::cout << "found ball: " << bx << " " << by << " " << maxBr << std::endl;
            }

        }
        //get the necessary yaw to center the coordinates in radians
        yawInRadian   = ((float)((frameWidth/2) - bx)) *pprx;
        //get the necessary ptch to center the coordinates in radians
        pitchInRadian = ((float)(by - (frameHeight/2)))*ppry;
    }
    //move head (motion proxy)
    std::cout << "Yaw in rad: " << yawInRadian*radiansToDegree << " pitch in rad: " << pitchInRadian*radiansToDegree << std::endl;
    this->moveHead(yawInRadian, pitchInRadian, isAbsolute);
//    this->motionProxy->moveTo(0,0,yawInRadian);
}

void Movement::moveHead(float yawInRadian, float pitchInRadian, bool isAbsolute) {
    // The name of the joint to be moved.
    const AL::ALValue headYaw = "HeadYaw";
    const AL::ALValue headPitch = "HeadPitch";
    // Target stiffness.
    AL::ALValue stiffness = 1.0f;
    // Time (in seconds) to reach the target.
    AL::ALValue time = 1.0f;
    // Call the stiffness interpolation method.
    this->motionProxy->stiffnessInterpolation(headYaw, stiffness, 0.1f);
    this->motionProxy->stiffnessInterpolation(headPitch, stiffness, 0.1f);

    // Set the target angle list, in radians.
    AL::ALValue targetYawAngles = AL::ALValue::array(yawInRadian);
    AL::ALValue targetPitchAngles = AL::ALValue::array(pitchInRadian);

    /*
     * Call the angle interpolation method. The joint will reach the
     * desired angles at the desired times.
     */
    this->motionProxy->angleInterpolation(headYaw, targetYawAngles, time, isAbsolute);
    this->motionProxy->angleInterpolation(headPitch, targetPitchAngles, time, isAbsolute);

    // Remove the stiffness on the head.
    stiffness = 0.0f;
    this->motionProxy->stiffnessInterpolation(headYaw, stiffness, 0.1f);
    this->motionProxy->stiffnessInterpolation(headPitch, stiffness, 0.1f);
}

/**
  Calculates the actual distance of the active camera to the ground based on the pitch of the head.
  @return the distance of the active camera to the ground in cm.
 */
float Movement::getCameraHeightInCM() {
    AL::ALValue names = "HeadPitch";
    bool useSensors = true;
    float height = NECK_HEIGHT_CM;
    float angle = (this->motionProxy->getAngles(names,useSensors)).front();
//    std::cout << "HeadPitch: " << (angle* (180.0f/PI)) << std::endl;
    //based on the camera in use apply a part of the rotation matrix for rotation in euclidean space
//    if(this->VDProxy->getActiveCamera() == ID_TOP_CAM) {
//        height += (sin(angle) + cos(angle))*CAM_TOP_OFFSET_Z_CM;
//    } else {
        height += (sin(angle) + cos(angle))*CAM_BOTTOM_OFFSET_Z_CM;
//    }
    return height;
}

void Movement::getRealCoordinatesFromImageCoordinates(int frameWidth, int frameHeight, Ball *ball, cv::Point *coordinates) {

    float radianPerPixelV((float)(CAM_VFOV_RAD/frameHeight));
    float radianPerPixelH((float)(CAM_HFOV_RAD/frameWidth));
    AL::ALValue headPitch("HeadPitch"), headYaw("HeadYaw");
    float headYawInRadians((float)(*((this->motionProxy->getAngles(headYaw, true)).begin())));
    float headPitchInRadians((float)(*((this->motionProxy->getAngles(headPitch, true)).begin())));
    float camHeight(getCameraHeightInCM());

    int xCoord = 0, yCoord = 0;

    //make the center of the image the origin of the coordinate system
    xCoord = (frameWidth/2) - ball->getX();
    yCoord = ball->getY() - (frameHeight/2);

    float pitch(0.0);
//    if(this->currentCam == ID_TOP_CAM) {
//        pitch = headPitchInRadians+CAM_TOP_ARC_RAD+(radianPerPixelV*yCoord);
//    } else {
        pitch = headPitchInRadians+CAM_BOTTOM_ARC_RAD+(radianPerPixelV*yCoord);
//    }

    //NOTE: Due to the transformation of a 3D space to a 2D image, the arcs retrieved from the position on the image might
    //add error as further they get from the center.
    float alpha = (PI/2.0f)-pitch;
    float dist  = tan(alpha) * camHeight;
    float yaw   = headYawInRadians + radianPerPixelH * xCoord;
    float xDist = cos(yaw) * dist;
    float yDist = sin(yaw) * dist;

//    std::cout << "Pitch: " << (pitch * (180.0f/PI)) << " Yaw: " << (yaw * (180.0f/PI)) << std::endl;

    //Correct the distance (because the calculated intersection of the line of sight wth the ground plane,
    //lays behind the ball)
    //For xDistance:
    xDist = xDist - tan(pitch) * BALL_RADIUS_IN_CM;


    coordinates->x = xDist;
    coordinates->y = yDist;
}
