#ifndef IMAGEMANAGER_H
#define IMAGEMANAGER_H

//OpenCV includes
#include <opencv2/core/core.hpp>

//Aldebaran includes
#include <alvalue/alvalue.h>
#include <alproxies/alvideodeviceproxy.h>
#include <alvision/alvisiondefinitions.h>


class ImageManager
{
private:
    AL::ALVideoDeviceProxy *camProxy;
    std::string clientName, clientID;
    int frameWidth, frameHeight;
public:
    ImageManager(AL::ALVideoDeviceProxy *camProxy, int resolution, int colorSpace, int fps);
    void getFrame(cv::Mat &frame);
    void toggleCamera();
    int getSelectedCameraID();
    int getFrameWidth();
    int getFrameHeight();
    void unsubscribe();
};

#endif // IMAGEMANAGER_H
