#include "imagemanager.h"

#include <opencv2/highgui/highgui.hpp>

ImageManager::ImageManager(AL::ALVideoDeviceProxy *camProxy, int resolution = AL::kVGA, int colorSpace = AL::kBGRColorSpace, int fps = 12) {
    this->camProxy = camProxy;
    this->clientName = "imagemanager";
    //subscribe
    clientID = this->camProxy->subscribe(clientName, resolution, colorSpace, fps);
    std::cout << "ClientID " << clientID << std::endl;
    camProxy->setParam(AL::kCameraSelectID, 0);
    if(resolution == AL::kQQVGA) {
        this->frameWidth =  160;
        this->frameHeight = 120;
    } else if(resolution == AL::kQVGA) {
        this->frameWidth =  320;
        this->frameHeight = 240;
    } else {
        this->frameWidth =  640;
        this->frameHeight = 480;
    }
}

void ImageManager::getFrame(cv::Mat &frame) {
    //Create an cv::Mat header to wrap into an opencv image.*/

    /* Retrieve an image from the camera.
     * The image is returned in the form of a container object, with the
     * following fields:
     * 0 = width
     * 1 = height
     * 2 = number of layers
     * 3 = colors space index (see alvisiondefinitions.h)
     * 4 = time stamp (seconds)
     * 5 = time stamp (micro seconds)
     * 6 = image buffer (size of width * height * number of layers)
     */

    /* Create an iplimage header to wrap into an opencv image.*/
    IplImage* imgHeader = cvCreateImageHeader(cvSize(this->getFrameWidth(), this->getFrameHeight()), 8, 3);

    AL::ALValue img = camProxy->getImageRemote(clientID);

    /* Access the image buffer (6th field) and assign it to the opencv image
    * container. */
    imgHeader->imageData = (char*)img[6].GetBinary();
    cv::Mat temp(imgHeader);

    temp.copyTo(frame);

    /* Tells to ALVideoDevice that it can give back the image buffer to the
     * driver. Optional after a getImageRemote but MANDATORY after a getImageLocal.*/
    camProxy->releaseImage(clientID);
}

void ImageManager::toggleCamera() {
    if(camProxy->getParam(AL::kCameraSelectID) == 0) {
        camProxy->setParam(AL::kCameraSelectID, 1);
    } else {
        camProxy->setParam(AL::kCameraSelectID, 0);
    }
}

int ImageManager::getSelectedCameraID() {
    return camProxy->getParam(AL::kCameraSelectID);
}

int ImageManager::getFrameWidth() {
    return this->frameWidth;
}

int ImageManager::getFrameHeight() {
    return this->frameHeight;
}

void ImageManager::unsubscribe() {
    camProxy->unsubscribe(clientID);
}
