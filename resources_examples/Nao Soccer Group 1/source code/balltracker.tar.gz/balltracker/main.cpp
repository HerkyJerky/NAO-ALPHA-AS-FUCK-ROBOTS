//OpenCV includes
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

//C++ includes
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <list>

//Aldebaran includes
#include <alvision/alimage.h>
#include <alvision/alvisiondefinitions.h>
#include <alproxies/alvideodeviceproxy.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alrobotpostureproxy.h>
#include <alcommon/alproxy.h>

//Our includes
#include "balltracker.h"
#include "constants.h"
#include "ball.h"
#include "imagemanager.h"
#include "movement.h"

BallTracker *ballTracker;
cv::VideoCapture *capture;
ImageManager *imgManager;
Movement *movManager;
boost::shared_ptr<AL::ALProxy> walkProxy;
AL::ALRobotPostureProxy *postureProxy;
std::string clientID;
std::string clientName;

/**
  * The mouseHandler sets variable according to the programs state.
  * @param event is the kind of event like "left button down" or "right button down".
  * @param x the horizontal coordiante on the image where the event happened.
  * @param y the vertical coordiante on the image where the event happened.
  * @param flags
  * @param *param is a value the user wants to pass. In this case it is the hsv version of the image the event happened on.
  */
void mouseHandler(int event, int x, int y, int flags, void *param) {
    if(SELF_CALIBRATE) {
        //set the coordinates of the center and then the radius of the ball.
        if(event == CV_EVENT_LBUTTONDOWN){
            if(ballTracker->selectingCenter) {
                std::cout << "set center on X=" << x << " Y=" << y << std::endl;
                ballTracker->setCenter(x, y);
                ballTracker->selectingCenter = false;
            } else if(ballTracker->selectingRadius){
                std::cout << "radius: " << cvRound(std::sqrt((ballTracker->getCenterX()-x)*(ballTracker->getCenterX()-x) + (ballTracker->getCenterY() - y)*(ballTracker->getCenterY() - y))) << std::endl;
                ballTracker->setRadius(cvRound(std::sqrt((ballTracker->getCenterX()-x)*(ballTracker->getCenterX()-x) + (ballTracker->getCenterY() - y)*(ballTracker->getCenterY() - y))));
                ballTracker->selectingRadius = false;
            }
        }
        //start the self calibration
        if(event == CV_EVENT_RBUTTONDOWN){
            if(ballTracker->selectingBall) {
                //start Calibrating

                ballTracker->selectingBall = false;
            }
        }
        //reset the flags and start setting center and radius again
        if(event == CV_EVENT_MBUTTONDOWN){
            if(ballTracker->selectingBall) {
                ballTracker->selectingCenter = true;
                ballTracker->selectingRadius = true;
            } else {
                ballTracker->selectingBall = true;
                ballTracker->selectingCenter = true;
                ballTracker->selectingRadius = true;
            }
        }
    } else {
        //add a hsv set to the current color tracker
        if(event == CV_EVENT_LBUTTONDOWN){
            Mat* hsv_frame = (Mat*) param;
            ballTracker->newValue(hsv_frame->at<Vec3b>(y,x)[0],hsv_frame->at<Vec3b>(y,x)[1],hsv_frame->at<Vec3b>(y,x)[2]);
        }
        //finish the calibration for the current color
        if(event == CV_EVENT_RBUTTONDOWN){
            ballTracker->newBall();
        }
        //reset the thresholds
        if(event == CV_EVENT_MBUTTONDOWN){
            ballTracker->resetThresholds();
        }
    }

}

const char* windowName = "Visualisation";

/**
  * Draw the balls of the ball list on the given frame.
  * @param frame is a cv::Mat which holds the image information.
  * @param balls is a list of Ball pointern which holds the balls, which shall be drawn.
  */
void drawBalls(Mat frame, list<Ball*> balls) {
//    Mat frame = Mat::zeros(HEIGHT,WIDTH,CV_8UC3);

    for (list<Ball *>::iterator it = balls.begin(); it!=balls.end(); it++){
        Ball *ball = (*it);

        circle(frame, cvPoint(ball->getX(), ball->getY()), 3, CV_RGB(0,255,0), -1, 8, 0 );
        circle(frame, cvPoint(ball->getX(), ball->getY()), ball->getR(), CV_RGB(255,0,0), 3, 8, 0 );
    }

    imshow(windowName,frame);
}

/**
  * Clears a list of Ball* and deletes the Ball objects the pointer are pointing to.
  * @param &aList is the list, which should be cleared.
  */
void clearList(list< Ball* > &aList) {
    for(list<Ball*>::iterator it = aList.begin(); it != aList.end(); it++) {
        delete (*it);
    }
    aList.clear();
}

int main(int argc, char *argv[])
{
    list<string> colorNames;
    colorNames.push_back("Orange");

    if(USE_ON_NAO_REMOTE) {
        if (argc < 2) {
            std::cerr << "Usage 'getimages robotIp'" << std::endl;
            return 1;
        }
        AL::ALVideoDeviceProxy *camProxy = new AL::ALVideoDeviceProxy(argv[1]/*"192.168.200.16"*/, 9559);
        AL::ALMotionProxy *motionProxy   = new AL::ALMotionProxy(argv[1]/*"192.168.200.16"*/, 9559);
        postureProxy = new AL::ALRobotPostureProxy(argv[1]/*"192.168.200.16"*/, 9559);
        walkProxy = boost::shared_ptr<AL::ALProxy>(new AL::ALProxy("Motion", argv[1], 9559));

        //subscribe in the camProxy
        /*
          Specify the resolution among : kQQVGA (160x120), kQVGA (320x240),
          kVGA (640x480) or k4VGA (1280x960, only with the HD camera).
          (Definitions are available in alvisiondefinitions.h)
         */
        int resolution = AL::kVGA;

        /*
          Then specify the color space desired among : kYuvColorSpace, kYUVColorSpace,
          kYUV422ColorSpace, kRGBColorSpace, etc.
          (Definitions are available in alvisiondefinitions.h)
         */
        int colorSpace = AL::kBGRColorSpace;

        /*
          Finally, select the minimal number of frames per second (fps) that your
          vision module requires up to 30fps.
         */
        int fps = 2;

        imgManager = new ImageManager(camProxy, resolution, colorSpace, fps);
        movManager = new Movement(motionProxy);

        ballTracker = new BallTracker(*imgManager, colorNames);

        //stand up
        postureProxy->applyPosture("Stand", 1.0f);

    } else {
        capture = new VideoCapture;

        if(argc > 1) {
            capture->open(string(argv[1]));
        } else {
            capture->open(0);
        }

        //capture.set(CV_CAP_PROP_FRAME_WIDTH, 1280);   //Not working in OpenCV 2.1
        //capture.set(CV_CAP_PROP_FRAME_HEIGHT,720);    //Not working in OpenCV 2.1

        ballTracker = new BallTracker(*capture, colorNames);
    }
    ballTracker->calibrate();

    //Visualisation starts here
    //To get ball positions call: ballTracker->getBalls()

    namedWindow(windowName,CV_WINDOW_AUTOSIZE);

    clock_t start, stop;
    int count = 0;
    start = clock();

    while(true){
        count++;

        Mat frame;

        if(USE_ON_NAO_REMOTE) {
            imgManager->getFrame(frame);
        } else {
            (*capture) >> frame;
        }

        if(USE_ON_NAO_REMOTE) {
            list<Ball *> newBalls = ballTracker->getBalls();
            movManager->focusPointOnFrame(imgManager->getFrameWidth(), imgManager->getFrameHeight(), newBalls);
            drawBalls(frame, newBalls);
        } else {
            drawBalls(frame, ballTracker->getBalls());
        }

        if(PRINT_FRAME_RATE && ((count%20) == 0)){
            stop = clock() ;

            double timePassed = ((double) (stop - start)) / CLOCKS_PER_SEC;

            cout << "Frame rate: " << (double)20 / timePassed << endl ;

            count = 0;

            start = clock();
        }

        //Visualisation is closed when Esc is pressed
        if( (waitKey(1) & 255) == 27 ) break;
    }

    if(USE_ON_NAO_REMOTE) {
        imgManager->unsubscribe();
    }

    delete ballTracker;

    return 0;
}

