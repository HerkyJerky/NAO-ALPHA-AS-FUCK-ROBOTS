#ifndef COLORTRACKER_H
#define COLORTRACKER_H

//OpenCV includes
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

//C++ includes
#include <list>
#include <vector>
#include <string>

//Our includes
#include "thresholdmanager.h"
#include "ball.h"
#include "constants.h"

using namespace std;

//Tracks a range of HSV values
//This class can make a difference between multiple balls
class ColorTracker
{
private:
    ThresholdManager* manager;
    string colorName;
    Mat hsv_frame;

    void closing(Mat &in, Mat &out);
    void detectBallHough(list<Ball*> &balls, Mat &thresholded, Point &offset);
    void detectBallMoments(list<Ball*> &balls, Mat &thresholded);
    void detectBallMax(list<Ball*> &balls, Mat &thresholded);
    void detectBallContours(list<Ball*> &balls, Mat &thresholded);

public:
    ColorTracker(string,string);
    ~ColorTracker();

    //These methods are called during calibration
    void newValue(int a, int b, int c);
    void resetThresholds();

    void calibrateSelf(int x, int y, int r, Mat &frame);
    void findBestValues(int originMinH, int originMaxH, int originMinS, int originMaxS, int originMinV, int originMaxV, int x, int y, int r, Mat &frame);
    float calcScore(int x, int y, int r, Mat &frame);


    //Analyzes a frame
    void analyzeFrame(list<Ball*> &balls, Mat &frame);
};

#endif

