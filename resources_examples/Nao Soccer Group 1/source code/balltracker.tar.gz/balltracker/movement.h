#ifndef MOVEMENT_H
#define MOVEMENT_H

#include <list>

#include <alproxies/almotionproxy.h>
#include <alproxies/alrobotpostureproxy.h>
#include <alcommon/alproxy.h>

#include "ball.h"

//constants
#define PI 3.14159265358979323846
#define degreeToRadians PI/180.0
#define radiansToDegree 1/degreeToRadians
#define NECK_HEIGHT_CM 44.959
#define ID_TOP_CAM 0
#define ID_BOTTOM_CAM 1
#define CAM_TOP_OFFSET_X_CM 5.390
#define CAM_TOP_OFFSET_Z_CM 6.790
#define CAM_BOTTOM_OFFSET_X_CM 4.880
#define CAM_BOTTOM_OFFSET_Z_CM 2.381
#define CAM_TOP_ARC_DEG 0
#define CAM_TOP_ARC_RAD 0
#define CAM_BOTTOM_ARC_DEG 40
#define CAM_BOTTOM_ARC_RAD 0.698131701
#define CAM_HFOV_DEG 47.8
#define CAM_HFOV_RAD 0.834267382
#define CAM_VFOV_DEG 36.8
#define CAM_VFOV_RAD 0.642281165
#define BALL_RADIUS_IN_CM 4.15

class Movement
{
public:
    Movement(AL::ALMotionProxy *motionProxy);

    void focusPointOnFrame(int frameWidth, int frameHeight, list<Ball *> &balls);
    void getRealCoordinatesFromImageCoordinates(int frameWidth, int frameHeight, Ball *ball, Point *coordinates);

private:
    AL::ALMotionProxy *motionProxy;
    float getCameraHeightInCM();
    void moveHead(float yawInRadian, float pitchInRadian, bool isAbsolute);
};

#endif // MOVEMENT_H
