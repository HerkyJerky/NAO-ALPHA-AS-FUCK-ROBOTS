/*
 * Copyright (c) 2012 Aldebaran Robotics. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the COPYING file.
 */
#include <iostream>

#include <qi/os.hpp>
//Includes from Aldebaran Robotics
#include <alproxies/alredballtrackerproxy.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alrobotpostureproxy.h>
#include <alcommon/alproxy.h>
#include <alproxies/alrobotpostureproxy.h>
#include <alproxies/alredballtrackerproxy.h>

#include "balltracker.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: alvisualcompass_example robotIp" << std::endl;
        return 1;
    }

    AL::ALMotionProxy mProxy(argv[1], 9559);
    AL::ALRobotPostureProxy pProxy(argv[1], 9559);
    AL::ALVideoDeviceProxy vProxy(argv[1], 9559);
    AL::ALRobotPostureProxy postureProxy(argv[1], 9559);
    BallTracker ballTracker(&mProxy, &pProxy, &vProxy);
//    ballTracker.init();
    boost::shared_ptr<AL::ALProxy> motionProxy
            = boost::shared_ptr<AL::ALProxy>(new AL::ALProxy("Motion", argv[1], 9559));
    boost::shared_ptr<AL::ALProxy> kickProxy
            = boost::shared_ptr<AL::ALProxy>(new AL::ALProxy("Kick", argv[1], 9559));
    postureProxy.applyPosture("Stand", 1.0);
    ballTracker.moveHead();
    ballTracker.turn();
    ballTracker.moveHead();
    ballTracker.turn();
    ballTracker.moveHead();
    ballTracker.turn();
    ballTracker.moveHead();
    postureProxy.applyPosture("Stand", 1.0);
    motionProxy->callVoid("walk", 0.8, 0.4, 0);
//    motionProxy->callVoid("walkAroundBall", 90, 0.20);
//    kickProxy->callVoid("doKick");

    return 1;
}
