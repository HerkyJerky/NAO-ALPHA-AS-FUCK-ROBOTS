#include "balltracker.h"
#include <qi/os.hpp>
#include <alvision/alvisiondefinitions.h>

#define MAX_BOTTOM 0.45f

BallTracker::BallTracker(AL::ALMotionProxy *mProxy, AL::ALRobotPostureProxy *pProxy, AL::ALVideoDeviceProxy *vProxy) {
    this->motionProxy = mProxy;
    this->postureProxy = pProxy;
    this->videoDeviceProxy = vProxy;
}

void BallTracker::init() {
    this->postureProxy->goToPosture("Stand", 0.6);
    std::vector<std::string> names;
    AL::ALValue angles;
    names.reserve(2);
    angles.arraySetSize(2);
    names.push_back("HeadYaw");
    angles[0] = 1.0f;
    names.push_back("HeadPitch");
    angles[1] = 0.0f;
    this->motionProxy->setAngles(names, angles, 0.1f); //Goes to starting position
    qi::os::sleep(3.0f);
}

void BallTracker::moveHead() {
    this->init();
    float waitingTime = 3.0f;
    std::vector<std::string> names;
    AL::ALValue angles;

    names.reserve(2);
    angles.arraySetSize(2);

    names.push_back("HeadYaw");
    angles[0] = -1.0f;

    names.push_back("HeadPitch");
    angles[1] = MAX_BOTTOM;

    this->videoDeviceProxy->setParam(AL::kCameraSelectID, 1);
    this->motionProxy->setAngles(names, angles, 0.1f);
    qi::os::sleep(waitingTime);

    names.clear();
    angles.clear();
    names.reserve(2);
    angles.arraySetSize(2);

    names.push_back("HeadYaw");
    angles[0] = 1.0f;

    names.push_back("HeadPitch");
    angles[1] = MAX_BOTTOM;

    this->videoDeviceProxy->setParam(AL::kCameraSelectID, 0);
    this->motionProxy->setAngles(names, angles, 0.1f);
    qi::os::sleep(waitingTime);

    names.clear();
    angles.clear();
    names.reserve(2);
    angles.arraySetSize(2);

    names.push_back("HeadYaw");
    angles[0] = -1.0f;

    names.push_back("HeadPitch");
    angles[1] = 0.0f;

    this->videoDeviceProxy->setParam(AL::kCameraSelectID, 1);
    this->motionProxy->setAngles(names, angles, 0.1f);
    qi::os::sleep(waitingTime);

    names.clear();
    angles.clear();
    names.reserve(2);
    angles.arraySetSize(2);

    names.push_back("HeadYaw");
    angles[0] = 1.0f;

    names.push_back("HeadPitch");
    angles[1] = 0.0f;

    this->videoDeviceProxy->setParam(AL::kCameraSelectID, 0);
    this->motionProxy->setAngles(names, angles, 0.1f);
    qi::os::sleep(waitingTime);
}

void BallTracker::turn() {
    this->motionProxy->moveTo(0,0,90*(3.14f/180));
}
