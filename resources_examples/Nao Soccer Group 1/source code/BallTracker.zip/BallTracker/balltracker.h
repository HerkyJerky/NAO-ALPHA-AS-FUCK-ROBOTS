#ifndef BALLTRACKER_H
#define BALLTRACKER_H

#include <alproxies/almotionproxy.h>
#include <alproxies/alrobotpostureproxy.h>
#include <alproxies/alvideodeviceproxy.h>

class BallTracker {
    public:
        BallTracker(AL::ALMotionProxy *mProxy, AL::ALRobotPostureProxy *pProxy, AL::ALVideoDeviceProxy *vProxy);
        void init();
        void moveHead();
        void turn();
    private:
        AL::ALMotionProxy *motionProxy;
        AL::ALRobotPostureProxy *postureProxy;
        AL::ALVideoDeviceProxy *videoDeviceProxy;
};

#endif // BALLTRACKER_H
