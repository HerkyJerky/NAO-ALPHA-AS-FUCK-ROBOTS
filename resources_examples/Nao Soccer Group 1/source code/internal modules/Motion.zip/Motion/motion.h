#ifndef MOTION_H
#define MOTION_H

#include <boost/shared_ptr.hpp>
#include <alcommon/almodule.h>
#include <alproxies/almotionproxy.h>

namespace AL {
    class ALBroker;
}

class Motion : public AL::ALModule {
    public:
        Motion(boost::shared_ptr<AL::ALBroker> pBroker, const std::string& pName);
        virtual ~Motion();
        virtual void init();

        // Accessable Methods from outside the local module
        void turn(const float &thetaInDegrees);
        void walkStraight(const float &x);
        void walk(const float &x, const float &y, const float &thetaInDegrees);
        void walkAroundBall(const float &thetaInDegrees, const float &distanceToBall);
        void walkAroundBallInSteps(const float &thetaInDegrees, const float &distanceToBall, const int &inSteps);

        void walkEndless(const float &thetaInDegrees, const float &speed);
        void stopWalkDirectly();
        void stopWalkSmoothly();
    private:
        AL::ALMotionProxy mProxy;
        void setInit();

};

#endif //MOTION_H
