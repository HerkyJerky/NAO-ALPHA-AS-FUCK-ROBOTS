#include "motion.h"

using namespace AL;

#define PI 3.141592653
#define TO_RAD PI/180
#define TO_DEG 1 / TO_RAD
#define DISTANCE_TO_BALL 0.15

Motion::Motion(boost::shared_ptr<ALBroker> broker, const std::string& name):ALModule(broker, name) {
    setModuleDescription("This is a Motion Module which takes care of all Motion concerning Robot Football, except Kicking the ball");

    functionName("turn", getName(), "Turnes by a angle in degrees");
    addParam("thetaInDegrees", "The angle to turn");
    BIND_METHOD(Motion::turn);

    functionName("walkStraight", getName(), "Walks straight");
    addParam("x", "distance in meters");
    BIND_METHOD(Motion::walkStraight);

    functionName("walk", getName(), "Walks to a coordinate with an angle theta");
    addParam("x", "x-coordinate");
    addParam("y", "y-coordinate");
    addParam("thetaInDegrees", "thetaAngle");
    BIND_METHOD(Motion::walk);

    functionName("walkAroundBall", getName(), "Walks around the ball with a distance");
    addParam("thetaInDegrees", "angle in degrees");
    addParam("distanceToBall", "Distance to the Ball (15cm is a good estimate)");
    BIND_METHOD(Motion::walkAroundBall);

    functionName("walkAroundBallInSteps", getName(), "Walks around the ball with a distance in a certain amount of steps");
    addParam("thetaInDegrees", "angle in degrees");
    addParam("distanceToBall", "Distance to the Ball (15cm is a good estimate)");
    addParam("inSteps", "Amount of Steps");
    BIND_METHOD(Motion::walkAroundBallInSteps);

    functionName("walkEndless", getName(), "Walks Endlessly with a given speed");
    addParam("thetaInDegrees", "angle in degrees");
    addParam("speed", "The Speed");
    BIND_METHOD(Motion::walkEndless);

    functionName("stopWalkDirectly", getName(), "Stops Directly");
    BIND_METHOD(Motion::stopWalkDirectly);

    functionName("stopWalkSmoothly", getName(), "Stops Smoothly");
    BIND_METHOD(Motion::stopWalkSmoothly);

    this->mProxy = AL::ALMotionProxy(broker);
}

Motion::~Motion(){}

void Motion::init() {

}

void Motion::setInit() {
    mProxy.moveInit();
}

void Motion::turn(const float &thetaInDegrees) {
    float thetaInRadiaans = thetaInDegrees * TO_RAD;
    mProxy.moveTo(0,0,thetaInRadiaans);
}

void Motion::walkStraight(const float &x) {
    mProxy.moveTo(x,0,0);
}

void Motion::walk(const float &x, const float &y, const float &thetaInDegrees) {
    float thetaInRadiaans = thetaInDegrees * TO_RAD;
    mProxy.moveTo(x,y,thetaInRadiaans);
}

void Motion::walkAroundBall(const float &thetaInDegrees, const float &distanceToBall) {
    float x;
    float y;
    float thetaInRadiaans = thetaInDegrees * TO_RAD;
    if (thetaInRadiaans > 0) { //turn right
        if (thetaInRadiaans > 0 && thetaInRadiaans < PI/2) {
            x = distanceToBall - sin((PI/2) - thetaInRadiaans) * distanceToBall;
            y = (sin(thetaInRadiaans) * distanceToBall);
        } else if (thetaInRadiaans == PI/2){
            x = distanceToBall;
            y = -1 * distanceToBall;
        } else {
            float newThetaX = thetaInRadiaans - PI/2;
            x = distanceToBall + sin(newThetaX) * distanceToBall;
            float newThetaY = (PI/2) - newThetaX;
            y = sin(newThetaY) * distanceToBall;
        }
        y = -1 * y;
        mProxy.moveTo(x, y, thetaInRadiaans);
    } else if (thetaInRadiaans < 0) { //turn left
        float thetaInRadiaansTemp = thetaInRadiaans * -1;
        if (thetaInRadiaans < 0 && thetaInRadiaans > -PI/2) {
            x = distanceToBall - sin((PI/2) - thetaInRadiaansTemp) * distanceToBall;
            y = (sin(thetaInRadiaansTemp) * distanceToBall);
        } else if (thetaInRadiaans == -PI/2){
            x = distanceToBall;
            y = distanceToBall;
        } else {
            float newThetaX = thetaInRadiaansTemp - PI/2;
            x = DISTANCE_TO_BALL + sin(newThetaX) * distanceToBall;
            float newThetaY = (PI/2) - newThetaX;
            y = sin(newThetaY) * distanceToBall;
        }
        mProxy.moveTo(x, y, thetaInRadiaans);
    } else if (thetaInRadiaans == PI || thetaInRadiaans == -1 * PI) {
        mProxy.moveTo(2 * distanceToBall, 0, thetaInRadiaans);
    }
}

void Motion::walkAroundBallInSteps(const float &thetaInDegrees, const float &distanceToBall, const int &inSteps) {
    float thetaPart = thetaInDegrees/inSteps;
    for (int i = 0; i < inSteps; i++) {
        this->walkAroundBall(thetaPart, distanceToBall);
    }
}

void Motion::walkEndless(const float &thetaInDegrees, const float &speed) {
    float tempSpeed = speed;
    if (thetaInDegrees != 0) {
        this->turn(thetaInDegrees);
    }
    if (tempSpeed > 1.0f) {
        tempSpeed = 1.0f;
    } else if (tempSpeed < 0.0f) {
        tempSpeed = 0.0f;
    }
    mProxy.setWalkTargetVelocity(1.0,0,0,speed);
}

void Motion::stopWalkDirectly() {
    mProxy.killMove();
}

void Motion::stopWalkSmoothly() {
    mProxy.stopMove();
}
