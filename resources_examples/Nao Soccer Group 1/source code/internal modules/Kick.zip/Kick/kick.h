#ifndef KICK_H
#define KICK_H

#include <boost/shared_ptr.hpp>
#include <alcommon/almodule.h>
#include <alproxies/almotionproxy.h>

namespace AL {
    class ALBroker;
}

class Kick : public AL::ALModule {
    public:
        Kick(boost::shared_ptr<AL::ALBroker> pBroker, const std::string& pName);
        virtual ~Kick();
        virtual void init();
        void doKick();
    private:
        void moveToKickPosture();
        void setStiffness();
        AL::ALMotionProxy mProxy;

};

#endif // KICK_H
