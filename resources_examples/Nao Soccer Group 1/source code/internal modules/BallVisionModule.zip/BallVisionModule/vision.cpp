#include "vision.h"
#include <sstream>
#include <fstream>
#include <qi/log.hpp>


const int WIDTH = 640;                      //Width of frame
const int HEIGHT = 480;                     //Height of frame
const bool SHOW_DEBUG_WINDOWS = !true;       //Show hsv_images or not
const bool PRINT_FRAME_RATE = !true;
const bool PRINT_HSV_VALUES = !true;

enum METHOD { HOUGH, MOMENTS, MAX, CONTOURS_MOMENTS, CONTOURS_HOUGH };
const METHOD CHOSEN_METHOD = CONTOURS_MOMENTS;
const int SMALLEST_OBJECT = 100;            //Area of smallest object to track. Used in CONTOURS

const int HUE_MARGIN = 40;


std::string clientID;
std::string clientName;
std::list<cv::Vec3f> lastBalls;
int frameWidth(0);
int frameHeight(0);
int minA;
int minB;
int minC;
int maxA;
int maxB;
int maxC;

Vision::Vision(boost::shared_ptr<AL::ALBroker> broker, const std::string& name):AL::ALModule(broker, name) {

    setModuleDescription("The Module that is responsible for Tracking a ball/goal/other naos");

    functionName("debugSayValues", getName(), "For Debug purpose only - Return the setted values from the min - max values");
    BIND_METHOD(Vision::debugSayValues);

    functionName("setMinHue", getName(), "Sets the minHue Value");
    addParam("minHue", "The value that is supposed to be set for the minHue Value");
    BIND_METHOD(Vision::setMinHue);

    functionName("setMaxHue", getName(), "Sets the minHue Value");
    addParam("maxHue", "The value that is supposed to be set for the maxHue Value");
    BIND_METHOD(Vision::setMaxHue);

    functionName("setMinSaturation", getName(), "Sets the minSaturation Value");
    addParam("minSaturation", "The value that is supposed to be set for the minSaturation Value");
    BIND_METHOD(Vision::setMinSaturation);

    functionName("setMaxSaturation", getName(), "Sets the maxSaturation Value");
    addParam("maxSaturation", "The value that is supposed to be set for the maxSaturation Value");
    BIND_METHOD(Vision::setMaxSaturation);

    functionName("setMinValue", getName(), "Sets the minValue Value");
    addParam("minValue", "The value that is supposed to be set for the minValue Value");
    BIND_METHOD(Vision::setMinValue);

    functionName("setMaxValue", getName(), "Sets the maxValue Value");
    addParam("maxValue", "The value that is supposed to be set for the maxValue Value");
    BIND_METHOD(Vision::setMaxValue);

    functionName("startTracking", getName(), "startTracking");
    BIND_METHOD(Vision::startTracking);

    this->motionProxy = AL::ALMotionProxy(broker);
    this->visionProxy = AL::ALVisionToolboxProxy(broker);
    this->videoProxy = AL::ALVideoDeviceProxy(broker);
    this->textProxy = AL::ALTextToSpeechProxy(broker);

    this->minHue = 0;
    this->maxHue = 0;
    this->minSaturation = 0;
    this->maxSaturation = 0;
    this->minValue = 0;
    this->maxValue = 0;
}

Vision::~Vision() {}

void Vision::init() {}

void Vision::debugSayValues() {
    std::ostringstream minHueString;
    minHueString << "Min Hue is equal to " << this->minHue;
    std::ostringstream maxHueString;
    maxHueString << "Max Hue is equal to " << this->maxHue;
    std::ostringstream minSatString;
    minSatString << "Min Saturation is equal to " << this->minSaturation;
    std::ostringstream maxSatString;
    maxSatString << "Max Saturation is equal to " << this->maxSaturation;
    std::ostringstream minValString;
    minValString << "Min Value is equal to " << this->minValue;
    std::ostringstream maxValString;
    maxValString << "Max Value is equal to " << this->maxValue;
    this->textProxy.say(minHueString.str());
    this->textProxy.say(maxHueString.str());
    this->textProxy.say(minSatString.str());
    this->textProxy.say(maxSatString.str());
    this->textProxy.say(minValString.str());
    this->textProxy.say(maxValString.str());
}

void Vision::setMinHue(const int &minHue) {
    this->minHue = minHue;
}

void Vision::setMaxHue(const int &maxHue) {
    this->maxHue = maxHue;
}

void Vision::setMinSaturation(const int &minSaturation) {
    this->minSaturation = minSaturation;
}

void Vision::setMaxSaturation(const int &maxSaturation) {
    this->maxSaturation = maxSaturation;
}

void Vision::setMinValue(const int &minValue) {
    this->minValue = minValue;
}

void Vision::setMaxValue(const int &maxValue) {
    this->maxValue = maxValue;
}

void Vision::getFrame(cv::Mat &frame) {

    /* Retrieve an image from the camera.
     * The image is returned in the form of a container object, with the
     * following fields:
     * 0 = width
     * 1 = height
     * 2 = number of layers
     * 3 = colors space index (see alvisiondefinitions.h)
     * 4 = time stamp (seconds)
     * 5 = time stamp (micro seconds)
     * 6 = image buffer (size of width * height * number of layers)
     */
    const AL::ALImage *img = (AL::ALImage *) this->videoProxy.getImageLocal(clientID);
    /* Access the image buffer (6th field) and assign it to the opencv image
     * container. */
    IplImage *tempImage = cvCreateImageHeader(cvSize(frameWidth, frameHeight), 8, 3);
    tempImage->imageData = (char *) img->getData();
    cv::Mat imageHeader(tempImage);
    std::ofstream myfile;
    myfile.open("myfile.txt");
    for (int i =0; i < 480; i++) {
        for (int k = 0; k < 640; k++) {
            myfile << imageHeader.at<cv::Vec3b>(k,i)[0] << " " << imageHeader.at<cv::Vec3b>(k,i)[1] << " " << imageHeader.at<cv::Vec3b>(k,i)[2];
            if (k < 639) {
                myfile << ",";
            } else {
                myfile << "\n";
            }
        }
    }
    myfile.close();
//    cvSaveImage("cameraPicture.png", tempImage);

    imageHeader.copyTo(frame);

    /* Tells to ALVideoDevice that it can give back the image buffer to the
     * driver. Optional after a getImageRemote but MANDATORY after a getImageLocal.*/
    this->videoProxy.releaseImage(clientID);
}

void Vision::toggleCamera() {
    if(this->videoProxy.getParam(AL::kCameraSelectID) == 0) {
        this->videoProxy.setParam(AL::kCameraSelectID, 1);
    } else {
        this->videoProxy.setParam(AL::kCameraSelectID, 0);
    }
}

int Vision::getSelectedCameraID() {
    return this->videoProxy.getParam(AL::kCameraSelectID);
}

void Vision::clearBalls() {
    for (std::list<cv::Vec3f>::iterator it = lastBalls.begin(); it!=lastBalls.end(); it++) {
        (*it)[0] = NULL;
        (*it)[1] = NULL;
        (*it)[2] = NULL;
        delete &it;
    }
    lastBalls.clear();
}

void Vision::addValues(int a, int b, int c) {
    if(a<(minA-HUE_MARGIN)){
        minA -= 180;
        maxA -= 180;
    } else if(a > (maxA + HUE_MARGIN))
        a -= 180;
    if(a < minA)
        minA = a-1;
    if(a > maxA)
        maxA = std::min(179, a+1);

    if(b < minB)
        minB = std::max(  0, b-1);
    if(b > maxB)
        maxB = std::min(255, b+1);

    if(PRINT_HSV_VALUES){
        std::cout << "New HSV: " << a << ", : " << b  << ", : " << c << std::endl;
        std::cout << "Min HSV: " << minA << ", " << minB << ", " << minC << std::endl;
        std::cout << "Max HSV: " << maxA << ", " << maxB << ", " << maxC << std::endl;
    }
}

void Vision::detectBallHough(std::list<cv::Vec3f> &balls, cv::Mat &thresholded, cv::Point &offset) {
    cv::GaussianBlur(thresholded, thresholded, cv::Size(9, 9), 1.5, 1.5);
    //cvCanny(thresholded,thresholded,40.0,180.0);

    double minDist;
    int param1;
    int param2;

    if(CHOSEN_METHOD == HOUGH) {
        minDist = thresholded.rows/4;
        param1 = 100;
        param2 = 50;
    } else {
        minDist = 1000;
        param1 = 400;
        param2 = 50;
    }

    std::vector<cv::Vec3f> circles;
    cv::HoughCircles(thresholded, circles, CV_HOUGH_GRADIENT,2,minDist,param1,param2,5,400);

    for(uint i=0; i<circles.size(); i++) {
        balls.push_back(cv::Vec3f(cvRound(circles[i][0])+offset.x,
                              cvRound(circles[i][1])+offset.y,
                              cvRound(circles[i][2])));
    }

}

void Vision::detectBallMoments(std::list<cv::Vec3f> &balls, cv::Mat &thresholded) {
    cv::Moments moment = moments(thresholded);

    double area = moment.m00;

    double x = moment.m10/area;
    double y = moment.m01/area;
    double r = sqrt(area/(3.14*255));

    balls.push_back(cv::Vec3f(x,y,r));
}

void Vision::detectBallMax(std::list<cv::Vec3f> &balls, cv::Mat &thresholded) {
    std::vector<int> columnSums;
    for(int i=0;i<thresholded.cols;i++)
        columnSums.push_back(0);

    std::vector<int> rowSums;
    for(int i=0;i<thresholded.rows;i++)
        rowSums.push_back(0);

    int sum = 0;

    for(int row = 0; row < thresholded.rows; ++row) {
        uchar* inp  = thresholded.ptr<uchar>(row);
        for (int col = 0; col < thresholded.cols; ++col) {
            if (*inp++ == 255) {
                rowSums[row]++;
                columnSums[col]++;
                sum++;
            }
        }
    }

    int x = 0, maxColumnSum = 0;
    for(uint i=0;i<columnSums.size();i++)
        if (columnSums.at(i) > maxColumnSum){
            x = i;
            maxColumnSum = columnSums.at(i);
        }

    int y = 0, maxRowSum = 0;
    for(uint i=0;i<rowSums.size();i++)
        if (rowSums.at(i) > maxRowSum){
            y = i;
            maxRowSum = rowSums.at(i);
        }

    double r = sqrt((double)sum/3.14);

    balls.push_back(cv::Vec3f(x,y,r));
}

void Vision::detectBallContours(std::list<cv::Vec3f> &balls, cv::Mat &thresholded) {
    std::vector< std::vector<cv::Point> > contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::Mat temp;
    thresholded.copyTo(temp);
    cv::findContours(temp,contours,hierarchy,CV_RETR_CCOMP,CV_CHAIN_APPROX_SIMPLE );
    std::cout << "Hirachy size: " << hierarchy.size() << std::endl;
    std::cout << "Contours size: " << contours.size() << std::endl;
    if (hierarchy.size() > 0) {
        int index = 0;
        for ( ; index >= 0; index = hierarchy[index][0]) {
            if(CHOSEN_METHOD == CONTOURS_HOUGH){
                cv::Moments moment = moments((cv::Mat)contours[index]);

                double area = moment.m00;

                int margin = 10;
                cv::Rect rect = cv::boundingRect((cv::Mat)contours[index]);
                cv::Point pt1, pt2;
                pt1.x = std::max(0,rect.x - margin);
                pt1.y = std::max(0,rect.y - margin);
                pt2.x = std::min(rect.x + rect.width + margin,639);
                pt2.y = std::min(rect.y + rect.height + margin,479);
                cv::Rect resizedRect = cv::Rect(pt1,pt2);

                if(area>SMALLEST_OBJECT){
                    cv::Mat region = thresholded(resizedRect);
                    detectBallHough(balls,region,pt1);
                }
            } else {
                cv::Moments moment = moments((cv::Mat)contours[index]);

                double area = moment.m00;
                std::cout << "Area: " << area << std::endl;
                if(area > SMALLEST_OBJECT){
                    std::cout << "AREA > SMALLEST_OBJECT" << std::endl;
                    double x = moment.m10/area;
                    double y = moment.m01/area;
                    double r = sqrt(area/3.14);

                    balls.push_back(cv::Vec3f(x,y,r));
                    std::cout << "Balls-Size: " << balls.size() << std::cout;
                }
            }
        }
    }
}

void Vision::closing(cv::Mat &in, cv::Mat &out) {
    cv::Mat element = cv::getStructuringElement( cv::MORPH_ELLIPSE, cv::Size(4,4) );
    cv::dilate(in, out, element);
    cv::dilate(out, out, element);
    cv::dilate(out, out, element);
    cv::erode(out, out, element);
    cv::erode(out, out, element);
    cv::erode(out, out, element);
}

cv::Mat Vision::thresholdImage(cv::Mat &image) {
    cv::Mat thresholdedTemp;
    cv::Mat thresholded;
    cv::inRange(image, cv::Scalar(std::max(0, minA), minB, minC, 0), cv::Scalar(maxA, maxB, maxC, 0), thresholded);
    if(minA < 0){
        cv::inRange(image, cv::Scalar(minA+180, minB, minC, 0), cv::Scalar(180, maxB, maxC, 0), thresholdedTemp);
        bitwise_or(thresholded, thresholdedTemp, thresholded);
    }
    return thresholded;
}

void Vision::analyzeFrame(std::list<cv::Vec3f> &balls, cv::Mat &frame) {
    cv::cvtColor(frame, frame, CV_BGR2HSV);

    cv::Mat thresholded = thresholdImage(frame);

    closing(thresholded, thresholded);

    switch(CHOSEN_METHOD){
        case HOUGH : {  cv::Point offset = cv::Point(0, 0);
                        detectBallHough(balls,thresholded,offset); } break;
        case MOMENTS :  detectBallMoments(balls,thresholded); break;
        case MAX :      detectBallMax(balls,thresholded); break;
        default :       detectBallContours(balls,thresholded); //Requires closing
    }
}

void Vision::getBalls(std::list<cv::Vec3f> &ballList, cv::Mat &frame) {
    if(!frame.data)
        std::cerr << "ERROR: frame is NULL" << std::endl;

    //=========================================FLIP THE IMAGE=========================================//
//    flip(frame,frame,1);
    //=========================================FLIP THE IMAGE=========================================//

    clearBalls();

    analyzeFrame(ballList,frame);
}

void Vision::startTracking() {
    std::list<std::string> colorNames;
    colorNames.push_back("Orange");

//    //subscribe in the camProxy
//    /*
//      Specify the resolution among : kQQVGA (160x120), kQVGA (320x240),
//      kVGA (640x480) or k4VGA (1280x960, only with the HD camera).
//      (Definitions are available in alvisiondefinitions.h)
//     */
    int resolution = AL::kVGA;

//    /*
//      Then specify the color space desired among : kYuvColorSpace, kYUVColorSpace,
//      kYUV422ColorSpace, kRGBColorSpace, etc.
//      (Definitions are available in alvisiondefinitions.h)
//     */
    int colorSpace = AL::kBGRColorSpace;

//    /*
//      Finally, select the minimal number of frames per second (fps) that your
//      vision module requires up to 30fps.
//     */
    int fps = 20;

//    //subscribe
    clientName = "BallVisionModule";
    clientID = this->videoProxy.subscribe(clientName, resolution, colorSpace, fps);
    if (this->getSelectedCameraID() != 0) {
        this->videoProxy.setParam(AL::kCameraSelectID, 0);
    }
    if(resolution == AL::kQQVGA) {
        frameWidth =  160;
        frameHeight = 120;
    } else if(resolution == AL::kQVGA) {
        frameWidth =  320;
        frameHeight = 240;
    } else {
        frameWidth =  640;
        frameHeight = 480;
    }


//    //Commented out because we send values there each time. This values will always differ because of different light conditions
    addValues(this->minHue, this->minSaturation, this->minValue);
    addValues(this->maxHue, this->maxSaturation, this->maxValue);

//    while(true){

        cv::Mat frame;
        getFrame(frame);

        getBalls(lastBalls, frame);
        if(lastBalls.size() > 0) {
            this->textProxy.say("I've found ball");
            //CHRIS MACH DEINE MAGIE
//            break;
        }
//    }

//    //unsubscribe
    this->videoProxy.unsubscribe(clientID);
}
