#ifndef VISION_H
#define VISION_H

#include <boost/shared_ptr.hpp>
#include <alcommon/almodule.h>
#include <alproxies/almotionproxy.h>
#include <alproxies/alvisiontoolboxproxy.h>
#include <alproxies/alvideodeviceproxy.h>
#include <alproxies/altexttospeechproxy.h>
#include <alvision/alvisiondefinitions.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <list>
#include <math.h>
#include <stdlib.h>
#include <alvision/alimage.h>

namespace AL {
    class ALBroker;
}

class Vision : public AL::ALModule {
    public:
        Vision(boost::shared_ptr<AL::ALBroker> pBroker, const std::string& pName);
        virtual ~Vision();
        virtual void init();

        void debugSayValues();

        void setMinHue(const int &minHue);
        void setMaxHue(const int &maxHue);
        void setMinSaturation(const int &minSaturation);
        void setMaxSaturation(const int &maxSaturation);
        void setMinValue(const int &minValue);
        void setMaxValue(const int &maxValue);

        void startTracking();

        AL::ALMotionProxy motionProxy;
        AL::ALVisionToolboxProxy visionProxy;
        AL::ALVideoDeviceProxy videoProxy;
        AL::ALTextToSpeechProxy textProxy;

        void drawBalls(cv::Mat frame, std::list<cv::Vec3f> &balls);
        void getFrame(cv::Mat &frame);
        void toggleCamera();
        int getSelectedCameraID();
        void clearBalls();
        void getBalls(std::list<cv::Vec3f> &ballList, cv::Mat &frame);
        void analyzeFrame(std::list<cv::Vec3f> &balls, cv::Mat &frame);
        cv::Mat thresholdImage(cv::Mat &image);
        void closing(cv::Mat &in, cv::Mat &out);
        void addValues(int a, int b, int c);
        void detectBallHough(std::list<cv::Vec3f> &balls, cv::Mat &thresholded, cv::Point &offset);
        void detectBallMoments(std::list<cv::Vec3f> &balls,cv:: Mat &thresholded);
        void detectBallMax(std::list<cv::Vec3f> &balls, cv::Mat &thresholded);
        void detectBallContours(std::list<cv::Vec3f> &balls, cv::Mat &thresholded);




        int minHue;
        int maxHue;
        int minSaturation;
        int maxSaturation;
        int minValue;
        int maxValue;
};
#endif // VISION_H
